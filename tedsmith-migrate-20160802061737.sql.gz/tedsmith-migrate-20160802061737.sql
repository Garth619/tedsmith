# WordPress MySQL database migration
#
# Generated: Tuesday 2. August 2016 06:17 UTC
# Hostname: localhost
# Database: `tedsmith`
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_commentmeta`
#

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Mr WordPress', '', 'https://wordpress.org/', '', '2016-05-20 17:38:50', '2016-05-20 17:38:50', 'Hi, this is a comment.\nTo delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, '1', '', '', 0, 0) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=MyISAM AUTO_INCREMENT=1387 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://tedsmithdemo.com', 'yes'),
(2, 'home', 'http://tedsmithdemo.com', 'yes'),
(3, 'blogname', 'Ted Smith Law Group', 'yes'),
(4, 'blogdescription', '', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'ilawyerwp@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '0', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'F j, Y', 'yes'),
(24, 'time_format', 'g:i a', 'yes'),
(25, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:89:{s:19:"sitemap_index\\.xml$";s:19:"index.php?sitemap=1";s:31:"([^/]+?)-sitemap([0-9]+)?\\.xml$";s:51:"index.php?sitemap=$matches[1]&sitemap_n=$matches[2]";s:24:"([a-z]+)?-?sitemap\\.xsl$";s:25:"index.php?xsl=$matches[1]";s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:39:"index.php?&page_id=85&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:5:{i:0;s:34:"advanced-custom-fields-pro/acf.php";i:1;s:29:"gravityforms/gravityforms.php";i:2;s:24:"simple-history/index.php";i:3;s:24:"wordpress-seo/wp-seo.php";i:4;s:39:"wp-migrate-db-pro/wp-migrate-db-pro.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', '', 'no'),
(40, 'template', 'tedsmith', 'yes'),
(41, 'stylesheet', 'tedsmith', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '0', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '36686', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(51, 'blog_public', '0', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'page', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '0', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '0', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:0:{}', 'yes'),
(80, 'widget_rss', 'a:0:{}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', '', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '85', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '36686', 'yes'),
(92, 'wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:35:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:11:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:6:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(93, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(94, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'sidebars_widgets', 'a:8:{s:19:"wp_inactive_widgets";a:0:{}s:19:"primary-widget-area";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:21:"secondary-widget-area";N;s:24:"first-footer-widget-area";N;s:25:"second-footer-widget-area";N;s:24:"third-footer-widget-area";N;s:25:"fourth-footer-widget-area";N;s:13:"array_version";i:3;}', 'yes'),
(99, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(100, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(101, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(103, 'cron', 'a:6:{i:1470159530;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1470159539;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1470159874;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1470160968;a:1:{s:29:"simple_history/maybe_purge_db";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1470178566;a:1:{s:17:"gravityforms_cron";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(106, 'nonce_key', '8(v^@ms8%4VS1^lfP?lpuh&(mUp=g$e*(pIBM|f%DBq[{JV|d)rloJ/w:=jBG:=s', 'yes'),
(107, 'nonce_salt', 'MbiZsRu_Tp(Gb`mVM/5vU:AEwm66SkB2X}@`JRl%1B>liXZ:9/[=|;oXsw^#`vvs', 'yes'),
(116, 'auth_key', 'hR%QJZik:0Y^QcEw}qmYJV2CWpag.MmCCut#5,*@W8Mg$5M Vc&=,Z5SEwD}$ec=', 'yes'),
(117, 'auth_salt', '3s-UbIC84Ip?1t}Y:<,oCbl5+_jP#jk8f PA^Pw$AA1F?fX3liEO,^F>k!w?}BHu', 'yes'),
(118, 'logged_in_key', 'QHai-}lX>^mN6T?zkm&z[hZiPWJYVSU~?Wy>jq[/.q(-_#U^2zJKs?^hCi]:h5G/', 'yes'),
(119, 'logged_in_salt', 'c0PS/SlN@U*DtJpnDI,j)f>z7_)4fvQhX%sUi6[nr0O.Cev8D]-ig`@qQ # u[!K', 'yes'),
(127, 'can_compress_scripts', '1', 'yes'),
(140, 'recently_activated', 'a:0:{}', 'yes'),
(143, 'wpseo_titles', 'a:60:{s:10:"title_test";i:0;s:17:"forcerewritetitle";b:0;s:14:"hide-feedlinks";b:0;s:12:"hide-rsdlink";b:0;s:14:"hide-shortlink";b:0;s:16:"hide-wlwmanifest";b:0;s:5:"noodp";b:0;s:6:"noydir";b:0;s:15:"usemetakeywords";b:0;s:16:"title-home-wpseo";s:42:"%%sitename%% %%page%% %%sep%% %%sitedesc%%";s:18:"title-author-wpseo";s:0:"";s:19:"title-archive-wpseo";s:38:"%%date%% %%page%% %%sep%% %%sitename%%";s:18:"title-search-wpseo";s:0:"";s:15:"title-404-wpseo";s:0:"";s:19:"metadesc-home-wpseo";s:0:"";s:21:"metadesc-author-wpseo";s:0:"";s:22:"metadesc-archive-wpseo";s:0:"";s:18:"metakey-home-wpseo";s:0:"";s:20:"metakey-author-wpseo";s:0:"";s:22:"noindex-subpages-wpseo";b:0;s:20:"noindex-author-wpseo";b:0;s:21:"noindex-archive-wpseo";b:1;s:14:"disable-author";b:0;s:12:"disable-date";b:0;s:10:"title-post";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-post";s:0:"";s:12:"metakey-post";s:0:"";s:12:"noindex-post";b:0;s:17:"noauthorship-post";b:0;s:13:"showdate-post";b:0;s:16:"hideeditbox-post";b:0;s:10:"title-page";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-page";s:0:"";s:12:"metakey-page";s:0:"";s:12:"noindex-page";b:0;s:17:"noauthorship-page";b:1;s:13:"showdate-page";b:0;s:16:"hideeditbox-page";b:0;s:16:"title-attachment";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:19:"metadesc-attachment";s:0:"";s:18:"metakey-attachment";s:0:"";s:18:"noindex-attachment";b:0;s:23:"noauthorship-attachment";b:1;s:19:"showdate-attachment";b:0;s:22:"hideeditbox-attachment";b:0;s:18:"title-tax-category";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-category";s:0:"";s:20:"metakey-tax-category";s:0:"";s:24:"hideeditbox-tax-category";b:0;s:20:"noindex-tax-category";b:0;s:18:"title-tax-post_tag";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-post_tag";s:0:"";s:20:"metakey-tax-post_tag";s:0:"";s:24:"hideeditbox-tax-post_tag";b:0;s:20:"noindex-tax-post_tag";b:0;s:21:"title-tax-post_format";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:24:"metadesc-tax-post_format";s:0:"";s:23:"metakey-tax-post_format";s:0:"";s:27:"hideeditbox-tax-post_format";b:0;s:23:"noindex-tax-post_format";b:1;}', 'yes'),
(146, 'wpseo', 'a:14:{s:14:"blocking_files";a:0:{}s:15:"ms_defaults_set";b:0;s:7:"version";s:3:"3.4";s:12:"company_logo";s:0:"";s:12:"company_name";s:0:"";s:17:"company_or_person";s:0:"";s:20:"disableadvanced_meta";b:1;s:19:"onpage_indexability";b:1;s:12:"googleverify";s:0:"";s:8:"msverify";s:0:"";s:11:"person_name";s:0:"";s:12:"website_name";s:0:"";s:22:"alternate_website_name";s:0:"";s:12:"yandexverify";s:0:"";}', 'yes'),
(155, 'wpseo_sitemap_cache_validator_global', '2qxy3', 'no'),
(156, 'wpseo_permalinks', 'a:9:{s:15:"cleanpermalinks";b:0;s:24:"cleanpermalink-extravars";s:0:"";s:29:"cleanpermalink-googlecampaign";b:0;s:31:"cleanpermalink-googlesitesearch";b:0;s:15:"cleanreplytocom";b:0;s:10:"cleanslugs";b:1;s:18:"redirectattachment";b:0;s:17:"stripcategorybase";b:0;s:13:"trailingslash";b:0;}', 'yes'),
(157, 'wpseo_social', 'a:20:{s:9:"fb_admins";a:0:{}s:12:"fbconnectkey";s:32:"be1e58dd1fb55d4b203268c92b5f5fe8";s:13:"facebook_site";s:0:"";s:13:"instagram_url";s:0:"";s:12:"linkedin_url";s:0:"";s:11:"myspace_url";s:0:"";s:16:"og_default_image";s:0:"";s:18:"og_frontpage_title";s:0:"";s:17:"og_frontpage_desc";s:0:"";s:18:"og_frontpage_image";s:0:"";s:9:"opengraph";b:1;s:13:"pinterest_url";s:0:"";s:15:"pinterestverify";s:0:"";s:14:"plus-publisher";s:0:"";s:7:"twitter";b:1;s:12:"twitter_site";s:0:"";s:17:"twitter_card_type";s:7:"summary";s:11:"youtube_url";s:0:"";s:15:"google_plus_url";s:0:"";s:10:"fbadminapp";s:0:"";}', 'yes'),
(158, 'wpseo_rss', 'a:2:{s:9:"rssbefore";s:0:"";s:8:"rssafter";s:53:"The post %%POSTLINK%% appeared first on %%BLOGLINK%%.";}', 'yes'),
(159, 'wpseo_internallinks', 'a:10:{s:20:"breadcrumbs-404crumb";s:25:"Error 404: Page not found";s:23:"breadcrumbs-blog-remove";b:0;s:20:"breadcrumbs-boldlast";b:0;s:25:"breadcrumbs-archiveprefix";s:12:"Archives for";s:18:"breadcrumbs-enable";b:0;s:16:"breadcrumbs-home";s:4:"Home";s:18:"breadcrumbs-prefix";s:0:"";s:24:"breadcrumbs-searchprefix";s:16:"You searched for";s:15:"breadcrumbs-sep";s:7:"&raquo;";s:23:"post_types-post-maintax";i:0;}', 'yes'),
(160, 'wpseo_xml', 'a:16:{s:22:"disable_author_sitemap";b:1;s:22:"disable_author_noposts";b:1;s:16:"enablexmlsitemap";b:1;s:16:"entries-per-page";i:1000;s:14:"excluded-posts";s:0:"";s:38:"user_role-administrator-not_in_sitemap";b:0;s:31:"user_role-editor-not_in_sitemap";b:0;s:31:"user_role-author-not_in_sitemap";b:0;s:36:"user_role-contributor-not_in_sitemap";b:0;s:35:"user_role-subscriber-not_in_sitemap";b:0;s:30:"post_types-post-not_in_sitemap";b:0;s:30:"post_types-page-not_in_sitemap";b:0;s:36:"post_types-attachment-not_in_sitemap";b:1;s:34:"taxonomies-category-not_in_sitemap";b:0;s:34:"taxonomies-post_tag-not_in_sitemap";b:0;s:37:"taxonomies-post_format-not_in_sitemap";b:0;}', 'yes'),
(165, 'acf_version', '5.3.10', 'yes'),
(166, 'wpseo_sitemap_1_cache_validator', '2Cl62', 'no'),
(167, 'wpseo_sitemap_page_cache_validator', '2Cl68', 'no'),
(168, 'wpseo_sitemap_revision_cache_validator', '2Cl6d', 'no'),
(171, 'theme_mods_twentysixteen', 'a:2:{s:18:"nav_menu_locations";a:0:{}s:16:"sidebars_widgets";a:2:{s:4:"time";i:1467999652;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(172, 'wpseo_sitemap_nav_menu_cache_validator', '6XnBy', 'no'),
(186, 'wpseo_sitemap_nav_menu_item_cache_validator', '6XnBB', 'no'),
(187, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(188, 'wpseo_sitemap_138_cache_validator', '61bG7', 'yes'),
(197, 'category_children', 'a:0:{}', 'yes'),
(282, 'wpseo_sitemap_post_cache_validator', '75twU', 'no'),
(524, 'auto_core_update_notified', 'a:4:{s:4:"type";s:7:"success";s:5:"email";s:19:"ilawyerwp@gmail.com";s:7:"version";s:5:"4.5.3";s:9:"timestamp";i:1466536329;}', 'yes'),
(772, 'upload_path', '', 'yes'),
(773, 'upload_url_path', '', 'yes'),
(813, 'current_theme', 'Ted Smith', 'yes'),
(814, 'theme_mods_tedsmith', 'a:2:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:7:"primary";i:3;}}', 'yes'),
(815, 'theme_switched', '', 'yes'),
(818, 'acf_pro_license', 'YToyOntzOjM6ImtleSI7czo3MjoiYjNKa1pYSmZhV1E5TXpNeU9ETjhkSGx3WlQxa1pYWmxiRzl3WlhKOFpHRjBaVDB5TURFMExUQTNMVEEzSURJeE9qSTRPak0yIjtzOjM6InVybCI7czoyMzoiaHR0cDovL3RlZHNtaXRoZGVtby5jb20iO30=', 'yes'),
(823, 'WPLANG', '', 'yes'),
(868, 'simple_history_db_version', '5', 'yes'),
(869, 'simple_history_show_as_page', '1', 'yes'),
(870, 'simple_history_show_on_dashboard', '1', 'yes'),
(871, 'simple_history_enable_rss_feed', '0', 'yes'),
(872, 'simple_history_rss_secret', 'otokbnvzuvfhvaozbrua', 'yes'),
(876, 'widget_gform_widget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(877, 'gravityformsaddon_gravityformswebapi_version', '1.0', 'yes'),
(879, 'gform_enable_background_updates', '', 'yes'),
(880, 'gform_longtext_ready', '1', 'yes'),
(881, 'rg_form_version', '2.0.4', 'yes'),
(889, 'rg_gforms_key', '621e21584ab7936611e0d28422299c97', 'yes'),
(890, 'gform_enable_noconflict', '', 'yes'),
(891, 'rg_gforms_enable_akismet', '0', 'yes'),
(892, 'rg_gforms_currency', 'USD', 'yes'),
(917, 'rg_gforms_disable_css', '1', 'yes'),
(918, 'rg_gforms_captcha_public_key', '', 'yes'),
(919, 'rg_gforms_captcha_private_key', '', 'yes'),
(920, 'rg_gforms_message', '<!--GFM-->', 'yes'),
(961, 'gform_email_count', '6', 'yes'),
(995, 'wpseo_sitemap_170_cache_validator', '6tJUd', 'no'),
(996, 'wpseo_sitemap_171_cache_validator', '6tJUh', 'no'),
(997, 'wpseo_sitemap_172_cache_validator', '6tJUm', 'no'),
(998, 'wpseo_sitemap_173_cache_validator', '6tJUq', 'no'),
(1000, 'wpseo_sitemap_181_cache_validator', '6ykOK', 'no'),
(1001, 'wpseo_sitemap_193_cache_validator', '6z82U', 'no'),
(1030, 'wpseo_sitemap_221_cache_validator', '5EAm4', 'no'),
(1141, 'wpseo_sitemap_216_cache_validator', '6WGiE', 'no'),
(1142, 'wpseo_sitemap_217_cache_validator', '6WGiI', 'no'),
(1143, 'wpseo_sitemap_218_cache_validator', '6WGiM', 'no'),
(1144, 'wpseo_sitemap_219_cache_validator', '6WGiQ', 'no'),
(1145, 'wpseo_sitemap_220_cache_validator', '6WGiU', 'no'),
(1150, 'wpseo_sitemap_225_cache_validator', '6XdJQ', 'no'),
(1151, 'wpseo_sitemap_227_cache_validator', '6XdJU', 'no') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM AUTO_INCREMENT=1148 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(2, 4, '_edit_last', '1'),
(3, 4, '_edit_lock', '1463766205:1'),
(4, 6, '_edit_last', '1'),
(5, 6, '_edit_lock', '1463766938:1'),
(6, 8, '_edit_last', '1'),
(7, 8, '_edit_lock', '1463766959:1'),
(8, 10, '_edit_last', '1'),
(9, 10, '_edit_lock', '1463767135:1'),
(10, 12, '_edit_last', '1'),
(11, 12, '_edit_lock', '1463767030:1'),
(12, 14, '_edit_last', '1'),
(13, 14, '_edit_lock', '1463767172:1'),
(14, 16, '_edit_last', '1'),
(15, 16, '_edit_lock', '1463767164:1'),
(16, 18, '_edit_last', '1'),
(17, 18, '_edit_lock', '1463767167:1'),
(18, 20, '_edit_last', '1'),
(19, 20, '_edit_lock', '1463767121:1'),
(20, 22, '_edit_last', '1'),
(21, 22, '_edit_lock', '1463767157:1'),
(22, 24, '_edit_last', '1'),
(23, 24, '_edit_lock', '1463767160:1'),
(24, 26, '_edit_last', '1'),
(25, 26, '_edit_lock', '1463767131:1'),
(26, 18, '_yoast_wpseo_title', 'Killeen Paternity Lawyers | Harker Heights Paternity Test Attorneys'),
(27, 18, '_yoast_wpseo_metadesc', 'If you have questions about paternity, contact the attorneys of Ted Smith Law Group at 254-690-5688. We are located in Harker Heights, TX and offer free consultations.'),
(28, 12, '_yoast_wpseo_title', 'Harker Heights Child Support Attorneys | Ted Smith Law Group'),
(29, 12, '_yoast_wpseo_metadesc', 'The family law attorneys of Ted Smith Law Group are experienced in child support matters. Call us in Harker Heights, Texas at 254-690-5688 today.'),
(30, 6, '_yoast_wpseo_title', 'Killeen Divorce Lawyers | Fort Hood Property Division Lawyer'),
(31, 6, '_yoast_wpseo_metadesc', 'We protect the interests of civilian and military families in divorce. Call 254-690-5688 to get a free attorney consultation and learn how we can help you.'),
(35, 8, '_yoast_wpseo_title', 'Killeen Child Custody Attorneys | Fort Hood Custody Lawyers'),
(36, 8, '_yoast_wpseo_metadesc', 'Get the right attorney on your side when your ability to be a part of your child\'s life is at stake. Call 254-690-5688 for a free attorney consultation.'),
(37, 29, '_edit_last', '1'),
(38, 29, '_edit_lock', '1463767100:1'),
(39, 29, '_yoast_wpseo_title', 'Fort Hood Military Divorce Attorneys | Military Retirement Benefits'),
(40, 29, '_yoast_wpseo_metadesc', 'The attorneys of Ted Smith Law Group represent military service members and spouses in military family law matters. Call us in Harker Heights at 254-690-5688.'),
(41, 31, '_edit_last', '1'),
(42, 31, '_edit_lock', '1463767166:1'),
(43, 31, '_yoast_wpseo_title', 'Killeen Personal Injury Lawyers | Accident Lawyers Harker Heights'),
(44, 31, '_yoast_wpseo_metadesc', 'Hurt and in need of help? Don\'t know where to turn? Call 254-690-5688 to get a free attorney consultation and the answers you need.'),
(45, 33, '_edit_last', '1'),
(46, 33, '_edit_lock', '1463767239:1'),
(47, 35, '_edit_last', '1'),
(48, 35, '_edit_lock', '1463768001:1'),
(49, 35, '_yoast_wpseo_title', 'Killeen Truck Accident Attorneys | 18-Wheeler Accident Harker Heights'),
(50, 35, '_yoast_wpseo_metadesc', 'Truck accidents on Interstates, Texas state highways and local roads can all result in severe injuries. Call 254-690-5688 for a free attorney consultation.'),
(51, 37, '_edit_last', '1'),
(52, 37, '_edit_lock', '1463768037:1'),
(53, 39, '_edit_last', '1'),
(54, 39, '_edit_lock', '1463768116:1'),
(55, 39, '_yoast_wpseo_title', 'Harker Heights Bicycle Accident Attorneys | Killeen Bike Accident Lawyers'),
(56, 39, '_yoast_wpseo_metadesc', 'If you or a loved one has been injured in a bike accident, contact the attorneys of Ted Smith Law Group at 254-690-5688. We offer free consultations.'),
(57, 41, '_edit_last', '1'),
(58, 41, '_edit_lock', '1463768184:1'),
(59, 43, '_edit_last', '1'),
(60, 43, '_edit_lock', '1463768261:1'),
(61, 45, '_edit_last', '1'),
(62, 45, '_edit_lock', '1463768311:1'),
(63, 47, '_edit_last', '1'),
(64, 47, '_edit_lock', '1463768381:1'),
(65, 47, '_yoast_wpseo_title', 'Killeen Wrongful Death Attorney | Fatal Accident Lawyers Harker Heights'),
(66, 47, '_yoast_wpseo_metadesc', 'A local law firm providing exceptional representation to friends and neighbors. Contact Ted Smith Law Group at 254-690-5688 for a free attorney consultation.'),
(67, 49, '_edit_last', '1'),
(68, 49, '_edit_lock', '1463768412:1'),
(69, 51, '_edit_last', '1'),
(70, 51, '_edit_lock', '1463768450:1'),
(71, 53, '_edit_last', '1'),
(72, 53, '_edit_lock', '1463768502:1'),
(73, 55, '_edit_last', '1'),
(74, 55, '_edit_lock', '1463768540:1'),
(75, 57, '_edit_last', '1'),
(76, 57, '_edit_lock', '1463768578:1'),
(77, 59, '_edit_last', '1'),
(78, 59, '_edit_lock', '1463768624:1'),
(79, 61, '_edit_last', '1'),
(80, 61, '_edit_lock', '1463768658:1'),
(81, 63, '_edit_last', '1'),
(82, 63, '_edit_lock', '1463768706:1'),
(83, 63, '_yoast_wpseo_title', 'Killeen Social Security Disability Attorneys | Disability Benefits'),
(84, 63, '_yoast_wpseo_metadesc', 'Denied SSD benefits and need help? We help clients across Texas appeal denial of benefits. Call 254-690-5688 for a free attorney consultation.'),
(85, 65, '_edit_last', '1'),
(86, 65, '_edit_lock', '1463768766:1'),
(87, 67, '_edit_last', '1'),
(88, 67, '_edit_lock', '1463768813:1'),
(89, 69, '_edit_last', '1'),
(90, 69, '_edit_lock', '1463768871:1'),
(91, 71, '_edit_last', '1'),
(92, 71, '_edit_lock', '1463768909:1'),
(93, 73, '_edit_last', '1'),
(94, 73, '_edit_lock', '1463768944:1'),
(95, 75, '_edit_last', '1'),
(96, 75, '_edit_lock', '1463769665:1'),
(97, 75, '_yoast_wpseo_title', 'Killeen Estate Planning Attorneys | Wills Probate Harker Heights Lawyer'),
(98, 75, '_yoast_wpseo_metadesc', 'Call 254-690-5688 for a free attorney consultation regarding estate planning, probate or estate litigation.'),
(99, 77, '_edit_last', '1'),
(100, 77, '_edit_lock', '1463770007:1'),
(101, 79, '_edit_last', '1'),
(102, 79, '_edit_lock', '1463770157:1'),
(103, 81, '_edit_last', '1'),
(104, 81, '_edit_lock', '1463770065:1') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(105, 83, '_edit_last', '1'),
(106, 83, '_edit_lock', '1463770120:1'),
(107, 83, '_yoast_wpseo_title', 'Killeen Medical Malpractice Attorneys | Birth Injury Lawyers Harker Heights'),
(108, 83, '_yoast_wpseo_metadesc', 'Did a failure to diagnose cancer or some other type of medical negligence harm you or a loved one? Call 254-690-5688 for a free attorney consultation.'),
(109, 85, '_edit_last', '1'),
(110, 85, '_edit_lock', '1463770143:1'),
(111, 87, '_edit_last', '1'),
(112, 87, '_edit_lock', '1468000243:1'),
(113, 89, '_edit_last', '1'),
(114, 89, '_edit_lock', '1463770450:1'),
(115, 89, '_yoast_wpseo_title', 'Harker Heights Criminal Defense Attorneys | Killeen DUI Lawyers'),
(116, 89, '_yoast_wpseo_metadesc', 'Killeen Criminal Defense Attorneys Defending for your rights in Bell County and surrounding communities,Contact us to schedule a free initial consultation.'),
(117, 91, '_edit_last', '1'),
(118, 91, '_yoast_wpseo_title', 'Harker Heights Tax Law Lawyer | Ted Smith Law Group, PLLC'),
(119, 91, '_yoast_wpseo_metadesc', 'The attorneys at Ted Smith Law Group can help with your legal tax needs. Contact us at 254-690-5688 for a free attorney consultation.'),
(120, 91, '_edit_lock', '1463770491:1'),
(121, 94, '_edit_last', '1'),
(122, 94, '_yoast_wpseo_title', 'Harker Heights Real Estate Attorney | Ted Smith Law Group, PLLC'),
(123, 94, '_yoast_wpseo_metadesc', 'The attorneys at Ted Smith Law Group can help with your real estate legal needs. Contact us at 254-690-5688 for a free attorney consultation.'),
(124, 94, '_edit_lock', '1463770560:1'),
(125, 96, '_edit_last', '1'),
(126, 96, '_edit_lock', '1463770643:1'),
(127, 96, '_yoast_wpseo_title', 'Harker Heights Bankruptcy Attorney | Chapter 7 Chapter 13'),
(128, 96, '_yoast_wpseo_metadesc', 'For experienced bankruptcy attorneys, contact Ted Smith Law Group in Harker Heights. Call 254-690-5688 for a free attorney consultation.'),
(129, 98, '_edit_last', '1'),
(130, 98, '_edit_lock', '1463770997:1'),
(131, 98, '_yoast_wpseo_title', 'Harker Heights Business Law Attorneys | Business Formation Lawyers Killeen, TX'),
(132, 98, '_yoast_wpseo_metadesc', 'The attorneys of Ted Smith Law Group offer experienced and professional business law representation. Contact us in Harker Heights at 254-690-5688.'),
(133, 100, '_edit_last', '1'),
(134, 100, '_edit_lock', '1463771045:1'),
(135, 100, '_yoast_wpseo_title', 'Killeen Immigration Attorneys | Harker Heights Visa Lawyers'),
(136, 100, '_yoast_wpseo_metadesc', 'Don\'t let the immigration process be unduly delayed or your application improperly be denied. Call 254-690-5688 for a free attorney consultation.'),
(137, 102, '_edit_last', '1'),
(138, 102, '_edit_lock', '1463771150:1'),
(139, 102, '_yoast_wpseo_title', 'General Civil Practice | Ted Smith Law Group, PLLC | Harker Heights, Texas'),
(140, 102, '_yoast_wpseo_metadesc', 'A local law firm providing exceptional representation to friends and neighbors. Contact Ted Smith Law Group at 254-690-5688 for a free attorney consultation.'),
(141, 104, '_edit_last', '1'),
(142, 104, '_edit_lock', '1463771330:1'),
(143, 104, '_yoast_wpseo_title', 'Contact | Ted Smith Law Group, PLLC | Harker Heights, Texas'),
(144, 104, '_yoast_wpseo_metadesc', 'Contact Ted Smith Law Group at 254-690-5688 for a free attorney consultation and the trusted advice you deserve.'),
(145, 106, '_edit_last', '1'),
(146, 106, '_edit_lock', '1463771234:1'),
(147, 108, '_edit_last', '1'),
(148, 108, '_edit_lock', '1463771330:1'),
(149, 108, '_yoast_wpseo_title', 'Harker Heights Lawyers | Ted Smith Law Group'),
(150, 108, '_yoast_wpseo_metadesc', 'Want to learn more about your lawyer? View our profiles on this page or contact us at 254-690-5688 to schedule a free attorney consultation.'),
(151, 110, '_menu_item_type', 'post_type'),
(152, 110, '_menu_item_menu_item_parent', '0'),
(153, 110, '_menu_item_object_id', '61'),
(154, 110, '_menu_item_object', 'page'),
(155, 110, '_menu_item_target', ''),
(156, 110, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(157, 110, '_menu_item_xfn', ''),
(158, 110, '_menu_item_url', ''),
(160, 111, '_menu_item_type', 'post_type'),
(161, 111, '_menu_item_menu_item_parent', '0'),
(162, 111, '_menu_item_object_id', '98'),
(163, 111, '_menu_item_object', 'page'),
(164, 111, '_menu_item_target', ''),
(165, 111, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(166, 111, '_menu_item_xfn', ''),
(167, 111, '_menu_item_url', ''),
(169, 112, '_menu_item_type', 'post_type'),
(170, 112, '_menu_item_menu_item_parent', '0'),
(171, 112, '_menu_item_object_id', '89'),
(172, 112, '_menu_item_object', 'page'),
(173, 112, '_menu_item_target', ''),
(174, 112, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(175, 112, '_menu_item_xfn', ''),
(176, 112, '_menu_item_url', ''),
(178, 113, '_menu_item_type', 'post_type'),
(179, 113, '_menu_item_menu_item_parent', '0'),
(180, 113, '_menu_item_object_id', '49'),
(181, 113, '_menu_item_object', 'page'),
(182, 113, '_menu_item_target', ''),
(183, 113, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(184, 113, '_menu_item_xfn', ''),
(185, 113, '_menu_item_url', ''),
(187, 114, '_menu_item_type', 'post_type'),
(188, 114, '_menu_item_menu_item_parent', '0'),
(189, 114, '_menu_item_object_id', '75'),
(190, 114, '_menu_item_object', 'page'),
(191, 114, '_menu_item_target', ''),
(192, 114, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(193, 114, '_menu_item_xfn', ''),
(194, 114, '_menu_item_url', ''),
(196, 115, '_menu_item_type', 'post_type'),
(197, 115, '_menu_item_menu_item_parent', '114'),
(198, 115, '_menu_item_object_id', '81'),
(199, 115, '_menu_item_object', 'page'),
(200, 115, '_menu_item_target', ''),
(201, 115, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(202, 115, '_menu_item_xfn', ''),
(203, 115, '_menu_item_url', ''),
(205, 116, '_menu_item_type', 'post_type'),
(206, 116, '_menu_item_menu_item_parent', '114'),
(207, 116, '_menu_item_object_id', '77'),
(208, 116, '_menu_item_object', 'page'),
(209, 116, '_menu_item_target', ''),
(210, 116, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(211, 116, '_menu_item_xfn', ''),
(212, 116, '_menu_item_url', ''),
(214, 117, '_menu_item_type', 'post_type'),
(215, 117, '_menu_item_menu_item_parent', '114'),
(216, 117, '_menu_item_object_id', '79'),
(217, 117, '_menu_item_object', 'page'),
(218, 117, '_menu_item_target', ''),
(219, 117, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(220, 117, '_menu_item_xfn', ''),
(221, 117, '_menu_item_url', ''),
(223, 118, '_menu_item_type', 'post_type'),
(224, 118, '_menu_item_menu_item_parent', '0'),
(225, 118, '_menu_item_object_id', '4'),
(226, 118, '_menu_item_object', 'page'),
(227, 118, '_menu_item_target', ''),
(228, 118, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(229, 118, '_menu_item_xfn', ''),
(230, 118, '_menu_item_url', ''),
(232, 119, '_menu_item_type', 'post_type'),
(233, 119, '_menu_item_menu_item_parent', '118'),
(234, 119, '_menu_item_object_id', '20'),
(235, 119, '_menu_item_object', 'page'),
(236, 119, '_menu_item_target', ''),
(237, 119, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(238, 119, '_menu_item_xfn', ''),
(239, 119, '_menu_item_url', ''),
(241, 120, '_menu_item_type', 'post_type'),
(242, 120, '_menu_item_menu_item_parent', '118'),
(243, 120, '_menu_item_object_id', '26'),
(244, 120, '_menu_item_object', 'page'),
(245, 120, '_menu_item_target', ''),
(246, 120, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(247, 120, '_menu_item_xfn', ''),
(248, 120, '_menu_item_url', ''),
(250, 121, '_menu_item_type', 'post_type'),
(251, 121, '_menu_item_menu_item_parent', '118'),
(252, 121, '_menu_item_object_id', '8'),
(253, 121, '_menu_item_object', 'page'),
(254, 121, '_menu_item_target', ''),
(255, 121, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(256, 121, '_menu_item_xfn', ''),
(257, 121, '_menu_item_url', ''),
(259, 122, '_menu_item_type', 'post_type'),
(260, 122, '_menu_item_menu_item_parent', '118'),
(261, 122, '_menu_item_object_id', '12'),
(262, 122, '_menu_item_object', 'page'),
(263, 122, '_menu_item_target', ''),
(264, 122, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(265, 122, '_menu_item_xfn', ''),
(266, 122, '_menu_item_url', ''),
(268, 123, '_menu_item_type', 'post_type'),
(269, 123, '_menu_item_menu_item_parent', '118'),
(270, 123, '_menu_item_object_id', '10'),
(271, 123, '_menu_item_object', 'page'),
(272, 123, '_menu_item_target', ''),
(273, 123, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(274, 123, '_menu_item_xfn', ''),
(275, 123, '_menu_item_url', ''),
(277, 124, '_menu_item_type', 'post_type'),
(278, 124, '_menu_item_menu_item_parent', '118'),
(279, 124, '_menu_item_object_id', '6'),
(280, 124, '_menu_item_object', 'page'),
(281, 124, '_menu_item_target', ''),
(282, 124, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(283, 124, '_menu_item_xfn', ''),
(284, 124, '_menu_item_url', ''),
(286, 125, '_menu_item_type', 'post_type'),
(287, 125, '_menu_item_menu_item_parent', '118'),
(288, 125, '_menu_item_object_id', '22'),
(289, 125, '_menu_item_object', 'page'),
(290, 125, '_menu_item_target', ''),
(291, 125, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(292, 125, '_menu_item_xfn', ''),
(293, 125, '_menu_item_url', ''),
(295, 126, '_menu_item_type', 'post_type'),
(296, 126, '_menu_item_menu_item_parent', '118'),
(297, 126, '_menu_item_object_id', '24'),
(298, 126, '_menu_item_object', 'page'),
(299, 126, '_menu_item_target', ''),
(300, 126, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(301, 126, '_menu_item_xfn', ''),
(302, 126, '_menu_item_url', ''),
(304, 127, '_menu_item_type', 'post_type'),
(305, 127, '_menu_item_menu_item_parent', '118'),
(306, 127, '_menu_item_object_id', '29'),
(307, 127, '_menu_item_object', 'page'),
(308, 127, '_menu_item_target', ''),
(309, 127, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(310, 127, '_menu_item_xfn', ''),
(311, 127, '_menu_item_url', ''),
(313, 128, '_menu_item_type', 'post_type'),
(314, 128, '_menu_item_menu_item_parent', '118'),
(315, 128, '_menu_item_object_id', '16'),
(316, 128, '_menu_item_object', 'page'),
(317, 128, '_menu_item_target', ''),
(318, 128, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(319, 128, '_menu_item_xfn', ''),
(320, 128, '_menu_item_url', ''),
(322, 129, '_menu_item_type', 'post_type'),
(323, 129, '_menu_item_menu_item_parent', '118') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(324, 129, '_menu_item_object_id', '18'),
(325, 129, '_menu_item_object', 'page'),
(326, 129, '_menu_item_target', ''),
(327, 129, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(328, 129, '_menu_item_xfn', ''),
(329, 129, '_menu_item_url', ''),
(331, 130, '_menu_item_type', 'post_type'),
(332, 130, '_menu_item_menu_item_parent', '118'),
(333, 130, '_menu_item_object_id', '14'),
(334, 130, '_menu_item_object', 'page'),
(335, 130, '_menu_item_target', ''),
(336, 130, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(337, 130, '_menu_item_xfn', ''),
(338, 130, '_menu_item_url', ''),
(340, 131, '_menu_item_type', 'post_type'),
(341, 131, '_menu_item_menu_item_parent', '0'),
(342, 131, '_menu_item_object_id', '102'),
(343, 131, '_menu_item_object', 'page'),
(344, 131, '_menu_item_target', ''),
(345, 131, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(346, 131, '_menu_item_xfn', ''),
(347, 131, '_menu_item_url', ''),
(358, 133, '_menu_item_type', 'post_type'),
(359, 133, '_menu_item_menu_item_parent', '0'),
(360, 133, '_menu_item_object_id', '83'),
(361, 133, '_menu_item_object', 'page'),
(362, 133, '_menu_item_target', ''),
(363, 133, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(364, 133, '_menu_item_xfn', ''),
(365, 133, '_menu_item_url', ''),
(394, 137, '_menu_item_type', 'post_type'),
(395, 137, '_menu_item_menu_item_parent', '0'),
(396, 137, '_menu_item_object_id', '100'),
(397, 137, '_menu_item_object', 'page'),
(398, 137, '_menu_item_target', ''),
(399, 137, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(400, 137, '_menu_item_xfn', ''),
(401, 137, '_menu_item_url', ''),
(412, 139, '_menu_item_type', 'post_type'),
(413, 139, '_menu_item_menu_item_parent', '0'),
(414, 139, '_menu_item_object_id', '31'),
(415, 139, '_menu_item_object', 'page'),
(416, 139, '_menu_item_target', ''),
(417, 139, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(418, 139, '_menu_item_xfn', ''),
(419, 139, '_menu_item_url', ''),
(421, 140, '_menu_item_type', 'post_type'),
(422, 140, '_menu_item_menu_item_parent', '139'),
(423, 140, '_menu_item_object_id', '39'),
(424, 140, '_menu_item_object', 'page'),
(425, 140, '_menu_item_target', ''),
(426, 140, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(427, 140, '_menu_item_xfn', ''),
(428, 140, '_menu_item_url', ''),
(430, 141, '_menu_item_type', 'post_type'),
(431, 141, '_menu_item_menu_item_parent', '139'),
(432, 141, '_menu_item_object_id', '51'),
(433, 141, '_menu_item_object', 'page'),
(434, 141, '_menu_item_target', ''),
(435, 141, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(436, 141, '_menu_item_xfn', ''),
(437, 141, '_menu_item_url', ''),
(439, 142, '_menu_item_type', 'post_type'),
(440, 142, '_menu_item_menu_item_parent', '139'),
(441, 142, '_menu_item_object_id', '55'),
(442, 142, '_menu_item_object', 'page'),
(443, 142, '_menu_item_target', ''),
(444, 142, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(445, 142, '_menu_item_xfn', ''),
(446, 142, '_menu_item_url', ''),
(448, 143, '_menu_item_type', 'post_type'),
(449, 143, '_menu_item_menu_item_parent', '139'),
(450, 143, '_menu_item_object_id', '37'),
(451, 143, '_menu_item_object', 'page'),
(452, 143, '_menu_item_target', ''),
(453, 143, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(454, 143, '_menu_item_xfn', ''),
(455, 143, '_menu_item_url', ''),
(457, 144, '_menu_item_type', 'post_type'),
(458, 144, '_menu_item_menu_item_parent', '139'),
(459, 144, '_menu_item_object_id', '33'),
(460, 144, '_menu_item_object', 'page'),
(461, 144, '_menu_item_target', ''),
(462, 144, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(463, 144, '_menu_item_xfn', ''),
(464, 144, '_menu_item_url', ''),
(466, 145, '_menu_item_type', 'post_type'),
(467, 145, '_menu_item_menu_item_parent', '139'),
(468, 145, '_menu_item_object_id', '43'),
(469, 145, '_menu_item_object', 'page'),
(470, 145, '_menu_item_target', ''),
(471, 145, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(472, 145, '_menu_item_xfn', ''),
(473, 145, '_menu_item_url', ''),
(475, 146, '_menu_item_type', 'post_type'),
(476, 146, '_menu_item_menu_item_parent', '139'),
(477, 146, '_menu_item_object_id', '57'),
(478, 146, '_menu_item_object', 'page'),
(479, 146, '_menu_item_target', ''),
(480, 146, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(481, 146, '_menu_item_xfn', ''),
(482, 146, '_menu_item_url', ''),
(484, 147, '_menu_item_type', 'post_type'),
(485, 147, '_menu_item_menu_item_parent', '139'),
(486, 147, '_menu_item_object_id', '41'),
(487, 147, '_menu_item_object', 'page'),
(488, 147, '_menu_item_target', ''),
(489, 147, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(490, 147, '_menu_item_xfn', ''),
(491, 147, '_menu_item_url', ''),
(493, 148, '_menu_item_type', 'post_type'),
(494, 148, '_menu_item_menu_item_parent', '139'),
(495, 148, '_menu_item_object_id', '59'),
(496, 148, '_menu_item_object', 'page'),
(497, 148, '_menu_item_target', ''),
(498, 148, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(499, 148, '_menu_item_xfn', ''),
(500, 148, '_menu_item_url', ''),
(502, 149, '_menu_item_type', 'post_type'),
(503, 149, '_menu_item_menu_item_parent', '139'),
(504, 149, '_menu_item_object_id', '45'),
(505, 149, '_menu_item_object', 'page'),
(506, 149, '_menu_item_target', ''),
(507, 149, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(508, 149, '_menu_item_xfn', ''),
(509, 149, '_menu_item_url', ''),
(511, 150, '_menu_item_type', 'post_type'),
(512, 150, '_menu_item_menu_item_parent', '139'),
(513, 150, '_menu_item_object_id', '53'),
(514, 150, '_menu_item_object', 'page'),
(515, 150, '_menu_item_target', ''),
(516, 150, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(517, 150, '_menu_item_xfn', ''),
(518, 150, '_menu_item_url', ''),
(520, 151, '_menu_item_type', 'post_type'),
(521, 151, '_menu_item_menu_item_parent', '139'),
(522, 151, '_menu_item_object_id', '94'),
(523, 151, '_menu_item_object', 'page'),
(524, 151, '_menu_item_target', ''),
(525, 151, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(526, 151, '_menu_item_xfn', ''),
(527, 151, '_menu_item_url', ''),
(529, 152, '_menu_item_type', 'post_type'),
(530, 152, '_menu_item_menu_item_parent', '0'),
(531, 152, '_menu_item_object_id', '63'),
(532, 152, '_menu_item_object', 'page'),
(533, 152, '_menu_item_target', ''),
(534, 152, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(535, 152, '_menu_item_xfn', ''),
(536, 152, '_menu_item_url', ''),
(538, 153, '_menu_item_type', 'post_type'),
(539, 153, '_menu_item_menu_item_parent', '152'),
(540, 153, '_menu_item_object_id', '69'),
(541, 153, '_menu_item_object', 'page'),
(542, 153, '_menu_item_target', ''),
(543, 153, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(544, 153, '_menu_item_xfn', ''),
(545, 153, '_menu_item_url', ''),
(547, 154, '_menu_item_type', 'post_type'),
(548, 154, '_menu_item_menu_item_parent', '152'),
(549, 154, '_menu_item_object_id', '71'),
(550, 154, '_menu_item_object', 'page'),
(551, 154, '_menu_item_target', ''),
(552, 154, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(553, 154, '_menu_item_xfn', ''),
(554, 154, '_menu_item_url', ''),
(556, 155, '_menu_item_type', 'post_type'),
(557, 155, '_menu_item_menu_item_parent', '152'),
(558, 155, '_menu_item_object_id', '65'),
(559, 155, '_menu_item_object', 'page'),
(560, 155, '_menu_item_target', ''),
(561, 155, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(562, 155, '_menu_item_xfn', ''),
(563, 155, '_menu_item_url', ''),
(565, 156, '_menu_item_type', 'post_type'),
(566, 156, '_menu_item_menu_item_parent', '152'),
(567, 156, '_menu_item_object_id', '67'),
(568, 156, '_menu_item_object', 'page'),
(569, 156, '_menu_item_target', ''),
(570, 156, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(571, 156, '_menu_item_xfn', ''),
(572, 156, '_menu_item_url', ''),
(574, 157, '_menu_item_type', 'post_type'),
(575, 157, '_menu_item_menu_item_parent', '152'),
(576, 157, '_menu_item_object_id', '73'),
(577, 157, '_menu_item_object', 'page'),
(578, 157, '_menu_item_target', ''),
(579, 157, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(580, 157, '_menu_item_xfn', ''),
(581, 157, '_menu_item_url', ''),
(583, 158, '_menu_item_type', 'post_type'),
(584, 158, '_menu_item_menu_item_parent', '0'),
(585, 158, '_menu_item_object_id', '91'),
(586, 158, '_menu_item_object', 'page'),
(587, 158, '_menu_item_target', ''),
(588, 158, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(589, 158, '_menu_item_xfn', ''),
(590, 158, '_menu_item_url', ''),
(592, 159, '_menu_item_type', 'post_type'),
(593, 159, '_menu_item_menu_item_parent', '139') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(594, 159, '_menu_item_object_id', '35'),
(595, 159, '_menu_item_object', 'page'),
(596, 159, '_menu_item_target', ''),
(597, 159, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(598, 159, '_menu_item_xfn', ''),
(599, 159, '_menu_item_url', ''),
(601, 160, '_menu_item_type', 'post_type'),
(602, 160, '_menu_item_menu_item_parent', '139'),
(603, 160, '_menu_item_object_id', '47'),
(604, 160, '_menu_item_object', 'page'),
(605, 160, '_menu_item_target', ''),
(606, 160, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(607, 160, '_menu_item_xfn', ''),
(608, 160, '_menu_item_url', ''),
(610, 161, '_edit_last', '1'),
(611, 161, '_edit_lock', '1463771626:1'),
(612, 163, '_edit_last', '1'),
(613, 163, '_edit_lock', '1463771674:1'),
(614, 165, '_edit_last', '1'),
(615, 165, '_edit_lock', '1463771740:1'),
(616, 167, '_edit_last', '1'),
(617, 167, '_edit_lock', '1463771804:1'),
(618, 169, '_menu_item_type', 'post_type'),
(619, 169, '_menu_item_menu_item_parent', '0'),
(620, 169, '_menu_item_object_id', '108'),
(621, 169, '_menu_item_object', 'page'),
(622, 169, '_menu_item_target', ''),
(623, 169, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(624, 169, '_menu_item_xfn', ''),
(625, 169, '_menu_item_url', ''),
(663, 174, '_menu_item_type', 'post_type'),
(664, 174, '_menu_item_menu_item_parent', '0'),
(665, 174, '_menu_item_object_id', '104'),
(666, 174, '_menu_item_object', 'page'),
(667, 174, '_menu_item_target', ''),
(668, 174, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(669, 174, '_menu_item_xfn', ''),
(670, 174, '_menu_item_url', ''),
(672, 175, '_menu_item_type', 'post_type'),
(673, 175, '_menu_item_menu_item_parent', '0'),
(674, 175, '_menu_item_object_id', '85'),
(675, 175, '_menu_item_object', 'page'),
(676, 175, '_menu_item_target', ''),
(677, 175, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(678, 175, '_menu_item_xfn', ''),
(679, 175, '_menu_item_url', ''),
(681, 177, '_menu_item_type', 'custom'),
(682, 177, '_menu_item_menu_item_parent', '0'),
(683, 177, '_menu_item_object_id', '177'),
(684, 177, '_menu_item_object', 'custom'),
(685, 177, '_menu_item_target', ''),
(686, 177, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(687, 177, '_menu_item_xfn', ''),
(688, 177, '_menu_item_url', ''),
(690, 178, '_edit_last', '1'),
(691, 178, '_wp_page_template', 'page-about.php'),
(692, 178, '_yoast_wpseo_content_score', '60'),
(693, 178, '_edit_lock', '1470118182:1'),
(694, 180, '_menu_item_type', 'post_type'),
(695, 180, '_menu_item_menu_item_parent', '0'),
(696, 180, '_menu_item_object_id', '178'),
(697, 180, '_menu_item_object', 'page'),
(698, 180, '_menu_item_target', ''),
(699, 180, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(700, 180, '_menu_item_xfn', ''),
(701, 180, '_menu_item_url', ''),
(712, 182, '_menu_item_type', 'post_type'),
(713, 182, '_menu_item_menu_item_parent', '177'),
(714, 182, '_menu_item_object_id', '39'),
(715, 182, '_menu_item_object', 'page'),
(716, 182, '_menu_item_target', ''),
(717, 182, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(718, 182, '_menu_item_xfn', ''),
(719, 182, '_menu_item_url', ''),
(721, 183, '_menu_item_type', 'post_type'),
(722, 183, '_menu_item_menu_item_parent', '177'),
(723, 183, '_menu_item_object_id', '51'),
(724, 183, '_menu_item_object', 'page'),
(725, 183, '_menu_item_target', ''),
(726, 183, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(727, 183, '_menu_item_xfn', ''),
(728, 183, '_menu_item_url', ''),
(730, 184, '_menu_item_type', 'post_type'),
(731, 184, '_menu_item_menu_item_parent', '177'),
(732, 184, '_menu_item_object_id', '55'),
(733, 184, '_menu_item_object', 'page'),
(734, 184, '_menu_item_target', ''),
(735, 184, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(736, 184, '_menu_item_xfn', ''),
(737, 184, '_menu_item_url', ''),
(739, 185, '_menu_item_type', 'post_type'),
(740, 185, '_menu_item_menu_item_parent', '177'),
(741, 185, '_menu_item_object_id', '37'),
(742, 185, '_menu_item_object', 'page'),
(743, 185, '_menu_item_target', ''),
(744, 185, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(745, 185, '_menu_item_xfn', ''),
(746, 185, '_menu_item_url', ''),
(748, 186, '_menu_item_type', 'post_type'),
(749, 186, '_menu_item_menu_item_parent', '177') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(750, 186, '_menu_item_object_id', '33'),
(751, 186, '_menu_item_object', 'page'),
(752, 186, '_menu_item_target', ''),
(753, 186, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(754, 186, '_menu_item_xfn', ''),
(755, 186, '_menu_item_url', ''),
(757, 187, '_menu_item_type', 'post_type'),
(758, 187, '_menu_item_menu_item_parent', '177'),
(759, 187, '_menu_item_object_id', '43'),
(760, 187, '_menu_item_object', 'page'),
(761, 187, '_menu_item_target', ''),
(762, 187, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(763, 187, '_menu_item_xfn', ''),
(764, 187, '_menu_item_url', ''),
(766, 188, '_menu_item_type', 'post_type'),
(767, 188, '_menu_item_menu_item_parent', '177'),
(768, 188, '_menu_item_object_id', '57'),
(769, 188, '_menu_item_object', 'page'),
(770, 188, '_menu_item_target', ''),
(771, 188, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(772, 188, '_menu_item_xfn', ''),
(773, 188, '_menu_item_url', ''),
(775, 189, '_menu_item_type', 'post_type'),
(776, 189, '_menu_item_menu_item_parent', '208'),
(777, 189, '_menu_item_object_id', '41'),
(778, 189, '_menu_item_object', 'page'),
(779, 189, '_menu_item_target', ''),
(780, 189, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(781, 189, '_menu_item_xfn', ''),
(782, 189, '_menu_item_url', ''),
(784, 190, '_menu_item_type', 'post_type'),
(785, 190, '_menu_item_menu_item_parent', '208'),
(786, 190, '_menu_item_object_id', '59'),
(787, 190, '_menu_item_object', 'page'),
(788, 190, '_menu_item_target', ''),
(789, 190, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(790, 190, '_menu_item_xfn', ''),
(791, 190, '_menu_item_url', ''),
(793, 191, '_menu_item_type', 'post_type'),
(794, 191, '_menu_item_menu_item_parent', '208'),
(795, 191, '_menu_item_object_id', '45'),
(796, 191, '_menu_item_object', 'page'),
(797, 191, '_menu_item_target', ''),
(798, 191, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(799, 191, '_menu_item_xfn', ''),
(800, 191, '_menu_item_url', ''),
(802, 192, '_menu_item_type', 'post_type'),
(803, 192, '_menu_item_menu_item_parent', '208'),
(804, 192, '_menu_item_object_id', '53'),
(805, 192, '_menu_item_object', 'page'),
(806, 192, '_menu_item_target', ''),
(807, 192, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(808, 192, '_menu_item_xfn', ''),
(809, 192, '_menu_item_url', ''),
(820, 194, '_menu_item_type', 'post_type'),
(821, 194, '_menu_item_menu_item_parent', '208'),
(822, 194, '_menu_item_object_id', '20'),
(823, 194, '_menu_item_object', 'page'),
(824, 194, '_menu_item_target', ''),
(825, 194, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(826, 194, '_menu_item_xfn', ''),
(827, 194, '_menu_item_url', ''),
(829, 195, '_menu_item_type', 'post_type'),
(830, 195, '_menu_item_menu_item_parent', '208'),
(831, 195, '_menu_item_object_id', '26'),
(832, 195, '_menu_item_object', 'page'),
(833, 195, '_menu_item_target', ''),
(834, 195, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(835, 195, '_menu_item_xfn', ''),
(836, 195, '_menu_item_url', ''),
(838, 196, '_menu_item_type', 'post_type'),
(839, 196, '_menu_item_menu_item_parent', '208'),
(840, 196, '_menu_item_object_id', '8'),
(841, 196, '_menu_item_object', 'page'),
(842, 196, '_menu_item_target', ''),
(843, 196, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(844, 196, '_menu_item_xfn', ''),
(845, 196, '_menu_item_url', ''),
(847, 197, '_menu_item_type', 'post_type'),
(848, 197, '_menu_item_menu_item_parent', '208'),
(849, 197, '_menu_item_object_id', '12'),
(850, 197, '_menu_item_object', 'page'),
(851, 197, '_menu_item_target', ''),
(852, 197, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(853, 197, '_menu_item_xfn', ''),
(854, 197, '_menu_item_url', ''),
(856, 198, '_menu_item_type', 'post_type'),
(857, 198, '_menu_item_menu_item_parent', '208'),
(858, 198, '_menu_item_object_id', '10'),
(859, 198, '_menu_item_object', 'page'),
(860, 198, '_menu_item_target', ''),
(861, 198, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(862, 198, '_menu_item_xfn', ''),
(863, 198, '_menu_item_url', ''),
(865, 199, '_menu_item_type', 'post_type'),
(866, 199, '_menu_item_menu_item_parent', '208'),
(867, 199, '_menu_item_object_id', '6'),
(868, 199, '_menu_item_object', 'page'),
(869, 199, '_menu_item_target', ''),
(870, 199, '_menu_item_classes', 'a:1:{i:0;s:0:"";}') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(871, 199, '_menu_item_xfn', ''),
(872, 199, '_menu_item_url', ''),
(874, 200, '_menu_item_type', 'post_type'),
(875, 200, '_menu_item_menu_item_parent', '208'),
(876, 200, '_menu_item_object_id', '22'),
(877, 200, '_menu_item_object', 'page'),
(878, 200, '_menu_item_target', ''),
(879, 200, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(880, 200, '_menu_item_xfn', ''),
(881, 200, '_menu_item_url', ''),
(883, 201, '_menu_item_type', 'post_type'),
(884, 201, '_menu_item_menu_item_parent', '208'),
(885, 201, '_menu_item_object_id', '24'),
(886, 201, '_menu_item_object', 'page'),
(887, 201, '_menu_item_target', ''),
(888, 201, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(889, 201, '_menu_item_xfn', ''),
(890, 201, '_menu_item_url', ''),
(892, 202, '_menu_item_type', 'post_type'),
(893, 202, '_menu_item_menu_item_parent', '208'),
(894, 202, '_menu_item_object_id', '29'),
(895, 202, '_menu_item_object', 'page'),
(896, 202, '_menu_item_target', ''),
(897, 202, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(898, 202, '_menu_item_xfn', ''),
(899, 202, '_menu_item_url', ''),
(901, 203, '_menu_item_type', 'post_type'),
(902, 203, '_menu_item_menu_item_parent', '208'),
(903, 203, '_menu_item_object_id', '16'),
(904, 203, '_menu_item_object', 'page'),
(905, 203, '_menu_item_target', ''),
(906, 203, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(907, 203, '_menu_item_xfn', ''),
(908, 203, '_menu_item_url', ''),
(910, 204, '_menu_item_type', 'post_type'),
(911, 204, '_menu_item_menu_item_parent', '208'),
(912, 204, '_menu_item_object_id', '18'),
(913, 204, '_menu_item_object', 'page'),
(914, 204, '_menu_item_target', ''),
(915, 204, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(916, 204, '_menu_item_xfn', ''),
(917, 204, '_menu_item_url', ''),
(919, 205, '_menu_item_type', 'post_type'),
(920, 205, '_menu_item_menu_item_parent', '208'),
(921, 205, '_menu_item_object_id', '14'),
(922, 205, '_menu_item_object', 'page'),
(923, 205, '_menu_item_target', ''),
(924, 205, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(925, 205, '_menu_item_xfn', ''),
(926, 205, '_menu_item_url', ''),
(928, 206, '_menu_item_type', 'post_type'),
(929, 206, '_menu_item_menu_item_parent', '0'),
(930, 206, '_menu_item_object_id', '4'),
(931, 206, '_menu_item_object', 'page'),
(932, 206, '_menu_item_target', ''),
(933, 206, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(934, 206, '_menu_item_xfn', ''),
(935, 206, '_menu_item_url', ''),
(936, 206, '_menu_item_orphaned', '1468444891'),
(937, 207, '_menu_item_type', 'post_type'),
(938, 207, '_menu_item_menu_item_parent', '208'),
(939, 207, '_menu_item_object_id', '4'),
(940, 207, '_menu_item_object', 'page'),
(941, 207, '_menu_item_target', ''),
(942, 207, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(943, 207, '_menu_item_xfn', ''),
(944, 207, '_menu_item_url', ''),
(946, 208, '_menu_item_type', 'custom'),
(947, 208, '_menu_item_menu_item_parent', '177'),
(948, 208, '_menu_item_object_id', '208'),
(949, 208, '_menu_item_object', 'custom'),
(950, 208, '_menu_item_target', ''),
(951, 208, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(952, 208, '_menu_item_xfn', ''),
(953, 208, '_menu_item_url', ''),
(955, 209, '_menu_item_type', 'custom'),
(956, 209, '_menu_item_menu_item_parent', '177'),
(957, 209, '_menu_item_object_id', '209'),
(958, 209, '_menu_item_object', 'custom'),
(959, 209, '_menu_item_target', ''),
(960, 209, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(961, 209, '_menu_item_xfn', ''),
(962, 209, '_menu_item_url', ''),
(964, 210, '_menu_item_type', 'post_type'),
(965, 210, '_menu_item_menu_item_parent', '209'),
(966, 210, '_menu_item_object_id', '63'),
(967, 210, '_menu_item_object', 'page'),
(968, 210, '_menu_item_target', ''),
(969, 210, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(970, 210, '_menu_item_xfn', ''),
(971, 210, '_menu_item_url', ''),
(973, 211, '_menu_item_type', 'post_type'),
(974, 211, '_menu_item_menu_item_parent', '209'),
(975, 211, '_menu_item_object_id', '69'),
(976, 211, '_menu_item_object', 'page'),
(977, 211, '_menu_item_target', ''),
(978, 211, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(979, 211, '_menu_item_xfn', ''),
(980, 211, '_menu_item_url', ''),
(982, 212, '_menu_item_type', 'post_type') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(983, 212, '_menu_item_menu_item_parent', '209'),
(984, 212, '_menu_item_object_id', '71'),
(985, 212, '_menu_item_object', 'page'),
(986, 212, '_menu_item_target', ''),
(987, 212, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(988, 212, '_menu_item_xfn', ''),
(989, 212, '_menu_item_url', ''),
(991, 213, '_menu_item_type', 'post_type'),
(992, 213, '_menu_item_menu_item_parent', '209'),
(993, 213, '_menu_item_object_id', '73'),
(994, 213, '_menu_item_object', 'page'),
(995, 213, '_menu_item_target', ''),
(996, 213, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(997, 213, '_menu_item_xfn', ''),
(998, 213, '_menu_item_url', ''),
(1000, 214, '_menu_item_type', 'post_type'),
(1001, 214, '_menu_item_menu_item_parent', '209'),
(1002, 214, '_menu_item_object_id', '67'),
(1003, 214, '_menu_item_object', 'page'),
(1004, 214, '_menu_item_target', ''),
(1005, 214, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(1006, 214, '_menu_item_xfn', ''),
(1007, 214, '_menu_item_url', ''),
(1009, 215, '_menu_item_type', 'post_type'),
(1010, 215, '_menu_item_menu_item_parent', '209'),
(1011, 215, '_menu_item_object_id', '65'),
(1012, 215, '_menu_item_object', 'page'),
(1013, 215, '_menu_item_target', ''),
(1014, 215, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(1015, 215, '_menu_item_xfn', ''),
(1016, 215, '_menu_item_url', ''),
(1072, 222, '_menu_item_type', 'post_type'),
(1073, 222, '_menu_item_menu_item_parent', '228'),
(1074, 222, '_menu_item_object_id', '100'),
(1075, 222, '_menu_item_object', 'page'),
(1076, 222, '_menu_item_target', ''),
(1077, 222, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(1078, 222, '_menu_item_xfn', ''),
(1079, 222, '_menu_item_url', ''),
(1081, 223, '_menu_item_type', 'post_type'),
(1082, 223, '_menu_item_menu_item_parent', '228'),
(1083, 223, '_menu_item_object_id', '98'),
(1084, 223, '_menu_item_object', 'page'),
(1085, 223, '_menu_item_target', ''),
(1086, 223, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(1087, 223, '_menu_item_xfn', ''),
(1088, 223, '_menu_item_url', ''),
(1090, 224, '_menu_item_type', 'post_type'),
(1091, 224, '_menu_item_menu_item_parent', '228'),
(1092, 224, '_menu_item_object_id', '96'),
(1093, 224, '_menu_item_object', 'page'),
(1094, 224, '_menu_item_target', ''),
(1095, 224, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(1096, 224, '_menu_item_xfn', ''),
(1097, 224, '_menu_item_url', ''),
(1117, 228, '_menu_item_type', 'custom'),
(1118, 228, '_menu_item_menu_item_parent', '0'),
(1119, 228, '_menu_item_object_id', '228'),
(1120, 228, '_menu_item_object', 'custom'),
(1121, 228, '_menu_item_target', ''),
(1122, 228, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(1123, 228, '_menu_item_xfn', ''),
(1124, 228, '_menu_item_url', ''),
(1126, 229, '_menu_item_type', 'post_type'),
(1127, 229, '_menu_item_menu_item_parent', '0'),
(1128, 229, '_menu_item_object_id', '106'),
(1129, 229, '_menu_item_object', 'page'),
(1130, 229, '_menu_item_target', ''),
(1131, 229, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(1132, 229, '_menu_item_xfn', ''),
(1133, 229, '_menu_item_url', ''),
(1135, 230, '_edit_last', '1'),
(1136, 230, '_wp_page_template', 'default'),
(1137, 230, '_yoast_wpseo_content_score', '30'),
(1138, 230, '_edit_lock', '1468968629:1'),
(1139, 232, '_menu_item_type', 'post_type'),
(1140, 232, '_menu_item_menu_item_parent', '0'),
(1141, 232, '_menu_item_object_id', '230'),
(1142, 232, '_menu_item_object', 'page'),
(1143, 232, '_menu_item_target', ''),
(1144, 232, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(1145, 232, '_menu_item_xfn', ''),
(1146, 232, '_menu_item_url', '') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=MyISAM AUTO_INCREMENT=238 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2016-05-20 17:38:50', '2016-05-20 17:38:50', 'Welcome to WordPress. This is your first post. Edit or delete it, then start writing!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2016-05-20 17:38:50', '2016-05-20 17:38:50', '', 0, 'http://tedsmithdemo.com/?p=1', 0, 'post', '', 1),
(4, 1, '2016-05-20 17:45:45', '2016-05-20 17:45:45', 'The legal practice of family law is as unique as the families our attorneys serve. American families come in many shapes and sizes. When you run into difficulties, you need a representative who can deliver creative solutions that help you move forward with your life.\r\n\r\nAt the Ted Smith Law Group, PLLC, our family law practice focuses on legal matters including divorce, custody and visitation, child support, spousal support, and adoption. Every state approaches family matters differently. Whether you’ve only lived in Texas for a short while or you’ve lived here your entire life, our attorneys are ready to guide you through the legal system.\r\n<h2>Why Ted Smith Law Group, PLLC, Is Different</h2>\r\nFamily law is a particularly delicate category of legal work that requires not only legal expertise, but also compassion and support. Strong emotions often play a role in these cases, and outcomes can help families build bridges or burn them. Our attorneys understand the implications of every legal case, beyond obtaining legal reconciliation. Your dedicated attorney will help you understand state laws and make informed decisions about your future along the way.\r\n\r\nWe believe that straightforward answers best serve our clients. Allow us to become your go-to advocate in cases including:\r\n<ul>\r\n 	<li>Divorce and military divorce</li>\r\n 	<li>Property division</li>\r\n 	<li>Spousal support/alimony</li>\r\n 	<li>Child custody</li>\r\n 	<li>Child support</li>\r\n 	<li>Order modifications</li>\r\n 	<li>Paternity</li>\r\n 	<li>Adoption</li>\r\n 	<li>Fathers’ rights</li>\r\n 	<li>Grandparents’ rights</li>\r\n</ul>\r\nWith a strong legal advisor assisting you along the way, you can obtain a successful resolution to your case. One hallmark of a great family law attorney is the ability to expedite the process, so you can get back to your life without further disruption.\r\n<h2>Do I Need an Attorney for Family Law Matters?</h2>\r\nAt first, many individuals believe they can handle family law matters without the assistance of a legal expert. We recommend consulting an attorney regardless of the previous relationship you’ve had with family members. Having an attorney is a way to prepare and protect yourself from any difficulties or surprises. Texas law involves strict timeframes and nuanced statutes that each party must consider during the course of legal action.\r\n\r\nFor child custody and rights issues, your attorney will play an instrumental role in protecting your rights as a parent or guardian in front of conflicting parties and the state justice system. During family law matters, those involved can expect their lives to fall under the strict scrutiny of the courts. In today’s world, something as seemingly innocent as a social media post could tip the balance of legal decisions.\r\n<h2>When to Contact an Attorney for Assistance</h2>\r\nIn some cases, you will contact an attorney reactively, after you have been served with a divorce notice or another legal document. In others, you may reach out to your attorney in anticipation of filing for custody, adoption, or divorce. Reach out to an attorney at Ted Smith Law Group, PLLC, whenever you have questions regarding your legal situation. After a free consultation, you can decide if our team of legal experts is the right fit for your needs.\r\n\r\nYour attorney will not only provide guidance before and during a legal proceeding; he or she may play a role long after an initial case settles. For instance, custody and visitation rights often go back to court over time for modification. Choose an attorney you can trust to put your best interests first as your family learns how to manage life in a new legal structure.\r\n\r\nWhether you’re trying to work out school district boundaries during a divorce or trying to obtain rights to see your grandchild, our attorneys are ready to assist you. Don’t wait until a family challenge overwhelms. Let our firm make the process less stressful. <a href="/contact/">Contact us today</a> to schedule your free case evaluation.', 'Family Law', '', 'publish', 'closed', 'closed', '', 'family-law', '', '', '2016-05-20 17:45:45', '2016-05-20 17:45:45', '', 0, 'http://tedsmithdemo.com/?page_id=4', 0, 'page', '', 0),
(5, 1, '2016-05-20 17:45:45', '2016-05-20 17:45:45', 'The legal practice of family law is as unique as the families our attorneys serve. American families come in many shapes and sizes. When you run into difficulties, you need a representative who can deliver creative solutions that help you move forward with your life.\r\n\r\nAt the Ted Smith Law Group, PLLC, our family law practice focuses on legal matters including divorce, custody and visitation, child support, spousal support, and adoption. Every state approaches family matters differently. Whether you’ve only lived in Texas for a short while or you’ve lived here your entire life, our attorneys are ready to guide you through the legal system.\r\n<h2>Why Ted Smith Law Group, PLLC, Is Different</h2>\r\nFamily law is a particularly delicate category of legal work that requires not only legal expertise, but also compassion and support. Strong emotions often play a role in these cases, and outcomes can help families build bridges or burn them. Our attorneys understand the implications of every legal case, beyond obtaining legal reconciliation. Your dedicated attorney will help you understand state laws and make informed decisions about your future along the way.\r\n\r\nWe believe that straightforward answers best serve our clients. Allow us to become your go-to advocate in cases including:\r\n<ul>\r\n 	<li>Divorce and military divorce</li>\r\n 	<li>Property division</li>\r\n 	<li>Spousal support/alimony</li>\r\n 	<li>Child custody</li>\r\n 	<li>Child support</li>\r\n 	<li>Order modifications</li>\r\n 	<li>Paternity</li>\r\n 	<li>Adoption</li>\r\n 	<li>Fathers’ rights</li>\r\n 	<li>Grandparents’ rights</li>\r\n</ul>\r\nWith a strong legal advisor assisting you along the way, you can obtain a successful resolution to your case. One hallmark of a great family law attorney is the ability to expedite the process, so you can get back to your life without further disruption.\r\n<h2>Do I Need an Attorney for Family Law Matters?</h2>\r\nAt first, many individuals believe they can handle family law matters without the assistance of a legal expert. We recommend consulting an attorney regardless of the previous relationship you’ve had with family members. Having an attorney is a way to prepare and protect yourself from any difficulties or surprises. Texas law involves strict timeframes and nuanced statutes that each party must consider during the course of legal action.\r\n\r\nFor child custody and rights issues, your attorney will play an instrumental role in protecting your rights as a parent or guardian in front of conflicting parties and the state justice system. During family law matters, those involved can expect their lives to fall under the strict scrutiny of the courts. In today’s world, something as seemingly innocent as a social media post could tip the balance of legal decisions.\r\n<h2>When to Contact an Attorney for Assistance</h2>\r\nIn some cases, you will contact an attorney reactively, after you have been served with a divorce notice or another legal document. In others, you may reach out to your attorney in anticipation of filing for custody, adoption, or divorce. Reach out to an attorney at Ted Smith Law Group, PLLC, whenever you have questions regarding your legal situation. After a free consultation, you can decide if our team of legal experts is the right fit for your needs.\r\n\r\nYour attorney will not only provide guidance before and during a legal proceeding; he or she may play a role long after an initial case settles. For instance, custody and visitation rights often go back to court over time for modification. Choose an attorney you can trust to put your best interests first as your family learns how to manage life in a new legal structure.\r\n\r\nWhether you’re trying to work out school district boundaries during a divorce or trying to obtain rights to see your grandchild, our attorneys are ready to assist you. Don’t wait until a family challenge overwhelms. Let our firm make the process less stressful. <a href="/contact/">Contact us today</a> to schedule your free case evaluation.', 'Family Law', '', 'inherit', 'closed', 'closed', '', '4-revision-v1', '', '', '2016-05-20 17:45:45', '2016-05-20 17:45:45', '', 4, 'http://tedsmithdemo.com/2016/05/20/4-revision-v1/', 0, 'revision', '', 0),
(6, 1, '2016-05-20 17:48:43', '2016-05-20 17:48:43', 'Divorce plays an instrumental role in helping two people move forward and find happiness after a difficult marriage. You may have several questions about what your life might look like if you decide to divorce in Texas. We can answer your questions and help you start the process. The Ted Smith Law Group, PLLC is dedicated to protecting civilian and military married individuals’ lives and helping them rediscover independence.\r\n<h2>Fault and No-Fault Divorce in Texas</h2>\r\nSome states look at all divorces as no-fault. The Texas justice system recognizes both no-fault and at-fault divorces. No-fault divorces are those that take place because two individuals cannot reconcile their differences (insupportability) or have lived apart for three or more years.\r\n\r\nFault divorces arise when one party proves that the other is no longer fit to participate in the marriage. Grounds for fault divorces include cruelty, abandonment, felony convictions, adultery, and mental hospital confinement. Most divorce cases fall under the category of insupportability.\r\n<h2>The Divorce Process in Texas</h2>\r\nTo begin the process for a divorce, one spouse must create and file a Petition for Divorce. The petitioner (person initiating the divorce) should make two copies of the document and file it at the local courthouse. The courthouse clerk will stamp your documentation and assign the case a number and court district. The respondent (other spouse) must receive a stamped copy of the petition and respond to the court within 20 days of receiving the petition.\r\n\r\nA respondent can accept the terms of a divorce or contest them. Contested divorces often go to court, where the court will decide the ultimate terms of the divorce. These cases are more expensive and may take more time. You will need an attorney to protect your rights during a contested case.\r\n\r\nUncontested divorces require two ex-spouses to work together to compromise on the terms of a divorce. Unless you fully understand the terms that you are agreeing to in an uncontested divorce, we highly recommend seeking legal counsel to review your agreement before finalizing the terms.\r\n<h2>Elements of Separation in a Texas Divorce</h2>\r\nWhen two people marry, they combine lives in every sense of the word. When they decide to divorce, they (or the courts) must divide shared assets and rights before finalizing the divorce. Trying to agree on the terms of the divorce can be emotionally upsetting and the most difficult part of the process.\r\n\r\nThe elements that couples must determine include:\r\n<ul>\r\n 	<li>Property division. Assets a couple obtains during marriage are shared property. Each individual is entitled to a fair division of shared property, including debt, financial assets, real estate, pension plans, and physical property. Separate property, property that an individual had before marriage or after separation, almost always goes back to the original owner.</li>\r\n</ul>\r\n<ul>\r\n 	<li>Spousal support/alimony. In many marriages, one spouse may forego a career in favor of taking care of the home and children. In these cases, a supported spouse needs transitional support after divorce.</li>\r\n</ul>\r\n<ul>\r\n 	<li>Child custody. Child custody is particularly difficult for spouses who cannot compromise on the terms. Depending on the circumstances of a case, two parents may share joint custody, or one may have full custody and the other may have visitation rights.</li>\r\n</ul>\r\n<h2>Finding a Divorce Lawyer in Texas</h2>\r\nYour divorce attorney is more than a legal advisor. Throughout the process, he or she will help you understand your rights and the future implications of certain decisions. Our firm strives to provide each client with accessible support before, during, and after a divorce proceeding. For matters in family law, our compassionate attorneys are here to protect yours and your children’s futures. <a href="/contact/">Contact us today</a> for a free case evaluation.', 'Divorce', '', 'publish', 'closed', 'closed', '', 'divorce', '', '', '2016-05-20 17:57:43', '2016-05-20 17:57:43', '', 4, 'http://tedsmithdemo.com/?page_id=6', 0, 'page', '', 0),
(7, 1, '2016-05-20 17:48:43', '2016-05-20 17:48:43', 'Divorce plays an instrumental role in helping two people move forward and find happiness after a difficult marriage. You may have several questions about what your life might look like if you decide to divorce in Texas. We can answer your questions and help you start the process. The Ted Smith Law Group, PLLC is dedicated to protecting civilian and military married individuals’ lives and helping them rediscover independence.\r\n<h2>Fault and No-Fault Divorce in Texas</h2>\r\nSome states look at all divorces as no-fault. The Texas justice system recognizes both no-fault and at-fault divorces. No-fault divorces are those that take place because two individuals cannot reconcile their differences (insupportability) or have lived apart for three or more years.\r\n\r\nFault divorces arise when one party proves that the other is no longer fit to participate in the marriage. Grounds for fault divorces include cruelty, abandonment, felony convictions, adultery, and mental hospital confinement. Most divorce cases fall under the category of insupportability.\r\n<h2>The Divorce Process in Texas</h2>\r\nTo begin the process for a divorce, one spouse must create and file a Petition for Divorce. The petitioner (person initiating the divorce) should make two copies of the document and file it at the local courthouse. The courthouse clerk will stamp your documentation and assign the case a number and court district. The respondent (other spouse) must receive a stamped copy of the petition and respond to the court within 20 days of receiving the petition.\r\n\r\nA respondent can accept the terms of a divorce or contest them. Contested divorces often go to court, where the court will decide the ultimate terms of the divorce. These cases are more expensive and may take more time. You will need an attorney to protect your rights during a contested case.\r\n\r\nUncontested divorces require two ex-spouses to work together to compromise on the terms of a divorce. Unless you fully understand the terms that you are agreeing to in an uncontested divorce, we highly recommend seeking legal counsel to review your agreement before finalizing the terms.\r\n<h2>Elements of Separation in a Texas Divorce</h2>\r\nWhen two people marry, they combine lives in every sense of the word. When they decide to divorce, they (or the courts) must divide shared assets and rights before finalizing the divorce. Trying to agree on the terms of the divorce can be emotionally upsetting and the most difficult part of the process.\r\n\r\nThe elements that couples must determine include:\r\n<ul>\r\n 	<li>Property division. Assets a couple obtains during marriage are shared property. Each individual is entitled to a fair division of shared property, including debt, financial assets, real estate, pension plans, and physical property. Separate property, property that an individual had before marriage or after separation, almost always goes back to the original owner.</li>\r\n</ul>\r\n<ul>\r\n 	<li>Spousal support/alimony. In many marriages, one spouse may forego a career in favor of taking care of the home and children. In these cases, a supported spouse needs transitional support after divorce.</li>\r\n</ul>\r\n<ul>\r\n 	<li>Child custody. Child custody is particularly difficult for spouses who cannot compromise on the terms. Depending on the circumstances of a case, two parents may share joint custody, or one may have full custody and the other may have visitation rights.</li>\r\n</ul>\r\n<h2>Finding a Divorce Lawyer in Texas</h2>\r\nYour divorce attorney is more than a legal advisor. Throughout the process, he or she will help you understand your rights and the future implications of certain decisions. Our firm strives to provide each client with accessible support before, during, and after a divorce proceeding. For matters in family law, our compassionate attorneys are here to protect yours and your children’s futures. <a href="/contact/">Contact us today</a> for a free case evaluation.', 'Divorce', '', 'inherit', 'closed', 'closed', '', '6-revision-v1', '', '', '2016-05-20 17:48:43', '2016-05-20 17:48:43', '', 6, 'http://tedsmithdemo.com/6-revision-v1/', 0, 'revision', '', 0),
(8, 1, '2016-05-20 17:49:26', '2016-05-20 17:49:26', 'During and after a divorce, child custody affects the role of a parent in the life of a child. The process of determining custody is often emotional, and you may need the support of an experienced legal counselor to reach a satisfactory arrangement. At Ted Smith Law Group, PLLC, we understand that child custody battles can affect a parent’s relationship with a child. We are here to help you understand Texas laws and choose an arrangement that is most beneficial for you and your child.\r\n<h2>Child Custody in Texas</h2>\r\nIn Texas, the legal term for custody is “conservatorship.” A parent may share custody with the other parent in a joint managing conservatorship, or one parent may obtain full custody in a sole managing conservatorship.\r\n\r\nConservatorship is always determined on the standard of the best interest of the child. Financial responsibility, prior caretaking responsibilities, the child’s preference, an ability to respect the other parent, and a child’s physical, emotional, and psychological needs all play a role in determining custody arrangements.\r\n<h2>Rights of Conservatorships</h2>\r\nThe rights of a parent awarded during conservatorship proceedings include:\r\n<ul>\r\n 	<li>The ability to obtain professional records regarding the child</li>\r\n 	<li>The ability to speak to a physician and make decisions about a child’s health care</li>\r\n 	<li>The ability to obtain information about the child’s physical, educational, and emotional well-being from the other parent</li>\r\n 	<li>The ability to speak to educators and make decisions about school activities and educational goals</li>\r\n</ul>\r\nIn a joint managing conservatorship, both parents may have equal parenting rights, or the courts may assign exclusive rights to one parent or the other. In a sole managing conservatorship, one parent has full parental rights, including:\r\n<ul>\r\n 	<li>The ability to receive child support</li>\r\n 	<li>Giving consent and making decisions regarding health care treatment and education</li>\r\n 	<li>Attending school and extracurricular activities</li>\r\n 	<li>Deciding where a child lives, primarily</li>\r\n 	<li>Being the first person contacted during emergencies</li>\r\n</ul>\r\n&nbsp;\r\n\r\nThe court may make a sole conservatorship determination if the other parent is unfit to hold custody rights in some way. A history of violence, neglect, drug/alcohol use, criminal activity, prolonged absences, and irreconcilable belief differences may all affect how the courts award custody in Texas.\r\n<h2>Possession and Access</h2>\r\nCustody rights primarily determine the legal rights of a parent, not how often a parent can see or spend time with a child. After the courts award conservatorship, the parents must agree to the terms of a visitation schedule. Even parents with sole managing conservatorship rights may need to allow for routine visitation with the other parent. If the parents cannot determine a schedule for holiday visitation and living circumstances, the courts may decide for them.\r\n<h2>Determining Child Support</h2>\r\nChild custody goes hand in hand with child support. The parent a child does not live with is responsible for providing for a child, financially, until he or she turns 18 or until an age determined by the courts. Child support is determined based on financial means and certain available deductions.\r\n<h2>Finding a Child Custody Attorney</h2>\r\nChild custody cases can go smoothly if both parents can work together during and after the process. However, child custody often becomes a bitter battle between two parents who have differing beliefs about the well-being of a child. In either case, your attorney will help you retain your rights as a parent and protect your child’s interests.\r\n\r\nAt Ted Smith Law Group, PLLC, we help parents retain the ability to play important roles in their children’s lives. We routinely work with civilian and military parents, within the state and across the border, to secure child custody and child support arrangements that are both fair and practical. <a href="/contact/">Reach out to us today</a> for a free child custody case consultation.', 'Child Custody', '', 'publish', 'closed', 'closed', '', 'child-custody', '', '', '2016-05-20 17:58:21', '2016-05-20 17:58:21', '', 4, 'http://tedsmithdemo.com/?page_id=8', 0, 'page', '', 0),
(9, 1, '2016-05-20 17:49:26', '2016-05-20 17:49:26', 'During and after a divorce, child custody affects the role of a parent in the life of a child. The process of determining custody is often emotional, and you may need the support of an experienced legal counselor to reach a satisfactory arrangement. At Ted Smith Law Group, PLLC, we understand that child custody battles can affect a parent’s relationship with a child. We are here to help you understand Texas laws and choose an arrangement that is most beneficial for you and your child.\r\n<h2>Child Custody in Texas</h2>\r\nIn Texas, the legal term for custody is “conservatorship.” A parent may share custody with the other parent in a joint managing conservatorship, or one parent may obtain full custody in a sole managing conservatorship.\r\n\r\nConservatorship is always determined on the standard of the best interest of the child. Financial responsibility, prior caretaking responsibilities, the child’s preference, an ability to respect the other parent, and a child’s physical, emotional, and psychological needs all play a role in determining custody arrangements.\r\n<h2>Rights of Conservatorships</h2>\r\nThe rights of a parent awarded during conservatorship proceedings include:\r\n<ul>\r\n 	<li>The ability to obtain professional records regarding the child</li>\r\n 	<li>The ability to speak to a physician and make decisions about a child’s health care</li>\r\n 	<li>The ability to obtain information about the child’s physical, educational, and emotional well-being from the other parent</li>\r\n 	<li>The ability to speak to educators and make decisions about school activities and educational goals</li>\r\n</ul>\r\nIn a joint managing conservatorship, both parents may have equal parenting rights, or the courts may assign exclusive rights to one parent or the other. In a sole managing conservatorship, one parent has full parental rights, including:\r\n<ul>\r\n 	<li>The ability to receive child support</li>\r\n 	<li>Giving consent and making decisions regarding health care treatment and education</li>\r\n 	<li>Attending school and extracurricular activities</li>\r\n 	<li>Deciding where a child lives, primarily</li>\r\n 	<li>Being the first person contacted during emergencies</li>\r\n</ul>\r\n&nbsp;\r\n\r\nThe court may make a sole conservatorship determination if the other parent is unfit to hold custody rights in some way. A history of violence, neglect, drug/alcohol use, criminal activity, prolonged absences, and irreconcilable belief differences may all affect how the courts award custody in Texas.\r\n<h2>Possession and Access</h2>\r\nCustody rights primarily determine the legal rights of a parent, not how often a parent can see or spend time with a child. After the courts award conservatorship, the parents must agree to the terms of a visitation schedule. Even parents with sole managing conservatorship rights may need to allow for routine visitation with the other parent. If the parents cannot determine a schedule for holiday visitation and living circumstances, the courts may decide for them.\r\n<h2>Determining Child Support</h2>\r\nChild custody goes hand in hand with child support. The parent a child does not live with is responsible for providing for a child, financially, until he or she turns 18 or until an age determined by the courts. Child support is determined based on financial means and certain available deductions.\r\n<h2>Finding a Child Custody Attorney</h2>\r\nChild custody cases can go smoothly if both parents can work together during and after the process. However, child custody often becomes a bitter battle between two parents who have differing beliefs about the well-being of a child. In either case, your attorney will help you retain your rights as a parent and protect your child’s interests.\r\n\r\nAt Ted Smith Law Group, PLLC, we help parents retain the ability to play important roles in their children’s lives. We routinely work with civilian and military parents, within the state and across the border, to secure child custody and child support arrangements that are both fair and practical. <a href="/contact/">Reach out to us today</a> for a free child custody case consultation.', 'Child Custody', '', 'inherit', 'closed', 'closed', '', '8-revision-v1', '', '', '2016-05-20 17:49:26', '2016-05-20 17:49:26', '', 8, 'http://tedsmithdemo.com/8-revision-v1/', 0, 'revision', '', 0),
(10, 1, '2016-05-20 17:50:08', '2016-05-20 17:50:08', 'Unlike custody, which primarily involves the legal rights of a parent, child visitation refers to the physical access a parent has to a child. In most custody cases, judges do their best to ensure both parents play roles in a child’s life. Texas statutes refer to visitation as “possession and access.” During custody proceedings, parents must agree to a visitation schedule or the courts will do so on their behalves.\r\n\r\nThe attorneys at Ted Smith Law Group, PLLC, recognize the need for a parent to spend adequate time with a child. In addition to securing optimal visitation rights, we also help parents raise concerns when the other parent fails to follow the terms of the schedule.\r\n<h2>Visitation Schedules</h2>\r\nAs part of a parenting plan, divorced parents need visitation schedules to avoid conflicts regarding time spent with a child. There are two exceptions to formalized visitation schedules. The courts will make individual decisions for children under the age of 3, and any child older than 18 who is no longer in school is not bound by the visitation schedule.\r\n\r\nWhile some divided families may have special circumstances, the majority of parents adhere to a standard schedule, which ensures the following visitation rights:\r\n<ul>\r\n 	<li>Three alternating weekends a month determined by Fridays</li>\r\n 	<li>One weeknight, for a few hours</li>\r\n 	<li>Thirty days of visitation during the summer</li>\r\n 	<li>Alternated holidays and spring breaks</li>\r\n 	<li>Full weekends for each parent on Mother’s Day and Father’s Day</li>\r\n</ul>\r\nThe formalized schedule will include details regarding times and any individualized differences that deviate from the standard form. As long as both parents abide by custody arrangements and keep the best interests of the child in mind, the order will remain in good standing until the child turns 18.\r\n<h2>The Rights of a Parent During Visitation</h2>\r\nDuring visitation, a noncustodial parent does not assume the rights of the custodial parent. However, he or she does have certain rights as a parent in possession of a child. A parent is obligated to provide for the child’s basic needs and reasonably protect, care for, and discipline him or her. Depending on the terms of custody, a parent may also have the right to actively participate in the child’s health care needs and education, and provide moral or religious guidance.\r\n<h2>Conflicts Arising From Visitation Schedules</h2>\r\nOnce the initial schedule is approved and both parties agree, parents may find themselves back in court if one party continuously challenges the terms of the schedule. The courts will modify a visitation schedule according to the best interests of the child, but proving visitation issues can be difficult.\r\n\r\nIf you anticipate that your co-parent will make visitation difficult, consider keeping a record of information regarding visitation times, including witness statements, times, and details about what happened. The court can only enforce the terms of the visitation order. Keep your order in a safe place and refer to it as necessary.\r\n<h2>Visitation Rights for Grandparents</h2>\r\nIf parents retain custodial rights of their children, they choose who their children see. In some cases, this means grandparents may not have an opportunity to play a role in a child’s life. To obtain visitation rights, grandparents must often seek assistance from attorneys who understand the nuances of visitation laws. Sometimes, grandparents may need to file a lawsuit to gain access to a grandchild.\r\n<h2>Legal Help for Child Visitation in Texas</h2>\r\nAt Ted Smith Law Group, PLLC, we understand the complexities of visitation. For parents who have had difficulties with the law or have certain histories, current good behavior can be difficult to prove. We believe wholly in putting the child’s best interests first, and that often means having equal access to two participating parents. For more information about child visitation, <a href="/contact/">contact us today</a>. Initial consultations are always free.', 'Child Visitation', '', 'publish', 'closed', 'closed', '', 'child-visitation', '', '', '2016-05-20 17:58:55', '2016-05-20 17:58:55', '', 4, 'http://tedsmithdemo.com/?page_id=10', 0, 'page', '', 0),
(11, 1, '2016-05-20 17:50:08', '2016-05-20 17:50:08', 'Unlike custody, which primarily involves the legal rights of a parent, child visitation refers to the physical access a parent has to a child. In most custody cases, judges do their best to ensure both parents play roles in a child’s life. Texas statutes refer to visitation as “possession and access.” During custody proceedings, parents must agree to a visitation schedule or the courts will do so on their behalves.\r\n\r\nThe attorneys at Ted Smith Law Group, PLLC, recognize the need for a parent to spend adequate time with a child. In addition to securing optimal visitation rights, we also help parents raise concerns when the other parent fails to follow the terms of the schedule.\r\n<h2>Visitation Schedules</h2>\r\nAs part of a parenting plan, divorced parents need visitation schedules to avoid conflicts regarding time spent with a child. There are two exceptions to formalized visitation schedules. The courts will make individual decisions for children under the age of 3, and any child older than 18 who is no longer in school is not bound by the visitation schedule.\r\n\r\nWhile some divided families may have special circumstances, the majority of parents adhere to a standard schedule, which ensures the following visitation rights:\r\n<ul>\r\n 	<li>Three alternating weekends a month determined by Fridays</li>\r\n 	<li>One weeknight, for a few hours</li>\r\n 	<li>Thirty days of visitation during the summer</li>\r\n 	<li>Alternated holidays and spring breaks</li>\r\n 	<li>Full weekends for each parent on Mother’s Day and Father’s Day</li>\r\n</ul>\r\nThe formalized schedule will include details regarding times and any individualized differences that deviate from the standard form. As long as both parents abide by custody arrangements and keep the best interests of the child in mind, the order will remain in good standing until the child turns 18.\r\n<h2>The Rights of a Parent During Visitation</h2>\r\nDuring visitation, a noncustodial parent does not assume the rights of the custodial parent. However, he or she does have certain rights as a parent in possession of a child. A parent is obligated to provide for the child’s basic needs and reasonably protect, care for, and discipline him or her. Depending on the terms of custody, a parent may also have the right to actively participate in the child’s health care needs and education, and provide moral or religious guidance.\r\n<h2>Conflicts Arising From Visitation Schedules</h2>\r\nOnce the initial schedule is approved and both parties agree, parents may find themselves back in court if one party continuously challenges the terms of the schedule. The courts will modify a visitation schedule according to the best interests of the child, but proving visitation issues can be difficult.\r\n\r\nIf you anticipate that your co-parent will make visitation difficult, consider keeping a record of information regarding visitation times, including witness statements, times, and details about what happened. The court can only enforce the terms of the visitation order. Keep your order in a safe place and refer to it as necessary.\r\n<h2>Visitation Rights for Grandparents</h2>\r\nIf parents retain custodial rights of their children, they choose who their children see. In some cases, this means grandparents may not have an opportunity to play a role in a child’s life. To obtain visitation rights, grandparents must often seek assistance from attorneys who understand the nuances of visitation laws. Sometimes, grandparents may need to file a lawsuit to gain access to a grandchild.\r\n<h2>Legal Help for Child Visitation in Texas</h2>\r\nAt Ted Smith Law Group, PLLC, we understand the complexities of visitation. For parents who have had difficulties with the law or have certain histories, current good behavior can be difficult to prove. We believe wholly in putting the child’s best interests first, and that often means having equal access to two participating parents. For more information about child visitation, <a href="/contact/">contact us today</a>. Initial consultations are always free.', 'Child Visitation', '', 'inherit', 'closed', 'closed', '', '10-revision-v1', '', '', '2016-05-20 17:50:08', '2016-05-20 17:50:08', '', 10, 'http://tedsmithdemo.com/10-revision-v1/', 0, 'revision', '', 0),
(12, 1, '2016-05-20 17:50:52', '2016-05-20 17:50:52', 'All parents have a financial responsibility to support a child until he or she becomes an adult. Anyone legally recognized as a parent bears this financial responsibility. Any parent who does not have sole custody of a child must pay child support to cover the cost of a child’s needs, including health insurance, basic needs, and education.\r\n\r\nChild support in Texas can positively affect a child’s life, both physically and emotionally. Giving children financial support is one way to show your love. At Ted Smith Law Group, PLLC, we want to ensure that every child has access to the income needed to live a happy, productive life. We also want to ensure that parents do not take advantage of the system or one another.\r\n\r\nIf you’re having child support issues, we handle both military and civilian cases. Don’t wait until child support becomes a contentious issue to reach out for help. We can help you secure reasonable child support payments, protect your rights as a parent, and make sure your child receives the care and support needed to thrive.\r\n<h2>Determining Child Support in Texas</h2>\r\nChild support payments are determined based on a noncustodial parent’s resources. In addition to annual income, a parent’s overtime, financial assets, unemployment and pension benefits, and interest income all play a role in determining child support payments. Certain deductions do exist that may ease the burden of monthly payments, including:\r\n<ul>\r\n 	<li>Taxes (state, federal, and Social Security)</li>\r\n 	<li>Health insurance and expenses for the child</li>\r\n 	<li>Union dues</li>\r\n</ul>\r\nTo determine the monthly payments a parent is responsible for, calculate the full net income, subtract the deductions, divide by 12 (number of months), and then multiply the answer based on the appropriate percentage. The percentage of income that will go toward child support increases based on the number of children a parent must support. For one child, a parent must pay 20%. For two children, a parent must pay 25%. The percentage increases incrementally by 5% based on the number of children.\r\n<h2>When Child Support Ends</h2>\r\nA parent will typically stop paying child support payments when the child turns 18 and/or leaves high school. Child support may also end if a child enlists in the military at 18 without completing high school, marries, or attains legal emancipation. Courts may extend child support payments in special circumstances so that care will continue for children who are disabled.\r\n<h2>Paying Child Support</h2>\r\nParents should not pay child support directly to the other parent. Instead, Texas requires that child support payments go through the Texas Attorney General’s State Disbursement Unit. Paying through the state ensures each payment goes on record and that children in the state receive the financial support they need. In the past, parents could easily use financial payments as a form of control over other parents. Parents who pay child support must thoroughly understand the terms of the court order to avoid adverse legal actions.\r\n\r\nA parent bears responsibility for paying child support even if he or she does not have visitation rights. However, if you do have visitation rights and are paying full child support, your co-parent has no right to keep you from your child.\r\n<h2>Child Support Attorneys in Texas</h2>\r\nAt Ted Smith Law Group, PLLC, we understand the stress that comes from child support determinations on both side of the fence. Receiving adequate payments, recording payment use, and changing child support orders after a job loss or income change can all be difficult both financially and emotionally.\r\n\r\nOur attorneys understand that you want to care for your child in the best way possible, and we’re here to make the process of filing for child support, enforcing the terms, and modifying the terms as stress-free as possible. For a free case evaluation, <a href="/contact/">reach out to our office</a> today.', 'Child Support', '', 'publish', 'closed', 'closed', '', 'child-support', '', '', '2016-05-20 17:57:10', '2016-05-20 17:57:10', '', 4, 'http://tedsmithdemo.com/?page_id=12', 0, 'page', '', 0),
(13, 1, '2016-05-20 17:50:52', '2016-05-20 17:50:52', 'All parents have a financial responsibility to support a child until he or she becomes an adult. Anyone legally recognized as a parent bears this financial responsibility. Any parent who does not have sole custody of a child must pay child support to cover the cost of a child’s needs, including health insurance, basic needs, and education.\r\n\r\nChild support in Texas can positively affect a child’s life, both physically and emotionally. Giving children financial support is one way to show your love. At Ted Smith Law Group, PLLC, we want to ensure that every child has access to the income needed to live a happy, productive life. We also want to ensure that parents do not take advantage of the system or one another.\r\n\r\nIf you’re having child support issues, we handle both military and civilian cases. Don’t wait until child support becomes a contentious issue to reach out for help. We can help you secure reasonable child support payments, protect your rights as a parent, and make sure your child receives the care and support needed to thrive.\r\n<h2>Determining Child Support in Texas</h2>\r\nChild support payments are determined based on a noncustodial parent’s resources. In addition to annual income, a parent’s overtime, financial assets, unemployment and pension benefits, and interest income all play a role in determining child support payments. Certain deductions do exist that may ease the burden of monthly payments, including:\r\n<ul>\r\n 	<li>Taxes (state, federal, and Social Security)</li>\r\n 	<li>Health insurance and expenses for the child</li>\r\n 	<li>Union dues</li>\r\n</ul>\r\nTo determine the monthly payments a parent is responsible for, calculate the full net income, subtract the deductions, divide by 12 (number of months), and then multiply the answer based on the appropriate percentage. The percentage of income that will go toward child support increases based on the number of children a parent must support. For one child, a parent must pay 20%. For two children, a parent must pay 25%. The percentage increases incrementally by 5% based on the number of children.\r\n<h2>When Child Support Ends</h2>\r\nA parent will typically stop paying child support payments when the child turns 18 and/or leaves high school. Child support may also end if a child enlists in the military at 18 without completing high school, marries, or attains legal emancipation. Courts may extend child support payments in special circumstances so that care will continue for children who are disabled.\r\n<h2>Paying Child Support</h2>\r\nParents should not pay child support directly to the other parent. Instead, Texas requires that child support payments go through the Texas Attorney General’s State Disbursement Unit. Paying through the state ensures each payment goes on record and that children in the state receive the financial support they need. In the past, parents could easily use financial payments as a form of control over other parents. Parents who pay child support must thoroughly understand the terms of the court order to avoid adverse legal actions.\r\n\r\nA parent bears responsibility for paying child support even if he or she does not have visitation rights. However, if you do have visitation rights and are paying full child support, your co-parent has no right to keep you from your child.\r\n<h2>Child Support Attorneys in Texas</h2>\r\nAt Ted Smith Law Group, PLLC, we understand the stress that comes from child support determinations on both side of the fence. Receiving adequate payments, recording payment use, and changing child support orders after a job loss or income change can all be difficult both financially and emotionally.\r\n\r\nOur attorneys understand that you want to care for your child in the best way possible, and we’re here to make the process of filing for child support, enforcing the terms, and modifying the terms as stress-free as possible. For a free case evaluation, <a href="/contact/">reach out to our office</a> today.', 'Child Support', '', 'inherit', 'closed', 'closed', '', '12-revision-v1', '', '', '2016-05-20 17:50:52', '2016-05-20 17:50:52', '', 12, 'http://tedsmithdemo.com/12-revision-v1/', 0, 'revision', '', 0),
(14, 1, '2016-05-20 17:51:33', '2016-05-20 17:51:33', 'Property division is often one of the most contentious aspects of a divorce. Who gets what is a difficult question to answer, particularly when two people have been married for several years. In the state of Texas, you need an experienced divorce attorney to help you reach a fair compromise and keep the assets you hold most dear. At Ted Smith Law Group, PLLC, we help individuals reach property division terms that make sense, and allow our clients to start healing.\r\n<h2>Defining Property Under Texas Law</h2>\r\nTexas defines marriage property as either community or separate. Community property includes all financial assets and belongings a couple acquires during marriage, including real estate and housing, debt, stocks, pensions, and benefits. Anything that a couple obtained before marriage is separate and will go back to the original owner. Gifts and inheritances are also separate property.\r\n\r\nIn addition to separate and community categories, some assets may fall under a mixed-character definition. Individuals may share a percentage of ownership in assets that are paid for with separate and community assets, for example.\r\n\r\nGifts can become complex if couples disagree about who was the intended recipient. In some cases, gifts and other property split between spouses remains separate property that is shared equally, instead of community property. Property can also raise concerns, particularly if one spouse owned a home before marriage, but paid down the mortgage debt during marriage. Unless you and your spouse can easily agree on who gets what, you will likely need the assistance of an attorney to classify property and help you determine financial fairness.\r\n<h2>Dividing Property</h2>\r\nBefore a divorce, most people misunderstand the law to state that they are entitled to half of all community property. In reality, they are entitled to an equitable and just division. Because of this standard, many couples spend a significant amount of time accounting the value of different assets. High net worth couples and those who share a business or other assets may hire an accountant and/or appraisers to assess the value of a piece of community property.\r\n\r\nFactors that may affect how a court determines what is equitable and just include:\r\n<ul>\r\n 	<li>Physical health or age differences</li>\r\n 	<li>The determination of fault in a divorce</li>\r\n 	<li>Income and income earning differences</li>\r\n 	<li>Potential inheritances</li>\r\n 	<li>Tax considerations</li>\r\n 	<li>Child custody</li>\r\n 	<li>Spousal support</li>\r\n 	<li>Losses an innocent spouse sustained as a result of the divorce</li>\r\n</ul>\r\n<h2>Property Settlement Agreement</h2>\r\nCouples can create a formal property settlement agreement before or after filing for divorce. Some separated couples choose to file a property settlement agreement before petitioning for divorce. Once filed, the document becomes legally binding and both spouses must adhere to the terms set forth. The agreement may include stipulations regarding property division, spousal support, child custody, and other pertinent concerns that require resolution. To ensure you protect your rights, consider consulting a divorce attorney before filing a property settlement agreement in court.\r\n\r\nIf your property settlement agreement failed to divide all property, you can ask the courts to make a division decision after divorce. When spouses hide assets or fail to represent the value of property correctly, the other spouse has the right to ask for a division amendment.\r\n<h2>Ted Smith Law Group, PLLC, and Property Division</h2>\r\nRetain an attorney you can trust to protect your fair portion of property. For decades, our law firm has given local couples the support needed to get through a challenging time. During property division, we use the latest techniques to uncover all assets in a relationship and assign proper valuation for each piece of community property. We specialize in both civilian and military divorces, and can help you with every aspect of your divorce. <a href="/contact/">Call us today</a> for a free case evaluation.', 'Property Divison', '', 'publish', 'closed', 'closed', '', 'property-divison', '', '', '2016-05-20 17:59:32', '2016-05-20 17:59:32', '', 4, 'http://tedsmithdemo.com/?page_id=14', 0, 'page', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(15, 1, '2016-05-20 17:51:33', '2016-05-20 17:51:33', 'Property division is often one of the most contentious aspects of a divorce. Who gets what is a difficult question to answer, particularly when two people have been married for several years. In the state of Texas, you need an experienced divorce attorney to help you reach a fair compromise and keep the assets you hold most dear. At Ted Smith Law Group, PLLC, we help individuals reach property division terms that make sense, and allow our clients to start healing.\r\n<h2>Defining Property Under Texas Law</h2>\r\nTexas defines marriage property as either community or separate. Community property includes all financial assets and belongings a couple acquires during marriage, including real estate and housing, debt, stocks, pensions, and benefits. Anything that a couple obtained before marriage is separate and will go back to the original owner. Gifts and inheritances are also separate property.\r\n\r\nIn addition to separate and community categories, some assets may fall under a mixed-character definition. Individuals may share a percentage of ownership in assets that are paid for with separate and community assets, for example.\r\n\r\nGifts can become complex if couples disagree about who was the intended recipient. In some cases, gifts and other property split between spouses remains separate property that is shared equally, instead of community property. Property can also raise concerns, particularly if one spouse owned a home before marriage, but paid down the mortgage debt during marriage. Unless you and your spouse can easily agree on who gets what, you will likely need the assistance of an attorney to classify property and help you determine financial fairness.\r\n<h2>Dividing Property</h2>\r\nBefore a divorce, most people misunderstand the law to state that they are entitled to half of all community property. In reality, they are entitled to an equitable and just division. Because of this standard, many couples spend a significant amount of time accounting the value of different assets. High net worth couples and those who share a business or other assets may hire an accountant and/or appraisers to assess the value of a piece of community property.\r\n\r\nFactors that may affect how a court determines what is equitable and just include:\r\n<ul>\r\n 	<li>Physical health or age differences</li>\r\n 	<li>The determination of fault in a divorce</li>\r\n 	<li>Income and income earning differences</li>\r\n 	<li>Potential inheritances</li>\r\n 	<li>Tax considerations</li>\r\n 	<li>Child custody</li>\r\n 	<li>Spousal support</li>\r\n 	<li>Losses an innocent spouse sustained as a result of the divorce</li>\r\n</ul>\r\n<h2>Property Settlement Agreement</h2>\r\nCouples can create a formal property settlement agreement before or after filing for divorce. Some separated couples choose to file a property settlement agreement before petitioning for divorce. Once filed, the document becomes legally binding and both spouses must adhere to the terms set forth. The agreement may include stipulations regarding property division, spousal support, child custody, and other pertinent concerns that require resolution. To ensure you protect your rights, consider consulting a divorce attorney before filing a property settlement agreement in court.\r\n\r\nIf your property settlement agreement failed to divide all property, you can ask the courts to make a division decision after divorce. When spouses hide assets or fail to represent the value of property correctly, the other spouse has the right to ask for a division amendment.\r\n<h2>Ted Smith Law Group, PLLC, and Property Division</h2>\r\nRetain an attorney you can trust to protect your fair portion of property. For decades, our law firm has given local couples the support needed to get through a challenging time. During property division, we use the latest techniques to uncover all assets in a relationship and assign proper valuation for each piece of community property. We specialize in both civilian and military divorces, and can help you with every aspect of your divorce. <a href="/contact/">Call us today</a> for a free case evaluation.', 'Property Divison', '', 'inherit', 'closed', 'closed', '', '14-revision-v1', '', '', '2016-05-20 17:51:33', '2016-05-20 17:51:33', '', 14, 'http://tedsmithdemo.com/14-revision-v1/', 0, 'revision', '', 0),
(16, 1, '2016-05-20 17:52:08', '2016-05-20 17:52:08', 'Original court orders are legally binding, but that doesn’t mean parents and ex-spouses have no form of recourse if circumstances change. Modifications allow individuals to change court orders to better suit their needs. These changes are often best for everyone involved and can prevent financial hardship, future lawsuits, and ill will.\r\n\r\nAt Ted Smith Law Group, PLLC, we help people determine if a modification is the right course of action, and ensure that all financial obligations and visitation arrangements make sense for our clients. We can help you develop a compelling case and have that case heard, so you can make necessary changes as soon as possible.\r\n\r\nTo secure a modification, your situation or your ex-spouse’s must have changed drastically between filing the original order and now. Whether you obtained a raise and can now help your children more or you’re trying to keep an unfit parent from keeping visitation rights, we are ready to protect you and your child’s rights under the law.<strong> </strong>\r\n<h2>Child Support Modifications</h2>\r\nThe ability to pay support often changes over time as a parent’s financial status, custodial status, health status, or a child’s health status changes. If a paying parent takes a new job earning a higher income, an ex-spouse may petition the court to change support payments. On the other hand, if you lose your job, you may lower your payment rates to reflect that change. Military members returning from active duty may also qualify for a modification. The courts will not recognize any changes they believe were voluntary, i.e., you can’t change jobs intentionally to pay less child support.\r\n\r\nChild support orders in Texas can change if the last order was three or more years ago, the state guidelines for support change, or a parent’s circumstances change. The paying individual must pay according to the child support order that is legally binding at the time. A parent cannot stop paying or adjust payments based on an individual agreement.<strong> </strong>\r\n<h2>Child Custody and Visitation Modifications</h2>\r\nIf new circumstances arise that would change what is in the best interest of the child, parents may petition to modify existing custody and/or visitation orders. Circumstances that might warrant a change in legal and physical care arrangements include a parent’s disability, criminal convictions, residential location changes, or a parent’s remarriage.\r\n\r\nChildren older than 12 often have an opportunity to participate in modification changes. The courts will consider a child’s wishes along with the changes that have taken place within both households.\r\n\r\nIn some cases, parents give up their rights to another individual over time, knowingly or unknowingly. A parent who does not spend time or care for a child under existing orders for six months or longer may lose custody and/or visitation rights.<strong> </strong>\r\n<h2>Spousal Support/Alimony Modifications</h2>\r\nMany spousal support orders are governed by a restricted period, and the need for modification is unnecessary. However, either spouse may petition for a modification if something changes in individual situations. For instance, if an individual’s needs increase due to medical necessity, the courts may require the payee to increase payments. In other cases, the courts may terminate a spousal support order or reduce payments. Spousal support modifications are determined on a case-by-case basis.\r\n<h2>Securing Legal Support for Modifications</h2>\r\nTo ensure the family law judges hear and respect your wishes, retain a qualified attorney who understands modifications in Texas. At Ted Smith Law Group, PLLC, we help individuals with all types of family law court order modifications. We understand the changes that warrant modification and the evidence the court needs to see to agree to a change. For more information, please <a href="/contact/">contact our office</a> for a free case evaluation.', 'Modifications', '', 'publish', 'closed', 'closed', '', 'modifications', '', '', '2016-05-20 17:59:24', '2016-05-20 17:59:24', '', 4, 'http://tedsmithdemo.com/?page_id=16', 0, 'page', '', 0),
(17, 1, '2016-05-20 17:52:08', '2016-05-20 17:52:08', 'Original court orders are legally binding, but that doesn’t mean parents and ex-spouses have no form of recourse if circumstances change. Modifications allow individuals to change court orders to better suit their needs. These changes are often best for everyone involved and can prevent financial hardship, future lawsuits, and ill will.\r\n\r\nAt Ted Smith Law Group, PLLC, we help people determine if a modification is the right course of action, and ensure that all financial obligations and visitation arrangements make sense for our clients. We can help you develop a compelling case and have that case heard, so you can make necessary changes as soon as possible.\r\n\r\nTo secure a modification, your situation or your ex-spouse’s must have changed drastically between filing the original order and now. Whether you obtained a raise and can now help your children more or you’re trying to keep an unfit parent from keeping visitation rights, we are ready to protect you and your child’s rights under the law.<strong> </strong>\r\n<h2>Child Support Modifications</h2>\r\nThe ability to pay support often changes over time as a parent’s financial status, custodial status, health status, or a child’s health status changes. If a paying parent takes a new job earning a higher income, an ex-spouse may petition the court to change support payments. On the other hand, if you lose your job, you may lower your payment rates to reflect that change. Military members returning from active duty may also qualify for a modification. The courts will not recognize any changes they believe were voluntary, i.e., you can’t change jobs intentionally to pay less child support.\r\n\r\nChild support orders in Texas can change if the last order was three or more years ago, the state guidelines for support change, or a parent’s circumstances change. The paying individual must pay according to the child support order that is legally binding at the time. A parent cannot stop paying or adjust payments based on an individual agreement.<strong> </strong>\r\n<h2>Child Custody and Visitation Modifications</h2>\r\nIf new circumstances arise that would change what is in the best interest of the child, parents may petition to modify existing custody and/or visitation orders. Circumstances that might warrant a change in legal and physical care arrangements include a parent’s disability, criminal convictions, residential location changes, or a parent’s remarriage.\r\n\r\nChildren older than 12 often have an opportunity to participate in modification changes. The courts will consider a child’s wishes along with the changes that have taken place within both households.\r\n\r\nIn some cases, parents give up their rights to another individual over time, knowingly or unknowingly. A parent who does not spend time or care for a child under existing orders for six months or longer may lose custody and/or visitation rights.<strong> </strong>\r\n<h2>Spousal Support/Alimony Modifications</h2>\r\nMany spousal support orders are governed by a restricted period, and the need for modification is unnecessary. However, either spouse may petition for a modification if something changes in individual situations. For instance, if an individual’s needs increase due to medical necessity, the courts may require the payee to increase payments. In other cases, the courts may terminate a spousal support order or reduce payments. Spousal support modifications are determined on a case-by-case basis.\r\n<h2>Securing Legal Support for Modifications</h2>\r\nTo ensure the family law judges hear and respect your wishes, retain a qualified attorney who understands modifications in Texas. At Ted Smith Law Group, PLLC, we help individuals with all types of family law court order modifications. We understand the changes that warrant modification and the evidence the court needs to see to agree to a change. For more information, please <a href="/contact/">contact our office</a> for a free case evaluation.', 'Modifications', '', 'inherit', 'closed', 'closed', '', '16-revision-v1', '', '', '2016-05-20 17:52:08', '2016-05-20 17:52:08', '', 16, 'http://tedsmithdemo.com/16-revision-v1/', 0, 'revision', '', 0),
(18, 1, '2016-05-20 17:52:40', '2016-05-20 17:52:40', 'During divorces involving children, many male parents may start to question the paternity of the child. In Texas, presumption, voluntary acknowledgement, and court order are the three ways to establish paternity. Establishing paternity gives fathers certain rights, but it also may prevent someone who is not the legal father from having to pay child support unnecessarily.\r\n\r\nTed Smith Law Group, PLLC, understands that paternity issues are delicate and emotional for both father figures and children. We use extreme discretion to protect our clients and their children during paternity proceedings. Whether you’re going through a divorce or you have a child outside of a marriage, we can help you determine paternity and protect your rights as a father or as a presumed father.\r\n<h2>Establishing Paternity</h2>\r\nUnder state law, you are a presumed father if:\r\n<ul>\r\n 	<li>You were married to the mother when the child was born,</li>\r\n 	<li>A mother has a child 300 days after a marriage with you ends,</li>\r\n 	<li>You have claimed paternity in formal documentation, or,</li>\r\n 	<li>You lived with a child and acted as his or her parent during the child’s first two years.</li>\r\n</ul>\r\nA presumed father is legally obligated to act as a father, with all attendant rights and responsibilities, unless the biological father acknowledges paternity and the presumed father files a Denial of Paternity. A presumed father who is not the biological father can also remove legal obligation via a court order.\r\n\r\nIf you are not a presumed father, you and the mother of the child can sign a voluntary Acknowledgement of Paternity, which declares you as the biological father. You do have an opportunity to reject paternity acknowledgement by filing a Rescission of Acknowledgement of Paternity within 60 days of filing the acknowledgement and before any court case is filed. You may also challenge your acknowledgement in certain circumstances.\r\n\r\nIn addition to presumption and acknowledgment, the court may also establish parentage during a formal paternity case. A man who believes he is the biological father, the mother or next of kin, the child, or another approved party can file a paternity case to determine the true parentage.\r\n\r\nTo settle any disagreements over parentage, the courts may order genetic testing of the mother, child, and father in question. You have rights during paternity cases, and every case is different. A qualified paternity attorney can help you navigate through the establishment of parentage as well as any secondary issues, including visitation, custody, and child support.\r\n<h2>Why Worry About Paternity?</h2>\r\nIf you have no reason to contest fatherhood rights, then a paternity suit is unnecessary. Paternity cases are helpful to prove the responsibility of a father for child support purposes, to help a father retain his rights to custody and visitation, and to help a child understand his or her parentage.\r\n\r\nWhether you are actively pursuing a case or you have been sued, you need legal support to help protect your rights under Texas law. Circumstances change quickly, which may affect your rights as a caretaker or a legal father. If you fail to respond to an open lawsuit, you may not have an opportunity to plead your side of the case.\r\n<h2>Paternity Attorney Texas</h2>\r\nAs a mother or father concerned about the establishment of paternity, you may have many questions regarding the legal process. Paternity can be a very complex area of law, particularly when the individuals in question are unwilling to cooperate. The team of attorneys at Ted Smith Law Group, PLLC, wants to help you maintain your benefits and rights as a parent or a mistaken parent.\r\n\r\nEvery case is unique, and we will work with you to ensure a successful conclusion. To get started, please <a href="/contact/">reach out to our office</a> for a free case evaluation.', 'Paternity', '', 'publish', 'closed', 'closed', '', 'paternity', '', '', '2016-05-20 17:59:27', '2016-05-20 17:59:27', '', 4, 'http://tedsmithdemo.com/?page_id=18', 0, 'page', '', 0),
(19, 1, '2016-05-20 17:52:40', '2016-05-20 17:52:40', 'During divorces involving children, many male parents may start to question the paternity of the child. In Texas, presumption, voluntary acknowledgement, and court order are the three ways to establish paternity. Establishing paternity gives fathers certain rights, but it also may prevent someone who is not the legal father from having to pay child support unnecessarily.\r\n\r\nTed Smith Law Group, PLLC, understands that paternity issues are delicate and emotional for both father figures and children. We use extreme discretion to protect our clients and their children during paternity proceedings. Whether you’re going through a divorce or you have a child outside of a marriage, we can help you determine paternity and protect your rights as a father or as a presumed father.\r\n<h2>Establishing Paternity</h2>\r\nUnder state law, you are a presumed father if:\r\n<ul>\r\n 	<li>You were married to the mother when the child was born,</li>\r\n 	<li>A mother has a child 300 days after a marriage with you ends,</li>\r\n 	<li>You have claimed paternity in formal documentation, or,</li>\r\n 	<li>You lived with a child and acted as his or her parent during the child’s first two years.</li>\r\n</ul>\r\nA presumed father is legally obligated to act as a father, with all attendant rights and responsibilities, unless the biological father acknowledges paternity and the presumed father files a Denial of Paternity. A presumed father who is not the biological father can also remove legal obligation via a court order.\r\n\r\nIf you are not a presumed father, you and the mother of the child can sign a voluntary Acknowledgement of Paternity, which declares you as the biological father. You do have an opportunity to reject paternity acknowledgement by filing a Rescission of Acknowledgement of Paternity within 60 days of filing the acknowledgement and before any court case is filed. You may also challenge your acknowledgement in certain circumstances.\r\n\r\nIn addition to presumption and acknowledgment, the court may also establish parentage during a formal paternity case. A man who believes he is the biological father, the mother or next of kin, the child, or another approved party can file a paternity case to determine the true parentage.\r\n\r\nTo settle any disagreements over parentage, the courts may order genetic testing of the mother, child, and father in question. You have rights during paternity cases, and every case is different. A qualified paternity attorney can help you navigate through the establishment of parentage as well as any secondary issues, including visitation, custody, and child support.\r\n<h2>Why Worry About Paternity?</h2>\r\nIf you have no reason to contest fatherhood rights, then a paternity suit is unnecessary. Paternity cases are helpful to prove the responsibility of a father for child support purposes, to help a father retain his rights to custody and visitation, and to help a child understand his or her parentage.\r\n\r\nWhether you are actively pursuing a case or you have been sued, you need legal support to help protect your rights under Texas law. Circumstances change quickly, which may affect your rights as a caretaker or a legal father. If you fail to respond to an open lawsuit, you may not have an opportunity to plead your side of the case.\r\n<h2>Paternity Attorney Texas</h2>\r\nAs a mother or father concerned about the establishment of paternity, you may have many questions regarding the legal process. Paternity can be a very complex area of law, particularly when the individuals in question are unwilling to cooperate. The team of attorneys at Ted Smith Law Group, PLLC, wants to help you maintain your benefits and rights as a parent or a mistaken parent.\r\n\r\nEvery case is unique, and we will work with you to ensure a successful conclusion. To get started, please <a href="/contact/">reach out to our office</a> for a free case evaluation.', 'Paternity', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2016-05-20 17:52:40', '2016-05-20 17:52:40', '', 18, 'http://tedsmithdemo.com/18-revision-v1/', 0, 'revision', '', 0),
(20, 1, '2016-05-20 17:53:26', '2016-05-20 17:53:26', 'Choosing to adopt is a wonderful way to care for a child in need and fulfill your dreams of having a family. The Ted Smith Law Group, PLLC, works with families of all shapes and sizes to streamline the adoption process and ensure families receive the support they need after finalizing an adoption.\r\n<h2>Preparing for Adoption</h2>\r\nLike many other family law proceedings, adoption requires families to open up their lives to the court’s scrutiny. Your lifestyle and background will play an important role in their determination of eligibility. The state will look for information regarding:\r\n<ul>\r\n 	<li>Your age (you must be at least 21 and a responsible adult to adopt)</li>\r\n 	<li>Financial stability and security</li>\r\n 	<li>References from extended family members</li>\r\n 	<li>Comprehensive background checks, including any reports of abuse or neglect</li>\r\n 	<li>Your marital status (a person does not have to be married to adopt in Texas)</li>\r\n 	<li>Your home life and lifestyle</li>\r\n</ul>\r\nEvery aspect of an adoption proceeding must be handled carefully and completely. If the proceedings do not include all the necessary information, the state could declare your adoption invalid. Our firm regularly helps cisgender and LGBTQ parents, step-parents, and grandparents who are seeking to adopt family members, children from international adoption agencies, and children from domestic public and private adoption agencies.\r\n<h2>Family Member Adoptions and Surrogacy</h2>\r\nStep-parent adoptions allow mother and father figures to play a permanent role in a child’s life, and are often in the best interest of the child. In these cases, a biological parent must terminate his or her rights as a parent. If a biological parent currently plays no role in a child’s life, a step-parent adoption may be the best way to give a child a well-rounded and loving family environment. Step-parents who adopt their children have more legal rights and can play an active role in a child’s education, health and wellness, and general instruction.\r\n\r\nIn some cases, grandparents will adopt a grandchild to take a child out of a bad situation. To do that, both biological parents must terminate their own parental rights or the grandparents must prove that the biological parents are unfit or that the parents are deceased.\r\n\r\nParents who cannot have their own children often opt to use a surrogate. After a surrogate gives birth, she and her spouse are presumed to be the child’s parents. The original parents must adopt their child after birth to make the family unit official.\r\n<h2>Terminating Parental Rights</h2>\r\nHowever, a biological parent cannot simply decide to relinquish his or her rights during an adoption proceeding. The court must come to its own conclusion and create a court order recognizing the formal, voluntary termination.\r\n\r\nIn some cases, the courts will involuntarily terminate parental rights. Parents who have a history of abandonment, neglect, child endangerment, criminal conduct, or other characteristics that prevent a parent from taking a responsible role may not have the opportunity to keep parental rights. The courts will, in every case, determine which outcome is in the best interest of the child.\r\n\r\nA child may not have more than two parents. In order to complete an adoption in Texas, the legal parents’ rights in the state must be terminated. Once completed, the termination of parental rights is permanent.\r\n<h2>Choosing an Adoption Attorney</h2>\r\nYour adoption attorney will play a key role in the outcome of your family’s adoption pursuits. Ted Smith Law Group, PLLC, wants to help you navigate the complexities of adoption in Texas so you can start spending time with your new family as soon as possible. We look forward to helping you file your Petition for Adoption, securing a termination of parental rights (if needed), and ensuring that future questions surrounding the adoption never arise. When you’re ready to get started, please <a href="/contact/">call our office</a> for a free case evaluation.', 'Adoption', '', 'publish', 'closed', 'closed', '', 'adoption', '', '', '2016-05-20 17:58:41', '2016-05-20 17:58:41', '', 4, 'http://tedsmithdemo.com/?page_id=20', 0, 'page', '', 0),
(21, 1, '2016-05-20 17:53:26', '2016-05-20 17:53:26', 'Choosing to adopt is a wonderful way to care for a child in need and fulfill your dreams of having a family. The Ted Smith Law Group, PLLC, works with families of all shapes and sizes to streamline the adoption process and ensure families receive the support they need after finalizing an adoption.\r\n<h2>Preparing for Adoption</h2>\r\nLike many other family law proceedings, adoption requires families to open up their lives to the court’s scrutiny. Your lifestyle and background will play an important role in their determination of eligibility. The state will look for information regarding:\r\n<ul>\r\n 	<li>Your age (you must be at least 21 and a responsible adult to adopt)</li>\r\n 	<li>Financial stability and security</li>\r\n 	<li>References from extended family members</li>\r\n 	<li>Comprehensive background checks, including any reports of abuse or neglect</li>\r\n 	<li>Your marital status (a person does not have to be married to adopt in Texas)</li>\r\n 	<li>Your home life and lifestyle</li>\r\n</ul>\r\nEvery aspect of an adoption proceeding must be handled carefully and completely. If the proceedings do not include all the necessary information, the state could declare your adoption invalid. Our firm regularly helps cisgender and LGBTQ parents, step-parents, and grandparents who are seeking to adopt family members, children from international adoption agencies, and children from domestic public and private adoption agencies.\r\n<h2>Family Member Adoptions and Surrogacy</h2>\r\nStep-parent adoptions allow mother and father figures to play a permanent role in a child’s life, and are often in the best interest of the child. In these cases, a biological parent must terminate his or her rights as a parent. If a biological parent currently plays no role in a child’s life, a step-parent adoption may be the best way to give a child a well-rounded and loving family environment. Step-parents who adopt their children have more legal rights and can play an active role in a child’s education, health and wellness, and general instruction.\r\n\r\nIn some cases, grandparents will adopt a grandchild to take a child out of a bad situation. To do that, both biological parents must terminate their own parental rights or the grandparents must prove that the biological parents are unfit or that the parents are deceased.\r\n\r\nParents who cannot have their own children often opt to use a surrogate. After a surrogate gives birth, she and her spouse are presumed to be the child’s parents. The original parents must adopt their child after birth to make the family unit official.\r\n<h2>Terminating Parental Rights</h2>\r\nHowever, a biological parent cannot simply decide to relinquish his or her rights during an adoption proceeding. The court must come to its own conclusion and create a court order recognizing the formal, voluntary termination.\r\n\r\nIn some cases, the courts will involuntarily terminate parental rights. Parents who have a history of abandonment, neglect, child endangerment, criminal conduct, or other characteristics that prevent a parent from taking a responsible role may not have the opportunity to keep parental rights. The courts will, in every case, determine which outcome is in the best interest of the child.\r\n\r\nA child may not have more than two parents. In order to complete an adoption in Texas, the legal parents’ rights in the state must be terminated. Once completed, the termination of parental rights is permanent.\r\n<h2>Choosing an Adoption Attorney</h2>\r\nYour adoption attorney will play a key role in the outcome of your family’s adoption pursuits. Ted Smith Law Group, PLLC, wants to help you navigate the complexities of adoption in Texas so you can start spending time with your new family as soon as possible. We look forward to helping you file your Petition for Adoption, securing a termination of parental rights (if needed), and ensuring that future questions surrounding the adoption never arise. When you’re ready to get started, please <a href="/contact/">call our office</a> for a free case evaluation.', 'Adoption', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2016-05-20 17:53:26', '2016-05-20 17:53:26', '', 20, 'http://tedsmithdemo.com/20-revision-v1/', 0, 'revision', '', 0),
(22, 1, '2016-05-20 17:54:17', '2016-05-20 17:54:17', 'Historically, courts have sided with mothers in custody and visitation matters, leaving fathers to bear the financial burden and deal with the outcome. Today, as household roles continue to shift, fathers are increasingly standing up and protecting their rights to play a role in their children’s lives. Established fathers and female noncustodial parents deserve the opportunity to play active roles in their children’s lives.\r\n\r\nThe team at Ted Smith Law Group, PLLC, wants to protect your rights as a parent so you can have the relationship you want with your child. If you need a flexible visitation schedule, help enforcing the schedule, or assistance fighting against an unfair protective order, we’re here to make sure you don’t lose your parental rights or your reputation as a responsible parent.\r\n<h2>Protecting Parental and Financial Rights</h2>\r\nAs a father, whether you are a noncustodial parent with visitation rights or you have joint custody with your ex-spouse, you retain the right to:\r\n<ul>\r\n 	<li>Time. According to the court-ordered visitation schedule, you have the right to spend time with your child. Your co-parent must adhere to the schedule or risk police involvement and custody modifications. A mother does not have the right to keep you from your child without a protective order or a visitation schedule modification.</li>\r\n 	<li>Make decisions on your child’s behalf, based on custody agreements. According to the terms of your custody arrangement, you may have the right to play a decision-making role in your child’s life. Review the custody agreement to determine your rights regarding your child’s education, health care, moral guidance, legal actions, financial control, and a child’s primary residence. Every parental arrangement is different, and your attorney can help you determine your legal rights as a single parent.</li>\r\n 	<li>Financial fairness. You have both the right to pay only a fair and reasonable amount of child support ordered by the state and the right to ask for child support if you are the child’s custodial parent.</li>\r\n</ul>\r\n<h2>The Issue of Unfair Protective Orders Against Fathers</h2>\r\nUnfortunately, some mothers file protective orders against fathers to gain more power over a child’s life, not because a father was actually abusive or violent. These cases are particularly devastating for the children and the fathers who are falsely accused.\r\n\r\nThe courts will file an order only if they believe the move is in the best interest of the child. More often than not, they may choose to err on the side of caution if they do not have strong evidence of a father’s innocence. If an ex-spouse accuses you of engaging in activities unfit for a father, seek legal counsel immediately. Proceeding in a timely and professional manner will improve your ability to fight the order and protect your rights.\r\n<h2>What to Do if Your Rights are Violated</h2>\r\nWhile sex and gender are not supposed to affect the court’s decision regarding child custody and visitation, it can still cause subconscious biases. Some of the best ways to protect your rights include:\r\n<ul>\r\n 	<li>Consulting a father’s rights attorney. Stay in touch with someone who can guide you through the process to ensure the courts fairly evaluate your case.</li>\r\n 	<li>Avoiding confrontation. Although ex-spouses often do things to make their ex’s upset, avoid engaging in any potentially negative communications.</li>\r\n 	<li>Avoiding influencing your child. Some parents manipulate their children into losing trust in one parent. Instead of fighting fire with fire, ask your attorney or outreach groups about how to move forward.</li>\r\n</ul>\r\nIf you are experiencing the effects of subversive behaviors or your rights are not being respected, <a href="/contact/">reach out to our office</a> for a free case evaluation. Allow us to help you protect your relationship with your child and avoid future legal battles with an uncooperative co-parent.', 'Fathers\' Rights', '', 'publish', 'closed', 'closed', '', 'fathers-rights', '', '', '2016-05-20 17:59:17', '2016-05-20 17:59:17', '', 4, 'http://tedsmithdemo.com/?page_id=22', 0, 'page', '', 0),
(23, 1, '2016-05-20 17:54:17', '2016-05-20 17:54:17', 'Historically, courts have sided with mothers in custody and visitation matters, leaving fathers to bear the financial burden and deal with the outcome. Today, as household roles continue to shift, fathers are increasingly standing up and protecting their rights to play a role in their children’s lives. Established fathers and female noncustodial parents deserve the opportunity to play active roles in their children’s lives.\r\n\r\nThe team at Ted Smith Law Group, PLLC, wants to protect your rights as a parent so you can have the relationship you want with your child. If you need a flexible visitation schedule, help enforcing the schedule, or assistance fighting against an unfair protective order, we’re here to make sure you don’t lose your parental rights or your reputation as a responsible parent.\r\n<h2>Protecting Parental and Financial Rights</h2>\r\nAs a father, whether you are a noncustodial parent with visitation rights or you have joint custody with your ex-spouse, you retain the right to:\r\n<ul>\r\n 	<li>Time. According to the court-ordered visitation schedule, you have the right to spend time with your child. Your co-parent must adhere to the schedule or risk police involvement and custody modifications. A mother does not have the right to keep you from your child without a protective order or a visitation schedule modification.</li>\r\n 	<li>Make decisions on your child’s behalf, based on custody agreements. According to the terms of your custody arrangement, you may have the right to play a decision-making role in your child’s life. Review the custody agreement to determine your rights regarding your child’s education, health care, moral guidance, legal actions, financial control, and a child’s primary residence. Every parental arrangement is different, and your attorney can help you determine your legal rights as a single parent.</li>\r\n 	<li>Financial fairness. You have both the right to pay only a fair and reasonable amount of child support ordered by the state and the right to ask for child support if you are the child’s custodial parent.</li>\r\n</ul>\r\n<h2>The Issue of Unfair Protective Orders Against Fathers</h2>\r\nUnfortunately, some mothers file protective orders against fathers to gain more power over a child’s life, not because a father was actually abusive or violent. These cases are particularly devastating for the children and the fathers who are falsely accused.\r\n\r\nThe courts will file an order only if they believe the move is in the best interest of the child. More often than not, they may choose to err on the side of caution if they do not have strong evidence of a father’s innocence. If an ex-spouse accuses you of engaging in activities unfit for a father, seek legal counsel immediately. Proceeding in a timely and professional manner will improve your ability to fight the order and protect your rights.\r\n<h2>What to Do if Your Rights are Violated</h2>\r\nWhile sex and gender are not supposed to affect the court’s decision regarding child custody and visitation, it can still cause subconscious biases. Some of the best ways to protect your rights include:\r\n<ul>\r\n 	<li>Consulting a father’s rights attorney. Stay in touch with someone who can guide you through the process to ensure the courts fairly evaluate your case.</li>\r\n 	<li>Avoiding confrontation. Although ex-spouses often do things to make their ex’s upset, avoid engaging in any potentially negative communications.</li>\r\n 	<li>Avoiding influencing your child. Some parents manipulate their children into losing trust in one parent. Instead of fighting fire with fire, ask your attorney or outreach groups about how to move forward.</li>\r\n</ul>\r\nIf you are experiencing the effects of subversive behaviors or your rights are not being respected, <a href="/contact/">reach out to our office</a> for a free case evaluation. Allow us to help you protect your relationship with your child and avoid future legal battles with an uncooperative co-parent.', 'Fathers\' Rights', '', 'inherit', 'closed', 'closed', '', '22-revision-v1', '', '', '2016-05-20 17:54:17', '2016-05-20 17:54:17', '', 22, 'http://tedsmithdemo.com/22-revision-v1/', 0, 'revision', '', 0),
(24, 1, '2016-05-20 17:55:13', '2016-05-20 17:55:13', 'Grandparents often serve as important role models for children, as well as being sources of unconditional love and support. During and after a divorce, access to a close grandparent can become a source of comfort and familiarity for a child going through a difficult time. Unfortunately, grandparents do not have the same rights as parents. If a custodial parent decides to disallow access to a grandparent, grandparents do not have an inherent right to visitation.\r\n\r\nAt Ted Smith Law Group, PLLC, we understand how enriching a grandparent can be to the life of a child. We’re here to help grandparents of all ages pursue their right to visitation or custody of a child in a difficult situation. We help grandparents with visitation, custody, adoption, and child support.\r\n<h2>Working with Parents</h2>\r\nIf possible, we will work with the parents of your grandchild to arrange a beneficial solution. Grandparents do not have much room to negotiate if a parent is not behaving in an unfit manner and has a reasonably valid reason for barring a grandparent from seeing a child.\r\n\r\nHowever, if you have an interest in pursuing legal action, you should always contact an attorney to discuss your options. We will help you determine if you have a valid case to pursue visitation or custody rights to become part of your grandchild’s life.\r\n<h2>Obtaining Visitation for a Grandchild</h2>\r\nIf a custodial parent is not allowing you to see your grandchild, you can pursue a lawsuit to obtain a court order for visitation. You may pursue a visitation case against the parent if the parent in question is in jail, is mentally unfit, not living with the child, or is dead. If grandparents meet one of these conditions, the court will hear the case and determine if visitation is in the child’s best interest and if:\r\n<ul>\r\n 	<li>A parent is unfit due to neglect, abuse, incarceration, or incompetence,</li>\r\n 	<li>The parents are divorced,</li>\r\n 	<li>The child only has a court-approved relationship with one parent, or</li>\r\n 	<li>The child has been living with his or her grandparent(s) for six months or longer.</li>\r\n</ul>\r\n<h2>Obtaining Custody of a Grandchild</h2>\r\nParents can grant a grandparent custody of a child through a power of attorney. If the parents do not give a grandparent a power of attorney, the grandparent must file a custody lawsuit and prove one of the following:\r\n<ul>\r\n 	<li>The child lived with the grandparent seeking custody for at least six months. A grandparent has 90 days to file a lawsuit from the time a child leaves the home to live with someone else</li>\r\n 	<li>The child’s best interests are not being met</li>\r\n 	<li>All custodial parties agree that a grandparent should have custody and/or long-term visitation rights</li>\r\n 	<li>The grandparent is the child’s legal guardian</li>\r\n</ul>\r\nIf all of the requisite conditions are met and the court determines that living with a grandparent is in the best interest of the child, then grandparents may win the custody battle.\r\n<h2>Adopting a Grandchild</h2>\r\nIf two parents can no longer participate in their roles (after death, due to substance abuse, or because of a history of violence), they may voluntarily terminate their rights as parents or have their rights terminated involuntarily. A grandparent can file a Petition for Adoption as soon as the courts formally terminate parental rights.\r\n\r\nThe courts will approve of a grandparent adoption if living with grandparents is in the child’s best interest. Adoption is one way to keep a biological grandchild inside the family when outside adoption or foster care are the only other alternatives.\r\n\r\nReach Out to a Grandparents’ Rights Attorney\r\nCustody and visitation battles involving children are tough. If you are concerned about losing your role in your grandchild’s life, <a href="/contact/">contact the team</a> at Ted Smith Law Group, PLLC today.', 'Grandparents’ Rights', '', 'publish', 'closed', 'closed', '', 'grandparents-rights', '', '', '2016-05-20 17:59:20', '2016-05-20 17:59:20', '', 4, 'http://tedsmithdemo.com/?page_id=24', 0, 'page', '', 0),
(25, 1, '2016-05-20 17:55:13', '2016-05-20 17:55:13', 'Grandparents often serve as important role models for children, as well as being sources of unconditional love and support. During and after a divorce, access to a close grandparent can become a source of comfort and familiarity for a child going through a difficult time. Unfortunately, grandparents do not have the same rights as parents. If a custodial parent decides to disallow access to a grandparent, grandparents do not have an inherent right to visitation.\r\n\r\nAt Ted Smith Law Group, PLLC, we understand how enriching a grandparent can be to the life of a child. We’re here to help grandparents of all ages pursue their right to visitation or custody of a child in a difficult situation. We help grandparents with visitation, custody, adoption, and child support.\r\n<h2>Working with Parents</h2>\r\nIf possible, we will work with the parents of your grandchild to arrange a beneficial solution. Grandparents do not have much room to negotiate if a parent is not behaving in an unfit manner and has a reasonably valid reason for barring a grandparent from seeing a child.\r\n\r\nHowever, if you have an interest in pursuing legal action, you should always contact an attorney to discuss your options. We will help you determine if you have a valid case to pursue visitation or custody rights to become part of your grandchild’s life.\r\n<h2>Obtaining Visitation for a Grandchild</h2>\r\nIf a custodial parent is not allowing you to see your grandchild, you can pursue a lawsuit to obtain a court order for visitation. You may pursue a visitation case against the parent if the parent in question is in jail, is mentally unfit, not living with the child, or is dead. If grandparents meet one of these conditions, the court will hear the case and determine if visitation is in the child’s best interest and if:\r\n<ul>\r\n 	<li>A parent is unfit due to neglect, abuse, incarceration, or incompetence,</li>\r\n 	<li>The parents are divorced,</li>\r\n 	<li>The child only has a court-approved relationship with one parent, or</li>\r\n 	<li>The child has been living with his or her grandparent(s) for six months or longer.</li>\r\n</ul>\r\n<h2>Obtaining Custody of a Grandchild</h2>\r\nParents can grant a grandparent custody of a child through a power of attorney. If the parents do not give a grandparent a power of attorney, the grandparent must file a custody lawsuit and prove one of the following:\r\n<ul>\r\n 	<li>The child lived with the grandparent seeking custody for at least six months. A grandparent has 90 days to file a lawsuit from the time a child leaves the home to live with someone else</li>\r\n 	<li>The child’s best interests are not being met</li>\r\n 	<li>All custodial parties agree that a grandparent should have custody and/or long-term visitation rights</li>\r\n 	<li>The grandparent is the child’s legal guardian</li>\r\n</ul>\r\nIf all of the requisite conditions are met and the court determines that living with a grandparent is in the best interest of the child, then grandparents may win the custody battle.\r\n<h2>Adopting a Grandchild</h2>\r\nIf two parents can no longer participate in their roles (after death, due to substance abuse, or because of a history of violence), they may voluntarily terminate their rights as parents or have their rights terminated involuntarily. A grandparent can file a Petition for Adoption as soon as the courts formally terminate parental rights.\r\n\r\nThe courts will approve of a grandparent adoption if living with grandparents is in the child’s best interest. Adoption is one way to keep a biological grandchild inside the family when outside adoption or foster care are the only other alternatives.\r\n\r\nReach Out to a Grandparents’ Rights Attorney\r\nCustody and visitation battles involving children are tough. If you are concerned about losing your role in your grandchild’s life, <a href="/contact/">contact the team</a> at Ted Smith Law Group, PLLC today.', 'Grandparents’ Rights', '', 'inherit', 'closed', 'closed', '', '24-revision-v1', '', '', '2016-05-20 17:55:13', '2016-05-20 17:55:13', '', 24, 'http://tedsmithdemo.com/24-revision-v1/', 0, 'revision', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(26, 1, '2016-05-20 17:55:55', '2016-05-20 17:55:55', 'During a divorce, you may have to work through three major and potentially challenging elements: child custody and support, property division, and spousal support. Spousal support is based on need, the provider’s ability to pay, and any acts of violence that occurred during the marriage or during the divorce proceedings.\r\n\r\nFor many primary income earners, hearing the words alimony or spousal support is stressful. They envision servicing an ongoing debt that will prevent them from moving on. For those who quit working or did not pursue a career in favor of household maintenance and childcare, the words are equally stressful. They fear reentering the workforce and learning how to become independent once more.\r\n\r\nThe attorneys at Ted Smith Law Group, PLLC, help individuals on both sides of the spousal support fence. We understand that each marriage is different, and we want to ensure that our clients receive the most beneficial outcomes possible.\r\n<h2>Determining Spousal Support Eligibility</h2>\r\nYou are eligible for spousal support payments if you do not have enough property to provide for your needs after a divorce and the paying spouse was convicted of family violence, <strong>or</strong> the accepting spouse’s earning capacity will not provide for his or her minimum needs and the accepting spouse has been married to the providing spouse for 10 years or longer, has a disability, or cares for a child with a disability.\r\n\r\nOnce the courts determine eligibility, they will determine the amount of support a spouse can receive and the timeframe for receiving the benefit. The state will look at the length of marriage, the age and earning capability of the accepting spouse, educational attainment, a history of employment, and other factors to make its determination.\r\n\r\nTexas limits the duration of spousal support. Unless an accepting spouse is disabled or taking care of a disabled child, the maximum length of support is 10 years. To prove eligibility for support, the spouse in need should consult an attorney to help build a case.\r\n<h2>Determining Spousal Support Payments</h2>\r\nThe paying spouse will have to pay up to $5,000 or 20% of his or her gross income per month. The lower amount is the amount a paying spouse will owe. To make a payment determination, the courts will evaluate both spouses’ financial assets, child support, education and employment history, age, contributions to the family during marriage, marital misconduct, family violence, and community property fraud during marriage.\r\n\r\nWhen you are court-ordered to pay spousal support, you must pay regularly to avoid jail time and the possibility of having to pay retroactively. While you cannot actively change your income-earning level to lower spousal payments, you can ask the court for an agreement modification if you lose your job or have to accept a lower-paying job while paying for spousal support.\r\n<h2>Creating a Contract for Spousal Support</h2>\r\nCourt-ordered spousal support is the only legally enforceable financial support a spouse can receive for himself or herself after a divorce. However, some couples choose to create an independent contract outlining the terms of support for an accepting spouse. Amicable divorcees can use contractual maintenance to qualify for certain living arrangements, to go back to school, or to improve childcare income over time.\r\n<h2>Your Attorney for Alimony/Spousal Support in Texas</h2>\r\nWhether you need help navigating court-ordered spousal support or developing a working contract between you and your spouse, the attorneys at Ted Smith Law Group, PLLC are here to help you. We want you to have the best future possible after a divorce, and finding an appropriate solution for spousal support can help. <a href="/contact/">Contact us today</a> and we’ll evaluate your case for free case evaluation and give you more information about our spousal support experience.', 'Alimony/Spousal Support', '', 'publish', 'closed', 'closed', '', 'alimony-spousal-support', '', '', '2016-05-20 17:58:51', '2016-05-20 17:58:51', '', 4, 'http://tedsmithdemo.com/?page_id=26', 0, 'page', '', 0),
(27, 1, '2016-05-20 17:55:55', '2016-05-20 17:55:55', 'During a divorce, you may have to work through three major and potentially challenging elements: child custody and support, property division, and spousal support. Spousal support is based on need, the provider’s ability to pay, and any acts of violence that occurred during the marriage or during the divorce proceedings.\r\n\r\nFor many primary income earners, hearing the words alimony or spousal support is stressful. They envision servicing an ongoing debt that will prevent them from moving on. For those who quit working or did not pursue a career in favor of household maintenance and childcare, the words are equally stressful. They fear reentering the workforce and learning how to become independent once more.\r\n\r\nThe attorneys at Ted Smith Law Group, PLLC, help individuals on both sides of the spousal support fence. We understand that each marriage is different, and we want to ensure that our clients receive the most beneficial outcomes possible.\r\n<h2>Determining Spousal Support Eligibility</h2>\r\nYou are eligible for spousal support payments if you do not have enough property to provide for your needs after a divorce and the paying spouse was convicted of family violence, <strong>or</strong> the accepting spouse’s earning capacity will not provide for his or her minimum needs and the accepting spouse has been married to the providing spouse for 10 years or longer, has a disability, or cares for a child with a disability.\r\n\r\nOnce the courts determine eligibility, they will determine the amount of support a spouse can receive and the timeframe for receiving the benefit. The state will look at the length of marriage, the age and earning capability of the accepting spouse, educational attainment, a history of employment, and other factors to make its determination.\r\n\r\nTexas limits the duration of spousal support. Unless an accepting spouse is disabled or taking care of a disabled child, the maximum length of support is 10 years. To prove eligibility for support, the spouse in need should consult an attorney to help build a case.\r\n<h2>Determining Spousal Support Payments</h2>\r\nThe paying spouse will have to pay up to $5,000 or 20% of his or her gross income per month. The lower amount is the amount a paying spouse will owe. To make a payment determination, the courts will evaluate both spouses’ financial assets, child support, education and employment history, age, contributions to the family during marriage, marital misconduct, family violence, and community property fraud during marriage.\r\n\r\nWhen you are court-ordered to pay spousal support, you must pay regularly to avoid jail time and the possibility of having to pay retroactively. While you cannot actively change your income-earning level to lower spousal payments, you can ask the court for an agreement modification if you lose your job or have to accept a lower-paying job while paying for spousal support.\r\n<h2>Creating a Contract for Spousal Support</h2>\r\nCourt-ordered spousal support is the only legally enforceable financial support a spouse can receive for himself or herself after a divorce. However, some couples choose to create an independent contract outlining the terms of support for an accepting spouse. Amicable divorcees can use contractual maintenance to qualify for certain living arrangements, to go back to school, or to improve childcare income over time.\r\n<h2>Your Attorney for Alimony/Spousal Support in Texas</h2>\r\nWhether you need help navigating court-ordered spousal support or developing a working contract between you and your spouse, the attorneys at Ted Smith Law Group, PLLC are here to help you. We want you to have the best future possible after a divorce, and finding an appropriate solution for spousal support can help. <a href="/contact/">Contact us today</a> and we’ll evaluate your case for free case evaluation and give you more information about our spousal support experience.', 'Alimony/Spousal Support', '', 'inherit', 'closed', 'closed', '', '26-revision-v1', '', '', '2016-05-20 17:55:55', '2016-05-20 17:55:55', '', 26, 'http://tedsmithdemo.com/26-revision-v1/', 0, 'revision', '', 0),
(29, 1, '2016-05-20 18:00:39', '2016-05-20 18:00:39', 'Military divorces can be very different from civilian divorces. Our founding attorney, Ted Smith, has developed a strong practice within our firm for military divorce. His experience as a judge advocate general (JAG) officer at Fort Hood gives us a unique set of skills that can work to your benefit as a military member or spouse of a military member.\r\n<h2>What Makes a Military Divorce Different?</h2>\r\nWhile the grounds for divorce in the military are the same as any other divorce, military members have several protections that prevent them from facing adverse consequences while on active duty. The Service Members Civil Relief Act, for instance, protects military members from having to work through legal proceedings while on duty and for 60 days after they return from active status.\r\n\r\nThe Uniformed Services Former Spouses’ Protection Act (USFSPA) protects a military spouse’s right to military retired pay as the result of some divorce settlements. It also provides enforcement stipulations for child support and spousal support for military couples.\r\n<h2>Where to File for Divorce</h2>\r\nSince military families often move regularly, knowing where to file for divorce can affect the process moving forward. You don’t have to file for a divorce in the state or county where you got married, but you should file in the state where one spouse has an established residency. To qualify for a Texas divorce, you or your spouse must have lived in the state for six months and in the county in which you intend to file for at least three months.\r\n<h2>Child Custody in Military Divorce</h2>\r\nSome active military members worry they cannot keep their parental rights during divorce proceedings. As in any other divorce proceeding, the court will assign custody based on a parent’s ability to provide for the child’s best interests. A military member can share joint custody or obtain full custody and name someone as a temporary custodian while on active duty.\r\n\r\nUnder Texas laws, a military member’s custody and visitation rights might transfer to his or her parents during active duty. As soon as an active member returns, he or she retains custody rights. Furthermore, a military parent may ask for additional visitation time upon returning home.\r\n<h2>Financial Considerations in Military Divorce</h2>\r\nUnderstanding financial obligations during a military divorce is a complex matter. Military members’ child and spousal support payments are determined by Leave and Earnings Statements. Since military pay works differently than a traditional paycheck, having a military divorce specialist walk you through your income considerations can provide peace of mind.\r\n\r\nDuring property division, many military-related assets are subject to division between a military member and spouse, particularly if a couple was married for several years. Understanding what you may owe and what benefits you may have access to can help you protect your right to a fair and equitable division of assets.\r\n\r\nEach case is different, and deserves close examination by a qualified legal specialist. Bring the financial documents you have to your free case evaluation, and we will help you work through the considerations that may affect child custody, property division, and spousal support.\r\n<h2>Handling Military Divorce Cases for Military Members and Spouses</h2>\r\nMilitary divorces do not always take place in the states. If you and your spouse are abroad, our attorneys can help you wherever you are deployed or stationed. In addition to state divorce laws, federal statutes that affect all service members also govern every military divorce.\r\n\r\nAs your military divorce firm, we will not only help you navigate the complex laws that govern divorce agreements; we will also help you find the support you need to move on with your life after a divorce. From helping you connect with military support services to pursuing modifications to support orders, we offer complete in-person and remote divorce services. <a href="/contact/">Contact our team</a> today to set up your free consultation.', 'Military Divorce', '', 'publish', 'closed', 'closed', '', 'military-divorce', '', '', '2016-05-20 18:00:39', '2016-05-20 18:00:39', '', 4, 'http://tedsmithdemo.com/?page_id=29', 0, 'page', '', 0),
(30, 1, '2016-05-20 18:00:39', '2016-05-20 18:00:39', 'Military divorces can be very different from civilian divorces. Our founding attorney, Ted Smith, has developed a strong practice within our firm for military divorce. His experience as a judge advocate general (JAG) officer at Fort Hood gives us a unique set of skills that can work to your benefit as a military member or spouse of a military member.\r\n<h2>What Makes a Military Divorce Different?</h2>\r\nWhile the grounds for divorce in the military are the same as any other divorce, military members have several protections that prevent them from facing adverse consequences while on active duty. The Service Members Civil Relief Act, for instance, protects military members from having to work through legal proceedings while on duty and for 60 days after they return from active status.\r\n\r\nThe Uniformed Services Former Spouses’ Protection Act (USFSPA) protects a military spouse’s right to military retired pay as the result of some divorce settlements. It also provides enforcement stipulations for child support and spousal support for military couples.\r\n<h2>Where to File for Divorce</h2>\r\nSince military families often move regularly, knowing where to file for divorce can affect the process moving forward. You don’t have to file for a divorce in the state or county where you got married, but you should file in the state where one spouse has an established residency. To qualify for a Texas divorce, you or your spouse must have lived in the state for six months and in the county in which you intend to file for at least three months.\r\n<h2>Child Custody in Military Divorce</h2>\r\nSome active military members worry they cannot keep their parental rights during divorce proceedings. As in any other divorce proceeding, the court will assign custody based on a parent’s ability to provide for the child’s best interests. A military member can share joint custody or obtain full custody and name someone as a temporary custodian while on active duty.\r\n\r\nUnder Texas laws, a military member’s custody and visitation rights might transfer to his or her parents during active duty. As soon as an active member returns, he or she retains custody rights. Furthermore, a military parent may ask for additional visitation time upon returning home.\r\n<h2>Financial Considerations in Military Divorce</h2>\r\nUnderstanding financial obligations during a military divorce is a complex matter. Military members’ child and spousal support payments are determined by Leave and Earnings Statements. Since military pay works differently than a traditional paycheck, having a military divorce specialist walk you through your income considerations can provide peace of mind.\r\n\r\nDuring property division, many military-related assets are subject to division between a military member and spouse, particularly if a couple was married for several years. Understanding what you may owe and what benefits you may have access to can help you protect your right to a fair and equitable division of assets.\r\n\r\nEach case is different, and deserves close examination by a qualified legal specialist. Bring the financial documents you have to your free case evaluation, and we will help you work through the considerations that may affect child custody, property division, and spousal support.\r\n<h2>Handling Military Divorce Cases for Military Members and Spouses</h2>\r\nMilitary divorces do not always take place in the states. If you and your spouse are abroad, our attorneys can help you wherever you are deployed or stationed. In addition to state divorce laws, federal statutes that affect all service members also govern every military divorce.\r\n\r\nAs your military divorce firm, we will not only help you navigate the complex laws that govern divorce agreements; we will also help you find the support you need to move on with your life after a divorce. From helping you connect with military support services to pursuing modifications to support orders, we offer complete in-person and remote divorce services. <a href="/contact/">Contact our team</a> today to set up your free consultation.', 'Military Divorce', '', 'inherit', 'closed', 'closed', '', '29-revision-v1', '', '', '2016-05-20 18:00:39', '2016-05-20 18:00:39', '', 29, 'http://tedsmithdemo.com/29-revision-v1/', 0, 'revision', '', 0),
(31, 1, '2016-05-20 18:01:48', '2016-05-20 18:01:48', 'Serious injuries can change the course of peoples’ lives, including their physical, emotional, and financial health. When someone else’s carelessness results in an injurious accident, the injured party has the right to take action.\r\n\r\nAt Ted Smith Law Group, PLLC, we handle all kinds of personal injury cases throughout the state of Texas. Whether you are fighting against an insurance company that isn’t taking your claim seriously, or a negligent defendant who should have taken reasonable precautions, we will hold every liable party financially accountable for their actions.\r\n<h2>Helping People Recover One Day at a Time</h2>\r\nFor many people, a personal injury lawsuit is the only course of action seriously injured individuals can take. They may have medical bills, utility bills, and living expenses piling up without the ability to go back to work or resume their normal lives. Our firm helps seriously injured people find the financial support they need to cover current and future medical expenses, lost wages, loss of quality of life, and more.\r\n\r\nIf a vehicle accident, a property liability accident, a defective product accident, or an act of medical malpractice injures you or someone you love, our firm is standing by to help. You will not see a bill from us until we secure compensation on your behalf. In addition to relentlessly protecting your rights under civil law, we will act as your compassionate supporter and help you postpone medical bills and negotiate with insurance companies on your behalf so that you and your family can focus on recovery.\r\n<h2>Texas and Modified Comparative Negligence</h2>\r\nIn Texas, the courts will assign those involved in the incident a percentage of fault. If you are more than 50% at fault for an accident, you cannot collect compensation. For every percentage point of fault the courts assign, your total compensation will decrease proportionately.\r\n\r\nTo prove negligence, our firm will present evidence to support the following elements:\r\n<ul>\r\n 	<li>The defendant owed you some level of care,</li>\r\n 	<li>The defendant failed to honor that obligation,</li>\r\n 	<li>That obligation caused an injurious incident, and</li>\r\n 	<li>You were seriously injured as a result.</li>\r\n</ul>\r\nIn some cases, such as medical malpractice, we need only prove the nature of an injury using a standard called res ipsa loquitur. We do not necessarily need to prove each element of negligence.\r\n\r\nNegligence is the basis for most personal injury cases, and understanding how the process works can help you determine if you might have an actionable case. If you believe that negligence was involved in your injury, whether a building owner failed to tighten a handrail or you were part of a hit-and-run accident, reach out to our attorneys for a free case evaluation.\r\n<h2>Personal Injury Liability</h2>\r\nSomeone else may be at fault for your injuries, even if you were the only one around during the accident. Defective auto parts, malfunctioning machinery components, and negligent property care can all contribute to an accident that would not have happened under normal circumstances. When our firm accepts a personal injury case, we pursue investigations against all parties who may have played a role in your injury. Potential defendants may include:\r\n<ul>\r\n 	<li>Property owners</li>\r\n 	<li>Product manufacturers, including pharmaceutical companies</li>\r\n 	<li>Company owners</li>\r\n 	<li>Drivers and other civilians</li>\r\n 	<li>Health care professionals</li>\r\n</ul>\r\nIn addition to a primary personal injury case, we often pursue action against insurance companies that wrongfully deny or delay our clients’ claims. Insurance companies play a role in most personal injury cases.\r\n\r\nIf a preventable accident turns your life upside down, our compassionate attorneys will not stop until we help you receive the financial compensation you need and deserve. <a href="/contact/">Contact us today</a> to schedule a free consultation.', 'Personal Injury', '', 'publish', 'closed', 'closed', '', 'personal-injury', '', '', '2016-05-20 18:01:48', '2016-05-20 18:01:48', '', 0, 'http://tedsmithdemo.com/?page_id=31', 0, 'page', '', 0),
(32, 1, '2016-05-20 18:01:48', '2016-05-20 18:01:48', 'Serious injuries can change the course of peoples’ lives, including their physical, emotional, and financial health. When someone else’s carelessness results in an injurious accident, the injured party has the right to take action.\r\n\r\nAt Ted Smith Law Group, PLLC, we handle all kinds of personal injury cases throughout the state of Texas. Whether you are fighting against an insurance company that isn’t taking your claim seriously, or a negligent defendant who should have taken reasonable precautions, we will hold every liable party financially accountable for their actions.\r\n<h2>Helping People Recover One Day at a Time</h2>\r\nFor many people, a personal injury lawsuit is the only course of action seriously injured individuals can take. They may have medical bills, utility bills, and living expenses piling up without the ability to go back to work or resume their normal lives. Our firm helps seriously injured people find the financial support they need to cover current and future medical expenses, lost wages, loss of quality of life, and more.\r\n\r\nIf a vehicle accident, a property liability accident, a defective product accident, or an act of medical malpractice injures you or someone you love, our firm is standing by to help. You will not see a bill from us until we secure compensation on your behalf. In addition to relentlessly protecting your rights under civil law, we will act as your compassionate supporter and help you postpone medical bills and negotiate with insurance companies on your behalf so that you and your family can focus on recovery.\r\n<h2>Texas and Modified Comparative Negligence</h2>\r\nIn Texas, the courts will assign those involved in the incident a percentage of fault. If you are more than 50% at fault for an accident, you cannot collect compensation. For every percentage point of fault the courts assign, your total compensation will decrease proportionately.\r\n\r\nTo prove negligence, our firm will present evidence to support the following elements:\r\n<ul>\r\n 	<li>The defendant owed you some level of care,</li>\r\n 	<li>The defendant failed to honor that obligation,</li>\r\n 	<li>That obligation caused an injurious incident, and</li>\r\n 	<li>You were seriously injured as a result.</li>\r\n</ul>\r\nIn some cases, such as medical malpractice, we need only prove the nature of an injury using a standard called res ipsa loquitur. We do not necessarily need to prove each element of negligence.\r\n\r\nNegligence is the basis for most personal injury cases, and understanding how the process works can help you determine if you might have an actionable case. If you believe that negligence was involved in your injury, whether a building owner failed to tighten a handrail or you were part of a hit-and-run accident, reach out to our attorneys for a free case evaluation.\r\n<h2>Personal Injury Liability</h2>\r\nSomeone else may be at fault for your injuries, even if you were the only one around during the accident. Defective auto parts, malfunctioning machinery components, and negligent property care can all contribute to an accident that would not have happened under normal circumstances. When our firm accepts a personal injury case, we pursue investigations against all parties who may have played a role in your injury. Potential defendants may include:\r\n<ul>\r\n 	<li>Property owners</li>\r\n 	<li>Product manufacturers, including pharmaceutical companies</li>\r\n 	<li>Company owners</li>\r\n 	<li>Drivers and other civilians</li>\r\n 	<li>Health care professionals</li>\r\n</ul>\r\nIn addition to a primary personal injury case, we often pursue action against insurance companies that wrongfully deny or delay our clients’ claims. Insurance companies play a role in most personal injury cases.\r\n\r\nIf a preventable accident turns your life upside down, our compassionate attorneys will not stop until we help you receive the financial compensation you need and deserve. <a href="/contact/">Contact us today</a> to schedule a free consultation.', 'Personal Injury', '', 'inherit', 'closed', 'closed', '', '31-revision-v1', '', '', '2016-05-20 18:01:48', '2016-05-20 18:01:48', '', 31, 'http://tedsmithdemo.com/31-revision-v1/', 0, 'revision', '', 0),
(33, 1, '2016-05-20 18:03:00', '2016-05-20 18:03:00', 'Car accidents happen every day in Texas. Distracted driving, tired driving, road rage drivers, badly maintained roadways, and improper signage are all negligence that contributes to traffic accidents. When someone’s momentary lapse of attention or reckless driving caused you harm, you may be eligible to receive financial compensation for your damages.\r\n\r\nCommon acts of negligence include failing to yield right of way, running a red light, changing lanes without using a blinker, or rear-ending another vehicle. Acts of reckless driving include DUI, driving at high speeds, or racing another vehicle. In Texas, if a negligent driver causes your injuries, you may be entitled to receive monies for your medical bills, pain and suffering, and property damage. If the negligent driver was reckless, you can also obtain punitive or special damages.\r\n<h2>Proving Negligence in a Car Accident</h2>\r\nThe most difficult part of most negligence cases is proving who is at fault. In some car accidents, fault is nonnegotiable. For instance, if the other driver was intoxicated and driving the wrong way on the highway, that driver is at fault for the accident. In many cases, however, proving negligence is less obvious.\r\n\r\nProving negligence in a car accident requires an in-depth investigation of the crash. This involves taking photos at the scene of the crash, interviewing eyewitnesses, hiring a key witness (usually a doctor) to attest to your injuries in court, and a variety of other important factors. For the best chance of winning compensation from a negligent party, hire an experienced local car accident attorney.\r\n\r\nIn Texas, the courts follow a comparative negligence system that allocates fault between both parties. In some accidents, both drivers are at fault. Even in a rear-end collision, the jury may find either, both, or neither driver at fault for the accident. If the court assigns you an at-fault percentage of more than 50%, you will not recovery anything.\r\n\r\nProving the other driver’s percentage of fault can make a big difference in how much you receive in a settlement. Even if you know the other driver was at fault for your accident, he or she may have a suitable defense for the negligent action. There are two sides to every story: make sure the lawyer representing your side has the ability to prove your innocence before a jury.\r\n<h2>Skilled Texas Car Accident Attorneys</h2>\r\nTed Smith has represented clients in central Texas for almost 40 years. Our team of expert personal injury attorneys have come to the aid of numerous car accident victims to win financial compensation from negligent parties. We understand how stressful and time-consuming a personal injury lawsuit can be to an injured person, but we are here to make the process easier.\r\n\r\nWhen you need peace of mind after an accident, trust Ted Smith Law Group, PLLC. We have represented a variety of auto accidents throughout central Texas, including:\r\n<ul>\r\n 	<li>Car accidents</li>\r\n 	<li>Bus accidents</li>\r\n 	<li>Motorcycle accidents</li>\r\n 	<li>Semi-truck accidents</li>\r\n 	<li>Pedestrian accidents</li>\r\n 	<li>Bicycle accidents</li>\r\n 	<li>Uninsured motorist accidents</li>\r\n 	<li>Property damage accidents</li>\r\n</ul>\r\nWhen you work with Ted Smith Law Group, PLLC, you will experience a law firm completely dedicated to your success. We stay in contact with our clients throughout the trial and negotiation processes, so they are never left in the dark about their case. The right lawyer can make or break your car accident claim.\r\n\r\nOur fees are based on contingency, which means you do not pay a cent unless we win a settlement for your damages. Call (254) 690-5688 to <a href="/contact/">get in touch with our passionate, capable personal injury attorneys</a>. We offer a free consultation with one of our car accident lawyers who are happy to discuss your case in detail and provide more information.', 'Car Accidents', '', 'publish', 'closed', 'closed', '', 'car-accidents', '', '', '2016-05-20 18:03:00', '2016-05-20 18:03:00', '', 31, 'http://tedsmithdemo.com/?page_id=33', 0, 'page', '', 0),
(34, 1, '2016-05-20 18:03:00', '2016-05-20 18:03:00', 'Car accidents happen every day in Texas. Distracted driving, tired driving, road rage drivers, badly maintained roadways, and improper signage are all negligence that contributes to traffic accidents. When someone’s momentary lapse of attention or reckless driving caused you harm, you may be eligible to receive financial compensation for your damages.\r\n\r\nCommon acts of negligence include failing to yield right of way, running a red light, changing lanes without using a blinker, or rear-ending another vehicle. Acts of reckless driving include DUI, driving at high speeds, or racing another vehicle. In Texas, if a negligent driver causes your injuries, you may be entitled to receive monies for your medical bills, pain and suffering, and property damage. If the negligent driver was reckless, you can also obtain punitive or special damages.\r\n<h2>Proving Negligence in a Car Accident</h2>\r\nThe most difficult part of most negligence cases is proving who is at fault. In some car accidents, fault is nonnegotiable. For instance, if the other driver was intoxicated and driving the wrong way on the highway, that driver is at fault for the accident. In many cases, however, proving negligence is less obvious.\r\n\r\nProving negligence in a car accident requires an in-depth investigation of the crash. This involves taking photos at the scene of the crash, interviewing eyewitnesses, hiring a key witness (usually a doctor) to attest to your injuries in court, and a variety of other important factors. For the best chance of winning compensation from a negligent party, hire an experienced local car accident attorney.\r\n\r\nIn Texas, the courts follow a comparative negligence system that allocates fault between both parties. In some accidents, both drivers are at fault. Even in a rear-end collision, the jury may find either, both, or neither driver at fault for the accident. If the court assigns you an at-fault percentage of more than 50%, you will not recovery anything.\r\n\r\nProving the other driver’s percentage of fault can make a big difference in how much you receive in a settlement. Even if you know the other driver was at fault for your accident, he or she may have a suitable defense for the negligent action. There are two sides to every story: make sure the lawyer representing your side has the ability to prove your innocence before a jury.\r\n<h2>Skilled Texas Car Accident Attorneys</h2>\r\nTed Smith has represented clients in central Texas for almost 40 years. Our team of expert personal injury attorneys have come to the aid of numerous car accident victims to win financial compensation from negligent parties. We understand how stressful and time-consuming a personal injury lawsuit can be to an injured person, but we are here to make the process easier.\r\n\r\nWhen you need peace of mind after an accident, trust Ted Smith Law Group, PLLC. We have represented a variety of auto accidents throughout central Texas, including:\r\n<ul>\r\n 	<li>Car accidents</li>\r\n 	<li>Bus accidents</li>\r\n 	<li>Motorcycle accidents</li>\r\n 	<li>Semi-truck accidents</li>\r\n 	<li>Pedestrian accidents</li>\r\n 	<li>Bicycle accidents</li>\r\n 	<li>Uninsured motorist accidents</li>\r\n 	<li>Property damage accidents</li>\r\n</ul>\r\nWhen you work with Ted Smith Law Group, PLLC, you will experience a law firm completely dedicated to your success. We stay in contact with our clients throughout the trial and negotiation processes, so they are never left in the dark about their case. The right lawyer can make or break your car accident claim.\r\n\r\nOur fees are based on contingency, which means you do not pay a cent unless we win a settlement for your damages. Call (254) 690-5688 to <a href="/contact/">get in touch with our passionate, capable personal injury attorneys</a>. We offer a free consultation with one of our car accident lawyers who are happy to discuss your case in detail and provide more information.', 'Car Accidents', '', 'inherit', 'closed', 'closed', '', '33-revision-v1', '', '', '2016-05-20 18:03:00', '2016-05-20 18:03:00', '', 33, 'http://tedsmithdemo.com/33-revision-v1/', 0, 'revision', '', 0),
(35, 1, '2016-05-20 18:15:32', '2016-05-20 18:15:32', 'Victims of truck accidents know the incredibly violent nature of crashes involving semi-trucks on the roadway. The size and weight of semi-trucks increase the velocity and gravitational forces in an accident, leading to worse injuries and often long-lasting disabilities. If you have been injured in a truck accident due to someone else’s negligence, you should not have to suffer without financial compensation.\r\n<h2>Common Reasons for Truck Accidents</h2>\r\nThe trucking industry is infamous for imposing strict deadlines on drivers to reach their destinations. Drivers often feel pressured to travel long hours on the highway, even when they are drowsy. While there is a requirement for commercial truck drivers to get adequate rest between shifts, often drivers cannot sleep during odd hours or fail to sleep on command.\r\n\r\nMany truck drivers travel at night during the normal sleep cycle. Drowsy truck drivers are at risk of falling asleep behind the wheel. They may drift in and out of their lane and collide with other vehicles. Proving drowsiness was the cause of an accident is difficult, but it may be done with experienced lawyers. To prove a truck driver was too tired to safely operate a vehicle, our lawyers look at traffic cameras, interview eyewitnesses, gain access to driver data recorders, and more.\r\n\r\nAnother common factor behind truck accidents is driving under the influence of drugs or alcohol. Even though truck drivers have the added responsibility of operating a large vehicle, they make mistakes like other automobile drivers. When the police catch a commercial truck driver driving under the influence, the legal consequences are severe. When a DUI truck driver causes an accident, the courts can hold him or her responsible for damages.\r\n\r\nLike most states, Texas imposes a stricter blood alcohol content (BAC) level on commercial drivers than other drivers. While the legal limit for a non-commercial driver is 0.08 in Texas, the limit for commercial drivers is 0.04 BAC—punishable by a commercial driver DUI. A BAC as low as 0.02 in truck drivers results in a 24-hour commercial driving suspension. If a DUI truck driver caused your accident, your lawyer can use the defendant’s BAC results to prove negligence.\r\n<h2>Commercial Truck Driver Liability Insurance</h2>\r\nEvery commercial truck driver has some form of insurance coverage. State and federal laws in Texas make insurance mandatory for truck drivers depending on what the vehicle hauls. When you are involved in a truck accident, a representative from the trucking enterprise’s insurance company will likely call you.\r\n\r\nThe person you will speak to is the <a href="http://www.nolo.com/legal-encyclopedia/insurance-adjusters-who-they-are-how-they-handle-injury-claim.html" target="_blank">insurance adjuster</a>, a specialist the company hires to negotiate a settlement with the victim of an accident. After an accident, it is difficult to know how to handle these conversations. The role of the adjuster is to secure a settlement without going to court. The price the adjuster offers is generally less than what a plaintiff would receive in court, but the idea of avoiding a trial tempts many people.\r\n\r\nThe insurance adjuster can use anything you say over the phone against you in court. If you give too many details about your accident, you may hurt your chances of winning compensation. It is important to know how to handle the initial conversation with insurance adjusters or to let your attorney speak with them instead.\r\n<h2>Your Local Truck Accident Lawyers</h2>\r\nIf you need someone to come to your defense in a truck accident case, trust Ted Smith Law Group, PLLC. We have helped clients throughout central Texas obtain financial compensation for medical expenses, pain and suffering, lost wages, lost earning capacity, and other damages from negligent truck drivers. <a href="/contact/">Contact us today</a> for a free case evaluation with one of our compassionate accident attorneys.', 'Truck Accidents', '', 'publish', 'closed', 'closed', '', 'truck-accidents', '', '', '2016-05-20 18:15:32', '2016-05-20 18:15:32', '', 31, 'http://tedsmithdemo.com/?page_id=35', 0, 'page', '', 0),
(36, 1, '2016-05-20 18:15:32', '2016-05-20 18:15:32', 'Victims of truck accidents know the incredibly violent nature of crashes involving semi-trucks on the roadway. The size and weight of semi-trucks increase the velocity and gravitational forces in an accident, leading to worse injuries and often long-lasting disabilities. If you have been injured in a truck accident due to someone else’s negligence, you should not have to suffer without financial compensation.\r\n<h2>Common Reasons for Truck Accidents</h2>\r\nThe trucking industry is infamous for imposing strict deadlines on drivers to reach their destinations. Drivers often feel pressured to travel long hours on the highway, even when they are drowsy. While there is a requirement for commercial truck drivers to get adequate rest between shifts, often drivers cannot sleep during odd hours or fail to sleep on command.\r\n\r\nMany truck drivers travel at night during the normal sleep cycle. Drowsy truck drivers are at risk of falling asleep behind the wheel. They may drift in and out of their lane and collide with other vehicles. Proving drowsiness was the cause of an accident is difficult, but it may be done with experienced lawyers. To prove a truck driver was too tired to safely operate a vehicle, our lawyers look at traffic cameras, interview eyewitnesses, gain access to driver data recorders, and more.\r\n\r\nAnother common factor behind truck accidents is driving under the influence of drugs or alcohol. Even though truck drivers have the added responsibility of operating a large vehicle, they make mistakes like other automobile drivers. When the police catch a commercial truck driver driving under the influence, the legal consequences are severe. When a DUI truck driver causes an accident, the courts can hold him or her responsible for damages.\r\n\r\nLike most states, Texas imposes a stricter blood alcohol content (BAC) level on commercial drivers than other drivers. While the legal limit for a non-commercial driver is 0.08 in Texas, the limit for commercial drivers is 0.04 BAC—punishable by a commercial driver DUI. A BAC as low as 0.02 in truck drivers results in a 24-hour commercial driving suspension. If a DUI truck driver caused your accident, your lawyer can use the defendant’s BAC results to prove negligence.\r\n<h2>Commercial Truck Driver Liability Insurance</h2>\r\nEvery commercial truck driver has some form of insurance coverage. State and federal laws in Texas make insurance mandatory for truck drivers depending on what the vehicle hauls. When you are involved in a truck accident, a representative from the trucking enterprise’s insurance company will likely call you.\r\n\r\nThe person you will speak to is the <a href="http://www.nolo.com/legal-encyclopedia/insurance-adjusters-who-they-are-how-they-handle-injury-claim.html" target="_blank">insurance adjuster</a>, a specialist the company hires to negotiate a settlement with the victim of an accident. After an accident, it is difficult to know how to handle these conversations. The role of the adjuster is to secure a settlement without going to court. The price the adjuster offers is generally less than what a plaintiff would receive in court, but the idea of avoiding a trial tempts many people.\r\n\r\nThe insurance adjuster can use anything you say over the phone against you in court. If you give too many details about your accident, you may hurt your chances of winning compensation. It is important to know how to handle the initial conversation with insurance adjusters or to let your attorney speak with them instead.\r\n<h2>Your Local Truck Accident Lawyers</h2>\r\nIf you need someone to come to your defense in a truck accident case, trust Ted Smith Law Group, PLLC. We have helped clients throughout central Texas obtain financial compensation for medical expenses, pain and suffering, lost wages, lost earning capacity, and other damages from negligent truck drivers. <a href="/contact/">Contact us today</a> for a free case evaluation with one of our compassionate accident attorneys.', 'Truck Accidents', '', 'inherit', 'closed', 'closed', '', '35-revision-v1', '', '', '2016-05-20 18:15:32', '2016-05-20 18:15:32', '', 35, 'http://tedsmithdemo.com/35-revision-v1/', 0, 'revision', '', 0),
(37, 1, '2016-05-20 18:16:14', '2016-05-20 18:16:14', 'More bus accidents occur in Texas than you may realize. Citizens presume public transportation employs highly trained and competent drivers, but bus drivers are only human. Just like other drivers, they are prone to making errors behind the wheel. Bus accidents are traumatic for everyone involved, but victims may be able to obtain financial compensation for their medical, emotional, and financial damages.\r\n<h2>Who Is Responsible for Bus Accidents?</h2>\r\nWhen a bus accident occurs, placing fault can be difficult. It is the plaintiff’s job to prove that someone else was negligent in his or her duties, and that this negligence caused the accident. Bus accidents—school buses, charter buses, party buses, tour buses, or public buses—not only involve the driver, but also the bus company, the manufacturer, the school district, and/or the county.\r\n\r\nDespite having the added responsibility of multiple passengers, bus drivers drive distracted just like other drivers. Texting and driving, drowsy driving, and even DUIs all contribute to bus accidents in Texas. Human error causes buses to veer off the road, collide with other vehicles, and even run into pedestrians.\r\n\r\nMany bus accidents are not due to human error, but by part-malfunction or maintenance negligence. Texas law requires commercial and public buses to undergo checks to maintain the highest standards of safety. If a maintenance crew improperly services a bus, leading to brake failure or another dangerous issue, the courts can hold the crew responsible for the accident.\r\n\r\nHowever, if a piece of equipment from the bus manufacturer failed and caused the accident, the courts can hold the manufacturing company responsible. If driver negligence caused the accident, the courts can hold the driver and potentially the bus company liable for damages. If, for example, the enterprise was negligent and hired a driver with a history of DUI, the accident may be partially the company’s fault.\r\n<h2>How to File a Bus Accident Claim</h2>\r\nIf you have been involved in a bus accident involving personal injury, you may be at a loss as to how to pursue a lawsuit. The first step is to seek medical attention for your injuries. Our first priority is your personal health, and you need to visit a healthcare professional immediately after an accident.\r\n\r\nDelaying a doctor’s visit looks bad during a case; it gives the jurors reason to believe your injuries were not severe enough for you to seek medical attention. You need a doctor to document your injuries. Save this documentation as a record of expenses you have paid for medical care relating to the accident. After a doctor has taken care of your injuries, seek legal representation.\r\n\r\nBus accident negligence claims involve complex factors such as company liability, federal and state public transportation laws, and negotiations with insurance companies. To file a claim properly, hire lawyers with experience handling bus accidents. When you work with a bus accident lawyer, he or she will handle communication with insurance companies and the courts.\r\n\r\nYour lawyer will file the claim against the defendant and conduct an investigation into the case. The investigation involves gathering photographic evidence of the crash, interviewing witnesses, and collecting other relevant data. Often, we can settle a case without the need to go to court. If your case does go to court, you will not pay a cent unless you win.\r\n<h2>Let Ted Smith Law Group, PLLC, Handle Your Case</h2>\r\nTed Smith Law Group, PLLC, knows how to successfully negotiate with insurance adjusters, the defendant’s lawyers, jurors, and everyone else involved in a bus accident case. When you team with Ted Smith, you are free from responsibility. Let us give you peace of mind. <a href="/contact/">Contact us online</a> or call (254) 690-5688 to speak with a local attorney with experience handling bus accident cases.', 'Bus Accidents', '', 'publish', 'closed', 'closed', '', 'bus-accidents', '', '', '2016-05-20 18:16:14', '2016-05-20 18:16:14', '', 31, 'http://tedsmithdemo.com/?page_id=37', 0, 'page', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(38, 1, '2016-05-20 18:16:14', '2016-05-20 18:16:14', 'More bus accidents occur in Texas than you may realize. Citizens presume public transportation employs highly trained and competent drivers, but bus drivers are only human. Just like other drivers, they are prone to making errors behind the wheel. Bus accidents are traumatic for everyone involved, but victims may be able to obtain financial compensation for their medical, emotional, and financial damages.\r\n<h2>Who Is Responsible for Bus Accidents?</h2>\r\nWhen a bus accident occurs, placing fault can be difficult. It is the plaintiff’s job to prove that someone else was negligent in his or her duties, and that this negligence caused the accident. Bus accidents—school buses, charter buses, party buses, tour buses, or public buses—not only involve the driver, but also the bus company, the manufacturer, the school district, and/or the county.\r\n\r\nDespite having the added responsibility of multiple passengers, bus drivers drive distracted just like other drivers. Texting and driving, drowsy driving, and even DUIs all contribute to bus accidents in Texas. Human error causes buses to veer off the road, collide with other vehicles, and even run into pedestrians.\r\n\r\nMany bus accidents are not due to human error, but by part-malfunction or maintenance negligence. Texas law requires commercial and public buses to undergo checks to maintain the highest standards of safety. If a maintenance crew improperly services a bus, leading to brake failure or another dangerous issue, the courts can hold the crew responsible for the accident.\r\n\r\nHowever, if a piece of equipment from the bus manufacturer failed and caused the accident, the courts can hold the manufacturing company responsible. If driver negligence caused the accident, the courts can hold the driver and potentially the bus company liable for damages. If, for example, the enterprise was negligent and hired a driver with a history of DUI, the accident may be partially the company’s fault.\r\n<h2>How to File a Bus Accident Claim</h2>\r\nIf you have been involved in a bus accident involving personal injury, you may be at a loss as to how to pursue a lawsuit. The first step is to seek medical attention for your injuries. Our first priority is your personal health, and you need to visit a healthcare professional immediately after an accident.\r\n\r\nDelaying a doctor’s visit looks bad during a case; it gives the jurors reason to believe your injuries were not severe enough for you to seek medical attention. You need a doctor to document your injuries. Save this documentation as a record of expenses you have paid for medical care relating to the accident. After a doctor has taken care of your injuries, seek legal representation.\r\n\r\nBus accident negligence claims involve complex factors such as company liability, federal and state public transportation laws, and negotiations with insurance companies. To file a claim properly, hire lawyers with experience handling bus accidents. When you work with a bus accident lawyer, he or she will handle communication with insurance companies and the courts.\r\n\r\nYour lawyer will file the claim against the defendant and conduct an investigation into the case. The investigation involves gathering photographic evidence of the crash, interviewing witnesses, and collecting other relevant data. Often, we can settle a case without the need to go to court. If your case does go to court, you will not pay a cent unless you win.\r\n<h2>Let Ted Smith Law Group, PLLC, Handle Your Case</h2>\r\nTed Smith Law Group, PLLC, knows how to successfully negotiate with insurance adjusters, the defendant’s lawyers, jurors, and everyone else involved in a bus accident case. When you team with Ted Smith, you are free from responsibility. Let us give you peace of mind. <a href="/contact/">Contact us online</a> or call (254) 690-5688 to speak with a local attorney with experience handling bus accident cases.', 'Bus Accidents', '', 'inherit', 'closed', 'closed', '', '37-revision-v1', '', '', '2016-05-20 18:16:14', '2016-05-20 18:16:14', '', 37, 'http://tedsmithdemo.com/37-revision-v1/', 0, 'revision', '', 0),
(39, 1, '2016-05-20 18:17:36', '2016-05-20 18:17:36', 'Car accidents involving bicycles are particularly injurious due to the exposure of the bicyclist. Even with a helmet, bicyclists can be severely injured or killed in accidents involving motor vehicles. The law obligates drivers to be aware of bicyclists while behind the wheel and to give bicyclists plenty of room on the road. Unfortunately, many drivers ignore these laws and end up hitting unsuspecting bicyclists.\r\n<h2>What Does Texas Law Say About Bicycles?</h2>\r\nClients involved in bicycle accidents often ask about <a href="http://www.nolo.com/legal-encyclopedia/state-bicycle-helmet-laws.html" target="_blank">bicycle helmet laws in Texas</a>. No state in the United States currently enforces a law that makes it mandatory for adults to wear helmets. However, Dallas has its own city ordinance requiring bicyclists of all ages to wear a helmet while riding.\r\n\r\nIf you are involved in a bicycle accident and sustain a head injury, the jury will look at your use of a helmet. If the city you were in required helmets while riding and you failed to obey this rule, the courts may be less likely to grant you compensation for your injuries. Some plaintiffs have to prove the accident would have caused a head injury even if they had worn a helmet.\r\n\r\nIn Texas, the law states that bicyclists have the same rights and duties as drivers operating a vehicle. Bicyclists must take due care to follow state laws, such as having the correct lights on the bike to ride at night. Many drivers get irritated by bicyclists on the roadway and ride too closely to them. Although the law allows bicycles on the road with other vehicles, many motor vehicle operators ignore this rule and drive recklessly near bicyclists.\r\n<h2>Who Is Responsible in a Bicycle Accident?</h2>\r\nOften, a negligent driver causes accidents involving bicycles. Distracted driving, such as texting, eating, or personal grooming, can result in a driver failing to notice a bicyclist on the roadway or crossing an intersection, leading to a collision. Bicyclists are at increased risk at intersections, where it is common for a turning vehicle not to watch for crossing bikers while executing a turn.\r\n\r\nIf driver error caused the accident, the courts will hold the driver responsible for the plaintiff’s damages, including medical costs and pain and suffering. In Texas, it is possible for the courts to allocate fault between both parties if the plaintiff is partially responsible for the accident. Do not assume the defendant is automatically at fault because you were on a bike.\r\n\r\nCyclists who ride negligently, do not keep a proper lookout, or ignore the rules of the road may share responsibility for an accident. For example, if a biker crossed an intersection without waiting for the walk signal, but the driver was texting and did not notice the biker crossing, the courts may split fault between both parties for an accident. In this case, our state’s comparative negligence system would allocate a certain percentage of fault between both parties.\r\n\r\nIf the court finds you over 50% at fault, you will receive zero compensation for damages. It is important to invest in a quality lawyer to decrease your chances of the courts finding you more than 50% at fault. Hire a personal injury attorney to ensure the best chance of winning fair compensation for your injuries and property damage.\r\n<h2>Personal Injury Lawyers Who Make a Difference</h2>\r\nOur skilled personal injury attorneys believe you should focus on recovery instead of maneuvering a difficult court case. For a free case evaluation, <a href="/contact/">contact us</a> to speak with one of our friendly representatives. Ted Smith Law Group, PLLC, can help you get back on your feet. With almost 40 years of legal expertise, Ted Smith and his team of attorneys know what it takes to win a bicycle accident case involving someone else’s negligence. Call us today for expert legal advice.', 'Bicycle Accidents', '', 'publish', 'closed', 'closed', '', 'bicycle-accidents', '', '', '2016-05-20 18:17:36', '2016-05-20 18:17:36', '', 31, 'http://tedsmithdemo.com/?page_id=39', 0, 'page', '', 0),
(40, 1, '2016-05-20 18:17:36', '2016-05-20 18:17:36', 'Car accidents involving bicycles are particularly injurious due to the exposure of the bicyclist. Even with a helmet, bicyclists can be severely injured or killed in accidents involving motor vehicles. The law obligates drivers to be aware of bicyclists while behind the wheel and to give bicyclists plenty of room on the road. Unfortunately, many drivers ignore these laws and end up hitting unsuspecting bicyclists.\r\n<h2>What Does Texas Law Say About Bicycles?</h2>\r\nClients involved in bicycle accidents often ask about <a href="http://www.nolo.com/legal-encyclopedia/state-bicycle-helmet-laws.html" target="_blank">bicycle helmet laws in Texas</a>. No state in the United States currently enforces a law that makes it mandatory for adults to wear helmets. However, Dallas has its own city ordinance requiring bicyclists of all ages to wear a helmet while riding.\r\n\r\nIf you are involved in a bicycle accident and sustain a head injury, the jury will look at your use of a helmet. If the city you were in required helmets while riding and you failed to obey this rule, the courts may be less likely to grant you compensation for your injuries. Some plaintiffs have to prove the accident would have caused a head injury even if they had worn a helmet.\r\n\r\nIn Texas, the law states that bicyclists have the same rights and duties as drivers operating a vehicle. Bicyclists must take due care to follow state laws, such as having the correct lights on the bike to ride at night. Many drivers get irritated by bicyclists on the roadway and ride too closely to them. Although the law allows bicycles on the road with other vehicles, many motor vehicle operators ignore this rule and drive recklessly near bicyclists.\r\n<h2>Who Is Responsible in a Bicycle Accident?</h2>\r\nOften, a negligent driver causes accidents involving bicycles. Distracted driving, such as texting, eating, or personal grooming, can result in a driver failing to notice a bicyclist on the roadway or crossing an intersection, leading to a collision. Bicyclists are at increased risk at intersections, where it is common for a turning vehicle not to watch for crossing bikers while executing a turn.\r\n\r\nIf driver error caused the accident, the courts will hold the driver responsible for the plaintiff’s damages, including medical costs and pain and suffering. In Texas, it is possible for the courts to allocate fault between both parties if the plaintiff is partially responsible for the accident. Do not assume the defendant is automatically at fault because you were on a bike.\r\n\r\nCyclists who ride negligently, do not keep a proper lookout, or ignore the rules of the road may share responsibility for an accident. For example, if a biker crossed an intersection without waiting for the walk signal, but the driver was texting and did not notice the biker crossing, the courts may split fault between both parties for an accident. In this case, our state’s comparative negligence system would allocate a certain percentage of fault between both parties.\r\n\r\nIf the court finds you over 50% at fault, you will receive zero compensation for damages. It is important to invest in a quality lawyer to decrease your chances of the courts finding you more than 50% at fault. Hire a personal injury attorney to ensure the best chance of winning fair compensation for your injuries and property damage.\r\n<h2>Personal Injury Lawyers Who Make a Difference</h2>\r\nOur skilled personal injury attorneys believe you should focus on recovery instead of maneuvering a difficult court case. For a free case evaluation, <a href="/contact/">contact us</a> to speak with one of our friendly representatives. Ted Smith Law Group, PLLC, can help you get back on your feet. With almost 40 years of legal expertise, Ted Smith and his team of attorneys know what it takes to win a bicycle accident case involving someone else’s negligence. Call us today for expert legal advice.', 'Bicycle Accidents', '', 'inherit', 'closed', 'closed', '', '39-revision-v1', '', '', '2016-05-20 18:17:36', '2016-05-20 18:17:36', '', 39, 'http://tedsmithdemo.com/39-revision-v1/', 0, 'revision', '', 0),
(41, 1, '2016-05-20 18:18:34', '2016-05-20 18:18:34', 'In a pedestrian accident, the pedestrian is usually injured far worse than the negligent driver. When a pedestrian is involved in a traffic accident, he or she can sustain lifelong injuries. Common injuries associated with pedestrian accidents are traumatic brain injury, internal bleeding, and leg and pelvis injuries.\r\n\r\nIf the injured pedestrian survives the accident, he or she has to cope with medical expenses, temporary or permanent disability, lost wages, lost earning capacity, and immeasurable pain and suffering. If you or a loved one is the victim of a pedestrian accident, you have the right to sue the negligent party to obtain financial compensation for these damages.\r\n<h2>Common Causes of Pedestrian Accidents</h2>\r\nMost pedestrian accidents occur between 6 p.m. and midnight, when nighttime vision impairment, increased pedestrian traffic, and alcohol consumption (by the driver and pedestrian) may cause a collision. Common causes of pedestrian accidents include:\r\n<ul>\r\n 	<li>Driver distraction</li>\r\n 	<li>Driving while intoxicated</li>\r\n 	<li>Speeding drivers</li>\r\n 	<li>Poor city planning</li>\r\n 	<li>Lack of crosswalks and/or signage</li>\r\n</ul>\r\nChildren under the age of 16 are the most common victims of pedestrian accidents. Between lack of parental supervision and lack of road awareness, children are likely to run into the road without checking for vehicles. Often, risky driving contributes to these accidents, such as drivers speeding through school zones or residential neighborhoods.\r\n\r\nOlder pedestrians are also at increased risk of a pedestrian accident. Due to physical limitations concerning vision, hearing, and reflexes, the elderly may not be aware of oncoming traffic. Accidents involving the elderly have worse consequences than other pedestrian accidents and often result in permanent disability or death.\r\n\r\nIn most pedestrian accidents, the driver was negligent in his or her duties to drive safely and attentively. Distracted driving is common throughout Texas, as more and more people check their mobile devices on the go. Driver error (such as DUI) is also common, especially at night. Many accidents, however, could have been prevented with proper roadside signage and crosswalks.\r\n\r\nPoor city planning, such as a lack of proper sidewalks or failing to provide a crosswalk at an intersection, contributes to a percentage of pedestrian accidents in central Texas. In large cities such as Houston and Dallas, pedestrian accidents occur more frequently—often because a driver does not realize a pedestrian is crossing.\r\n\r\nFailure to maintain sidewalks and road signs can lead to pedestrians crossing the road when they should not, without realizing that oncoming traffic is not stopping. In these situations, the victim may sue the city or those responsible for maintaining the roadway. Whether driver negligence or a property defect caused your injury, you may be able to recover damages.\r\n<h2>Proving Negligence</h2>\r\nThe main step in a pedestrian accident case is proving which party’s negligence caused the accident. Texas has a comparative negligence system, in which the courts can split liability between two parties. For example, if a pedestrian was intoxicated and the driver was not paying attention, the courts may allocate a percentage of fault to both parties.\r\n\r\nTo win compensation, the plaintiff must prove the defendant failed to provide his or her legal duty to the plaintiff under the circumstances and that this breach caused an injury. Victims in pedestrian accidents need to hire a skilled personal injury lawyer to help them with these cases if and when they go to court.\r\n<h2>Texas Personal Injury Attorneys You Can Trust</h2>\r\nWhen Ted Smith Law Group, PLLC, takes on a client involved in a pedestrian accident, we anticipate moderate to severe injuries, permanent disability, and even wrongful death. Our law group is equipped to handle the most complex pedestrian accident cases and is proud to be the firm of choice for injured pedestrians throughout central Texas. If you need legal representation for your case, <a href="/contact/">contact us today</a> for a free consultation.', 'Pedestrian Accidents', '', 'publish', 'closed', 'closed', '', 'pedestrian-accidents', '', '', '2016-05-20 18:18:42', '2016-05-20 18:18:42', '', 31, 'http://tedsmithdemo.com/?page_id=41', 0, 'page', '', 0),
(42, 1, '2016-05-20 18:18:34', '2016-05-20 18:18:34', 'In a pedestrian accident, the pedestrian is usually injured far worse than the negligent driver. When a pedestrian is involved in a traffic accident, he or she can sustain lifelong injuries. Common injuries associated with pedestrian accidents are traumatic brain injury, internal bleeding, and leg and pelvis injuries.\r\n\r\nIf the injured pedestrian survives the accident, he or she has to cope with medical expenses, temporary or permanent disability, lost wages, lost earning capacity, and immeasurable pain and suffering. If you or a loved one is the victim of a pedestrian accident, you have the right to sue the negligent party to obtain financial compensation for these damages.\r\n<h2>Common Causes of Pedestrian Accidents</h2>\r\nMost pedestrian accidents occur between 6 p.m. and midnight, when nighttime vision impairment, increased pedestrian traffic, and alcohol consumption (by the driver and pedestrian) may cause a collision. Common causes of pedestrian accidents include:\r\n<ul>\r\n 	<li>Driver distraction</li>\r\n 	<li>Driving while intoxicated</li>\r\n 	<li>Speeding drivers</li>\r\n 	<li>Poor city planning</li>\r\n 	<li>Lack of crosswalks and/or signage</li>\r\n</ul>\r\nChildren under the age of 16 are the most common victims of pedestrian accidents. Between lack of parental supervision and lack of road awareness, children are likely to run into the road without checking for vehicles. Often, risky driving contributes to these accidents, such as drivers speeding through school zones or residential neighborhoods.\r\n\r\nOlder pedestrians are also at increased risk of a pedestrian accident. Due to physical limitations concerning vision, hearing, and reflexes, the elderly may not be aware of oncoming traffic. Accidents involving the elderly have worse consequences than other pedestrian accidents and often result in permanent disability or death.\r\n\r\nIn most pedestrian accidents, the driver was negligent in his or her duties to drive safely and attentively. Distracted driving is common throughout Texas, as more and more people check their mobile devices on the go. Driver error (such as DUI) is also common, especially at night. Many accidents, however, could have been prevented with proper roadside signage and crosswalks.\r\n\r\nPoor city planning, such as a lack of proper sidewalks or failing to provide a crosswalk at an intersection, contributes to a percentage of pedestrian accidents in central Texas. In large cities such as Houston and Dallas, pedestrian accidents occur more frequently—often because a driver does not realize a pedestrian is crossing.\r\n\r\nFailure to maintain sidewalks and road signs can lead to pedestrians crossing the road when they should not, without realizing that oncoming traffic is not stopping. In these situations, the victim may sue the city or those responsible for maintaining the roadway. Whether driver negligence or a property defect caused your injury, you may be able to recover damages.\r\n<h2>Proving Negligence</h2>\r\nThe main step in a pedestrian accident case is proving which party’s negligence caused the accident. Texas has a comparative negligence system, in which the courts can split liability between two parties. For example, if a pedestrian was intoxicated and the driver was not paying attention, the courts may allocate a percentage of fault to both parties.\r\n\r\nTo win compensation, the plaintiff must prove the defendant failed to provide his or her legal duty to the plaintiff under the circumstances and that this breach caused an injury. Victims in pedestrian accidents need to hire a skilled personal injury lawyer to help them with these cases if and when they go to court.\r\n<h2>Texas Personal Injury Attorneys You Can Trust</h2>\r\nWhen Ted Smith Law Group, PLLC, takes on a client involved in a pedestrian accident, we anticipate moderate to severe injuries, permanent disability, and even wrongful death. Our law group is equipped to handle the most complex pedestrian accident cases and is proud to be the firm of choice for injured pedestrians throughout central Texas. If you need legal representation for your case, <a href="/contact/">contact us today</a> for a free consultation.', 'Pedestrian Accidents', '', 'inherit', 'closed', 'closed', '', '41-revision-v1', '', '', '2016-05-20 18:18:34', '2016-05-20 18:18:34', '', 41, 'http://tedsmithdemo.com/41-revision-v1/', 0, 'revision', '', 0),
(43, 1, '2016-05-20 18:19:59', '2016-05-20 18:19:59', 'Between working with heavy equipment, working on the sides of busy highways, and performing dangerous duties on the job, construction workers face many risks every day. Negligent drivers who speed through construction zones or fail to abide by roadside warning signs are likely to strike construction workers at high speeds, leaving the victim severely injured.\r\n\r\nThe leading causes of construction worker death are falls, electrocutions, getting struck by objects, and being caught in-between equipment. These hazardous situations are often the result of improper equipment maintenance, part malfunction, and other forms of negligence. If you or someone you know was injured in a construction accident, you have a legal right to take the negligent party to court for compensation.\r\n<h2>Why Are Construction Accidents Common?</h2>\r\nThere is a certain level of risk involved in many professions, but the construction industry is the most susceptible to injuries due to the dangerous nature of the job. Employees have to operate large mechanical equipment, work on the sides of busy highways, and often work from high above the ground. Slip and fall accidents are the leading type of construction accident, due to faulty equipment or a company’s failure to adhere to safety standards.\r\n\r\nOther hazards on the job include electrocution from defective equipment, exposure to harmful chemicals and asbestos, part failure, repetitive motion injuries, and reckless drivers. Despite construction workers’ best attempt to work safely, many construction site hazards are outside of the workers’ control.\r\n<h2>Who Is At Fault?</h2>\r\nDetermining responsibility in a construction accident can be difficult. The negligent party may be a supervisor who improperly trained an employee, an equipment manufacturer who made a part error, the construction site owner who failed to provide a safe work environment, the general contractor who failed to ensure work was performed safely, or a number of other parties. The courts may find more than one party at fault, in which case the victim can sue everyone partially responsible.\r\n\r\nIf an equipment manufacturer causes a construction accident, they have “no-fault” or “strict” liability for the damages a defective product caused. In situations involving construction projects, the law requires most parties to carry insurance coverage, such as premises liability, property liability, commercial general liability, and employer’s liability insurances.\r\n\r\nNegotiating with these insurance companies and navigating the laws surrounding construction accidents is difficult. A skilled attorney will be equipped to handle the multiple facets of these conversations. As an accident victim, you must prove negligence and place fault on the responsible party (the defendant). A qualified personal injury lawyer can help you successfully accomplish both tasks in court.\r\n<h2>OSHA Safety Regulations</h2>\r\nAn important factor when considering the aftermath of a construction accident is the <a href="https://www.nolo.com/legal-encyclopedia/content/osha-act.html" target="_blank">Occupational Safety and Health Act (OSHA)</a> of 1970. OSHA establishes health and safety standards for all workplaces across America. OSHA legally obligates employers to provide a reasonably safe workplace environment. Employers must take due care to inform employees of hazards, properly train employees, and take other measures to ensure safety.\r\n\r\nUnder OSHA, employees have the right to complain about unsafe work conditions or refuse to work when facing danger in the workplace. OSHA regulations are the standards by which the law holds property owners, contractors, and supervisors on the job. If someone violates these regulations, resulting in injury, the injured party can sue for negligence.<strong> </strong>\r\n<h2>Call (254) 690-5688 to Schedule a Free Consultation</h2>\r\nIf you have been involved in a construction accident due to someone else’s negligence, whether it was a part malfunction or supervisor’s lapse in judgment, the Ted Smith Law Group, PLLC, can help you recover damages. <a href="/contact/">Contact us today</a> to discuss your case for free with one of our expert local personal injury attorneys.', 'Construction Accidents', '', 'publish', 'closed', 'closed', '', 'construction-accidents', '', '', '2016-05-20 18:19:59', '2016-05-20 18:19:59', '', 31, 'http://tedsmithdemo.com/?page_id=43', 0, 'page', '', 0),
(44, 1, '2016-05-20 18:19:59', '2016-05-20 18:19:59', 'Between working with heavy equipment, working on the sides of busy highways, and performing dangerous duties on the job, construction workers face many risks every day. Negligent drivers who speed through construction zones or fail to abide by roadside warning signs are likely to strike construction workers at high speeds, leaving the victim severely injured.\r\n\r\nThe leading causes of construction worker death are falls, electrocutions, getting struck by objects, and being caught in-between equipment. These hazardous situations are often the result of improper equipment maintenance, part malfunction, and other forms of negligence. If you or someone you know was injured in a construction accident, you have a legal right to take the negligent party to court for compensation.\r\n<h2>Why Are Construction Accidents Common?</h2>\r\nThere is a certain level of risk involved in many professions, but the construction industry is the most susceptible to injuries due to the dangerous nature of the job. Employees have to operate large mechanical equipment, work on the sides of busy highways, and often work from high above the ground. Slip and fall accidents are the leading type of construction accident, due to faulty equipment or a company’s failure to adhere to safety standards.\r\n\r\nOther hazards on the job include electrocution from defective equipment, exposure to harmful chemicals and asbestos, part failure, repetitive motion injuries, and reckless drivers. Despite construction workers’ best attempt to work safely, many construction site hazards are outside of the workers’ control.\r\n<h2>Who Is At Fault?</h2>\r\nDetermining responsibility in a construction accident can be difficult. The negligent party may be a supervisor who improperly trained an employee, an equipment manufacturer who made a part error, the construction site owner who failed to provide a safe work environment, the general contractor who failed to ensure work was performed safely, or a number of other parties. The courts may find more than one party at fault, in which case the victim can sue everyone partially responsible.\r\n\r\nIf an equipment manufacturer causes a construction accident, they have “no-fault” or “strict” liability for the damages a defective product caused. In situations involving construction projects, the law requires most parties to carry insurance coverage, such as premises liability, property liability, commercial general liability, and employer’s liability insurances.\r\n\r\nNegotiating with these insurance companies and navigating the laws surrounding construction accidents is difficult. A skilled attorney will be equipped to handle the multiple facets of these conversations. As an accident victim, you must prove negligence and place fault on the responsible party (the defendant). A qualified personal injury lawyer can help you successfully accomplish both tasks in court.\r\n<h2>OSHA Safety Regulations</h2>\r\nAn important factor when considering the aftermath of a construction accident is the <a href="https://www.nolo.com/legal-encyclopedia/content/osha-act.html" target="_blank">Occupational Safety and Health Act (OSHA)</a> of 1970. OSHA establishes health and safety standards for all workplaces across America. OSHA legally obligates employers to provide a reasonably safe workplace environment. Employers must take due care to inform employees of hazards, properly train employees, and take other measures to ensure safety.\r\n\r\nUnder OSHA, employees have the right to complain about unsafe work conditions or refuse to work when facing danger in the workplace. OSHA regulations are the standards by which the law holds property owners, contractors, and supervisors on the job. If someone violates these regulations, resulting in injury, the injured party can sue for negligence.<strong> </strong>\r\n<h2>Call (254) 690-5688 to Schedule a Free Consultation</h2>\r\nIf you have been involved in a construction accident due to someone else’s negligence, whether it was a part malfunction or supervisor’s lapse in judgment, the Ted Smith Law Group, PLLC, can help you recover damages. <a href="/contact/">Contact us today</a> to discuss your case for free with one of our expert local personal injury attorneys.', 'Construction Accidents', '', 'inherit', 'closed', 'closed', '', '43-revision-v1', '', '', '2016-05-20 18:19:59', '2016-05-20 18:19:59', '', 43, 'http://tedsmithdemo.com/43-revision-v1/', 0, 'revision', '', 0),
(45, 1, '2016-05-20 18:20:49', '2016-05-20 18:20:49', 'As a victim of a slip and fall accident in Texas, your lawsuit must have specific elements to win compensation. The key in a slip and fall case is to prove someone else was 50% or more at-fault for the accident. Since the rise of more and more false slip and fall lawsuits, the courts are more stringent than ever about the proof that must be present to win a case.\r\n<h2>What Texas Law Says About Slip and Fall Cases</h2>\r\nSlip and fall cases involve premises liability laws, where an unsafe or defective property condition caused the victim’s injury. If you slipped and fell on someone else’s property, do not assume the property owner is automatically at fault. To win compensation for your injuries, you must prove the property owner failed in his or her duties to provide a reasonably safe environment for visitors.\r\n\r\nProving negligence in a slip and fall case is not always easy; it requires the aid of a knowledgeable premises liability attorney in Texas to succeed. Not only does the plaintiff have to prove the property was unsafe but also that it was unsafe due to some action or inaction of the property owner. Premises liability laws in Texas are detailed and that alone makes it difficult for an injured person to win compensation without the help of an expert attorney.\r\n\r\nAn example of premises negligence is when a property owner fails to repair a sidewalk he or she knows is dangerously uneven, causing someone to trip and break a bone. The plaintiff would need to gather evidence of the faulty sidewalk using key witnesses and evidence that the owner should have reasonably known about the defect.\r\n\r\nThen, the plaintiff must prove the owner could have repaired the defect before the accident occurred but was negligent in his or her duties as a property owner. Finally, the plaintiff has to prove this negligent directly caused the accident that resulted in injury. Throughout the trial process, the victim also needs to file the correct claims with the state courts and sit through the discovery, deposition, and mediation phases before going to trial.\r\n<h2>Determining Liability</h2>\r\nThe most difficult part of a slip and fall case is proving someone else was responsible for the incident. Not every unsafe premises condition is due to someone’s negligence. The property owner must be directly at fault for the dangerous environment for the courts to allocate any sort of award.\r\n\r\nSpills, worn spots, uneven sidewalks, dangerous objects, torn carpet, loose flooring, and poor lighting are all examples of property owner negligence that could potentially lead to a slip, trip, and fall accident. If the property owner did everything in his or her power to prevent injury, such as placing warning signs around the dangerous area while waiting for a repair person, the courts most likely will not hold the owner responsible for an accident.\r\n\r\nIf the property owner knew about the hazard and failed to act to prevent injury, it may be a case of premises liability. However, the plaintiff must also examine his or her own percentage of fault in the accident. In many slip and fall cases, the courts find the victim at least partially responsible for the accident.\r\n<h2>Contact Qualified Slip and Fall Lawyers for Peace of Mind</h2>\r\nIf a property owner’s negligence contributed or caused your slip and fall accident, <a href="/contact/">contact Ted Smith Law Group, PLLC</a>, to speak with an experienced Texas slip and fall lawyer. We know slip and fall accident cases can seem daunting to injured victims, but we’re here to make your journey easier. When you need peace of mind during a slip and fall settlement, trust us to handle your case.', 'Slip and Fall Accidents', '', 'publish', 'closed', 'closed', '', 'slip-fall-accidents', '', '', '2016-05-20 18:20:49', '2016-05-20 18:20:49', '', 31, 'http://tedsmithdemo.com/?page_id=45', 0, 'page', '', 0),
(46, 1, '2016-05-20 18:20:49', '2016-05-20 18:20:49', 'As a victim of a slip and fall accident in Texas, your lawsuit must have specific elements to win compensation. The key in a slip and fall case is to prove someone else was 50% or more at-fault for the accident. Since the rise of more and more false slip and fall lawsuits, the courts are more stringent than ever about the proof that must be present to win a case.\r\n<h2>What Texas Law Says About Slip and Fall Cases</h2>\r\nSlip and fall cases involve premises liability laws, where an unsafe or defective property condition caused the victim’s injury. If you slipped and fell on someone else’s property, do not assume the property owner is automatically at fault. To win compensation for your injuries, you must prove the property owner failed in his or her duties to provide a reasonably safe environment for visitors.\r\n\r\nProving negligence in a slip and fall case is not always easy; it requires the aid of a knowledgeable premises liability attorney in Texas to succeed. Not only does the plaintiff have to prove the property was unsafe but also that it was unsafe due to some action or inaction of the property owner. Premises liability laws in Texas are detailed and that alone makes it difficult for an injured person to win compensation without the help of an expert attorney.\r\n\r\nAn example of premises negligence is when a property owner fails to repair a sidewalk he or she knows is dangerously uneven, causing someone to trip and break a bone. The plaintiff would need to gather evidence of the faulty sidewalk using key witnesses and evidence that the owner should have reasonably known about the defect.\r\n\r\nThen, the plaintiff must prove the owner could have repaired the defect before the accident occurred but was negligent in his or her duties as a property owner. Finally, the plaintiff has to prove this negligent directly caused the accident that resulted in injury. Throughout the trial process, the victim also needs to file the correct claims with the state courts and sit through the discovery, deposition, and mediation phases before going to trial.\r\n<h2>Determining Liability</h2>\r\nThe most difficult part of a slip and fall case is proving someone else was responsible for the incident. Not every unsafe premises condition is due to someone’s negligence. The property owner must be directly at fault for the dangerous environment for the courts to allocate any sort of award.\r\n\r\nSpills, worn spots, uneven sidewalks, dangerous objects, torn carpet, loose flooring, and poor lighting are all examples of property owner negligence that could potentially lead to a slip, trip, and fall accident. If the property owner did everything in his or her power to prevent injury, such as placing warning signs around the dangerous area while waiting for a repair person, the courts most likely will not hold the owner responsible for an accident.\r\n\r\nIf the property owner knew about the hazard and failed to act to prevent injury, it may be a case of premises liability. However, the plaintiff must also examine his or her own percentage of fault in the accident. In many slip and fall cases, the courts find the victim at least partially responsible for the accident.\r\n<h2>Contact Qualified Slip and Fall Lawyers for Peace of Mind</h2>\r\nIf a property owner’s negligence contributed or caused your slip and fall accident, <a href="/contact/">contact Ted Smith Law Group, PLLC</a>, to speak with an experienced Texas slip and fall lawyer. We know slip and fall accident cases can seem daunting to injured victims, but we’re here to make your journey easier. When you need peace of mind during a slip and fall settlement, trust us to handle your case.', 'Slip and Fall Accidents', '', 'inherit', 'closed', 'closed', '', '45-revision-v1', '', '', '2016-05-20 18:20:49', '2016-05-20 18:20:49', '', 45, 'http://tedsmithdemo.com/45-revision-v1/', 0, 'revision', '', 0),
(47, 1, '2016-05-20 18:21:54', '2016-05-20 18:21:54', 'Wrongful death cases are devastating for everyone involved. Knowing your loved one might still be alive if it not for someone else’s negligence can leave long-lasting feelings of anger and injustice. At Ted Smith Law Group, PLLC, we are passionate about defending the rights of those who cannot defend themselves and seeking justice against negligent parties in wrongful death cases.\r\n<h2>Common Causes of Wrongful Death</h2>\r\nThe Texas Statutes define “wrongful death” as when one party causes the death of another through a wrongful act, carelessness, recklessness, neglect, lack of skill, or by default. Many different incidents can result in wrongful death, from surgical error to machinery malfunction. The most common types of wrongful death lawsuits involve car accidents, product defects, and medical malpractice.<strong> </strong>\r\n\r\nWrongful death can occur as a result of a dog bite, construction accident, premises liability, car accident, theme park accident, defective drugs, prescription error, unsafe products, work injury, and murder, among other acts. Any incident that occurs as the result of someone’s negligence or carelessness and results in the death of another person can qualify as wrongful death.\r\n\r\nMedical malpractice cases of wrongful death can include surgical error, delayed diagnosis, misdiagnosis, prescription error, neglect, and other related negligence. In these cases, the victim’s family may sue the hospital as well as the doctor if the doctor was a hospital employee instead of an independent contractor. The family may also sue a negligent nurse, a maintenance person, the drug company (for a dangerous drug), and anyone else who contributed to the incident.\r\n\r\nIf an unsafe property, such as a faulty elevator or deteriorating scaffolding, caused wrongful death, the victim’s family may have a case against the property owner. If wrongful death occurred on the job, the family can take the supervisor, product manufacturer, general contractor, employer, and many others to court depending on the circumstances of the accident.\r\n\r\nIn the event of a murder, the victim’s family may sue the property owner or landlord for failing to provide a reasonably safe property. If poor security, broken parking lot lights, or another preventable safety hazard is the fault of the negligent property owner and contributed to the unsafe conditions that led to a murder, the courts may find the owner/landlord responsible.\r\n<h2>Who Can File a Wrongful Death Claim in Texas?</h2>\r\nThe Texas courts impose limitations on who can legally file a wrongful death claim and when. In Texas, the statute of limitations for filing a wrongful death claim is two years after the deceased person’s death. The surviving spouse, children, or parents have three months after the date of death to file a claim before the executor of the deceased person’s estate may file a claim instead.\r\n\r\nIf a surviving family member requests the personal representative of the deceased person not file a claim, the representative cannot legally file a claim. An adopted child can file a claim for the death of an adoptive parent, but not for a biological parent. Texas law does not allow surviving siblings to claim wrongful death for a deceased brother or sister.\r\n<h2>How to Recover Damages in a Wrongful Death Case</h2>\r\nAt Ted Smith Law Group, PLLC, we understand winning compensation for your loved one’s death will not change what happened. However, knowing the person responsible for the death is facing justice can give you peace of mind. The financial compensation you and your family can obtain for lost earning capacity, lost care and counsel the deceased person would have provided, lost love and companionship, lost inheritance, mental anguish, and more can help you heal.\r\n\r\nIf you need more information about wrongful death in Texas or would like to discuss your specific case with one of our lawyers, <a href="/contact/">contact us online</a> or call (254) 690-5688 for a free consultation.', 'Wrongful Death', '', 'publish', 'closed', 'closed', '', 'wrongful-death', '', '', '2016-05-20 18:21:54', '2016-05-20 18:21:54', '', 31, 'http://tedsmithdemo.com/?page_id=47', 0, 'page', '', 0),
(48, 1, '2016-05-20 18:21:54', '2016-05-20 18:21:54', 'Wrongful death cases are devastating for everyone involved. Knowing your loved one might still be alive if it not for someone else’s negligence can leave long-lasting feelings of anger and injustice. At Ted Smith Law Group, PLLC, we are passionate about defending the rights of those who cannot defend themselves and seeking justice against negligent parties in wrongful death cases.\r\n<h2>Common Causes of Wrongful Death</h2>\r\nThe Texas Statutes define “wrongful death” as when one party causes the death of another through a wrongful act, carelessness, recklessness, neglect, lack of skill, or by default. Many different incidents can result in wrongful death, from surgical error to machinery malfunction. The most common types of wrongful death lawsuits involve car accidents, product defects, and medical malpractice.<strong> </strong>\r\n\r\nWrongful death can occur as a result of a dog bite, construction accident, premises liability, car accident, theme park accident, defective drugs, prescription error, unsafe products, work injury, and murder, among other acts. Any incident that occurs as the result of someone’s negligence or carelessness and results in the death of another person can qualify as wrongful death.\r\n\r\nMedical malpractice cases of wrongful death can include surgical error, delayed diagnosis, misdiagnosis, prescription error, neglect, and other related negligence. In these cases, the victim’s family may sue the hospital as well as the doctor if the doctor was a hospital employee instead of an independent contractor. The family may also sue a negligent nurse, a maintenance person, the drug company (for a dangerous drug), and anyone else who contributed to the incident.\r\n\r\nIf an unsafe property, such as a faulty elevator or deteriorating scaffolding, caused wrongful death, the victim’s family may have a case against the property owner. If wrongful death occurred on the job, the family can take the supervisor, product manufacturer, general contractor, employer, and many others to court depending on the circumstances of the accident.\r\n\r\nIn the event of a murder, the victim’s family may sue the property owner or landlord for failing to provide a reasonably safe property. If poor security, broken parking lot lights, or another preventable safety hazard is the fault of the negligent property owner and contributed to the unsafe conditions that led to a murder, the courts may find the owner/landlord responsible.\r\n<h2>Who Can File a Wrongful Death Claim in Texas?</h2>\r\nThe Texas courts impose limitations on who can legally file a wrongful death claim and when. In Texas, the statute of limitations for filing a wrongful death claim is two years after the deceased person’s death. The surviving spouse, children, or parents have three months after the date of death to file a claim before the executor of the deceased person’s estate may file a claim instead.\r\n\r\nIf a surviving family member requests the personal representative of the deceased person not file a claim, the representative cannot legally file a claim. An adopted child can file a claim for the death of an adoptive parent, but not for a biological parent. Texas law does not allow surviving siblings to claim wrongful death for a deceased brother or sister.\r\n<h2>How to Recover Damages in a Wrongful Death Case</h2>\r\nAt Ted Smith Law Group, PLLC, we understand winning compensation for your loved one’s death will not change what happened. However, knowing the person responsible for the death is facing justice can give you peace of mind. The financial compensation you and your family can obtain for lost earning capacity, lost care and counsel the deceased person would have provided, lost love and companionship, lost inheritance, mental anguish, and more can help you heal.\r\n\r\nIf you need more information about wrongful death in Texas or would like to discuss your specific case with one of our lawyers, <a href="/contact/">contact us online</a> or call (254) 690-5688 for a free consultation.', 'Wrongful Death', '', 'inherit', 'closed', 'closed', '', '47-revision-v1', '', '', '2016-05-20 18:21:54', '2016-05-20 18:21:54', '', 47, 'http://tedsmithdemo.com/47-revision-v1/', 0, 'revision', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(49, 1, '2016-05-20 18:22:31', '2016-05-20 18:22:31', 'Distracted driving tempts even the best drivers, especially when stuck in stop-and-go traffic or during a day when the phone will not stop buzzing. Drivers who multitask on the road are likely to miss important traffic signals, fail to notice a crossing pedestrian, drift into other lanes, rear-end vehicles or cause head-on collisions. Some of the worst accidents on Texas’s roadways are attributed to distracted driving.\r\n\r\nWhen someone is involved in a distracted driving accident, the innocent victims can file a claim against the distracted driver for negligence. Drivers who cause crashes by failing to abide by state and federal laws concerning mobile use while driving can be held accountable for their recklessness in court.\r\n<h2>Common Causes of Distracted Driving</h2>\r\nIn today’s digital era, a large number of distracted driving accidents can be attributed to drivers using personal mobile devices. Texting, talking, emailing, scrolling through social media, or using apps such as Snapchat have all caused auto accidents. Recently, car accident victims have filed claims against Snapchat for failing to take down or limit the use of a speed filter. The speed filter captures the speed at which users are traveling, creating an environment where drivers are encouraged to use Snapchat while driving at high speeds.\r\n\r\nIf you or someone you know was injured in a crash involving the Snapchat filter, you can join other victims who are filing claims against the company. Other causes of distracted driving include eating, personal grooming, using GPS, watching videos, adjusting the radio, and other actions that remove a driver’s eyes from the road. However, texting and driving is the most dangerous distraction since it takes visual, manual, and cognitive attention away from the driving task.\r\n\r\nAny activity that takes the driver’s attention off of the road, including mental concentration, qualifies as distracted driving. This includes emotional driving and road rage driving. Driving while angry, sad, or otherwise upset can lead to a driver who is mentally distracted and unable to pay full attention to his or her surroundings. If a pedestrian walks in front of a mentally distracted driver, the driver could easily fail to notice.\r\n<h2>What Are My Legal Options in a Distracted Driving Case?</h2>\r\nTexas cities have distracted driving laws that ban texting and driving as well as using mobile devices in school zones. If someone was illegally using a mobile device, resulting in an injurious crash, the victim has a strong case against that person in court. However, do not assume that just because your accident involved a distracted driver the courts will automatically hold the driver 100% responsible.\r\n\r\nTexas follows the comparative negligence system—meaning the courts can allocate a percentage of responsibility to both parties. If the courts allocate you more than 50% of fault for the accident, you will not receive anything in compensation. For example, if a driver was texting and driving but you jumped out in front of the vehicle, you may be held more responsible for the accident than the driver. Hence, it is important to hire a competent lawyer in a distracted driving case for your best chance of obtaining total or at least partial compensation for your injuries.\r\n<h2>How to File a Claim for Distracted Driving</h2>\r\nIn Texas, the victim of a distracted driving accident has two years from the date of the injury to file a claim against the driver. If you have been involved in a distracted driving accident, <a href="/contact/">contact Ted Smith Law Group, PLLC</a>, to discuss your options with a local personal injury lawyer. Our firm has a reputation throughout central Texas for competent, capable car accident lawyers who help our clients achieve justice for their injuries and property damage. Do not let a distracted driver decide your future.', 'Distracted Driving', '', 'publish', 'closed', 'closed', '', 'distracted-driving', '', '', '2016-05-20 18:22:31', '2016-05-20 18:22:31', '', 0, 'http://tedsmithdemo.com/?page_id=49', 0, 'page', '', 0),
(50, 1, '2016-05-20 18:22:31', '2016-05-20 18:22:31', 'Distracted driving tempts even the best drivers, especially when stuck in stop-and-go traffic or during a day when the phone will not stop buzzing. Drivers who multitask on the road are likely to miss important traffic signals, fail to notice a crossing pedestrian, drift into other lanes, rear-end vehicles or cause head-on collisions. Some of the worst accidents on Texas’s roadways are attributed to distracted driving.\r\n\r\nWhen someone is involved in a distracted driving accident, the innocent victims can file a claim against the distracted driver for negligence. Drivers who cause crashes by failing to abide by state and federal laws concerning mobile use while driving can be held accountable for their recklessness in court.\r\n<h2>Common Causes of Distracted Driving</h2>\r\nIn today’s digital era, a large number of distracted driving accidents can be attributed to drivers using personal mobile devices. Texting, talking, emailing, scrolling through social media, or using apps such as Snapchat have all caused auto accidents. Recently, car accident victims have filed claims against Snapchat for failing to take down or limit the use of a speed filter. The speed filter captures the speed at which users are traveling, creating an environment where drivers are encouraged to use Snapchat while driving at high speeds.\r\n\r\nIf you or someone you know was injured in a crash involving the Snapchat filter, you can join other victims who are filing claims against the company. Other causes of distracted driving include eating, personal grooming, using GPS, watching videos, adjusting the radio, and other actions that remove a driver’s eyes from the road. However, texting and driving is the most dangerous distraction since it takes visual, manual, and cognitive attention away from the driving task.\r\n\r\nAny activity that takes the driver’s attention off of the road, including mental concentration, qualifies as distracted driving. This includes emotional driving and road rage driving. Driving while angry, sad, or otherwise upset can lead to a driver who is mentally distracted and unable to pay full attention to his or her surroundings. If a pedestrian walks in front of a mentally distracted driver, the driver could easily fail to notice.\r\n<h2>What Are My Legal Options in a Distracted Driving Case?</h2>\r\nTexas cities have distracted driving laws that ban texting and driving as well as using mobile devices in school zones. If someone was illegally using a mobile device, resulting in an injurious crash, the victim has a strong case against that person in court. However, do not assume that just because your accident involved a distracted driver the courts will automatically hold the driver 100% responsible.\r\n\r\nTexas follows the comparative negligence system—meaning the courts can allocate a percentage of responsibility to both parties. If the courts allocate you more than 50% of fault for the accident, you will not receive anything in compensation. For example, if a driver was texting and driving but you jumped out in front of the vehicle, you may be held more responsible for the accident than the driver. Hence, it is important to hire a competent lawyer in a distracted driving case for your best chance of obtaining total or at least partial compensation for your injuries.\r\n<h2>How to File a Claim for Distracted Driving</h2>\r\nIn Texas, the victim of a distracted driving accident has two years from the date of the injury to file a claim against the driver. If you have been involved in a distracted driving accident, <a href="/contact/">contact Ted Smith Law Group, PLLC</a>, to discuss your options with a local personal injury lawyer. Our firm has a reputation throughout central Texas for competent, capable car accident lawyers who help our clients achieve justice for their injuries and property damage. Do not let a distracted driver decide your future.', 'Distracted Driving', '', 'inherit', 'closed', 'closed', '', '49-revision-v1', '', '', '2016-05-20 18:22:31', '2016-05-20 18:22:31', '', 49, 'http://tedsmithdemo.com/49-revision-v1/', 0, 'revision', '', 0),
(51, 1, '2016-05-20 18:23:03', '2016-05-20 18:23:03', 'Traumatic brain injury (TBI) is often the result of car, pedestrian, bicycle, and motorcycle accidents. Other things that commonly result in TBI include slip and fall accidents, roller coasters, collisions, sports-related injury, violence, or explosive blasts. If you have sustained a TBI or other brain injury because of someone else’s negligence, you can sue for financial compensation for medical bills, past and future pain and suffering, lost earning capacity, and more.\r\n<h2>Types of Brain Injuries</h2>\r\nWhile many TBIs are severe, there are minor forms of brain injury as well. An accident victim may not notice mild brain injuries right away, but they will surface over time. For example, children can be susceptible to mild brain injuries from roller coasters with severe motion. These motions can make the brain hit the sides of the skull, resulting in mild traumatic brain injury.\r\n\r\nAt first, a child may complain of a simple headache or slight nausea. Over time, however, parents may see behavioral changes in their child, such as mood swings or trouble concentrating. Often, the parents can trace these changes back to the roller coaster. Symptoms to look for in mild brain injuries include blurred vision, confusion, a few seconds’ lost consciousness, sensitivity to light and sound, and trouble sleeping.\r\n\r\nModerate to severe TBI can result in a few minutes to hours of lost consciousness, persistent nausea, strong headaches, seizures, body numbness, clear liquid leaking from nose and ears, profound confusion, comatose, and death. The long-lasting effects of TBI can range from paralysis to cognitive degeneration. Common long-term effects include permanently slurred speech, developmental issues, difficulty reading and writing, and social issues.\r\n<h2>Common Causes of Brain Injuries</h2>\r\nThe most common cause of traumatic brain injury is falling. Falling out of bed, down stairs, in the bathtub, off of ladders, and other situations can easily result in a brain injury if the skull strikes the ground or other objects on the way down. Fall-related TBI is especially common in older adults who have difficulty moving around as well as in young children.\r\n\r\nThe other common cause of TBI is vehicle collision. The human body cannot withstand the gravitational forces involved in a high-speed vehicle collision, often resulting in internal problems and TBI. Severe rotational forces can cause cellular structures within the brain to tear, while a severe blow can cause the brain to move within the skull. When the head collides with the interior of a vehicle or some other object, the brain can suffer severe blunt force trauma and other damages.\r\n\r\nViolence causes a relatively large number of TBIs, such as shaken baby syndrome, gunshot wounds, objects penetrating the skull, domestic violence, or child abuse. Other causes of TBIs can include sports-related impact injuries, in which high impact jars the brain inside of the skull and causes injury. Finally, explosive blasts in combat cause many TBIs within active duty members of the military. Extreme pressure waves passing through the brain may significantly disrupt brain function.\r\n<h2>Have You Suffered a Brain Injury?</h2>\r\nIf you or a loved one has suffered a temporary or permanent brain injury due to someone else’s negligent or reckless behavior, you may be able to seek financial compensation. The courts may find the defendant guilty in a TBI case if he or she drove recklessly, failed to provide safe premises, created a defective product, incorrectly trained employees, or any number of other circumstances that resulted in the accident.\r\n\r\nTo speak with a personal injury attorney with brain injury experience, <a href="/contact/">contact Ted Smith Law Group, PLLC</a> for a free consultation. We’re dedicated to serving TBI victims throughout central Texas, and we will help you file a claim and maneuver the lawsuit process step by step.', 'Brain Injuries', '', 'publish', 'closed', 'closed', '', 'brain-injuries', '', '', '2016-05-20 18:23:08', '2016-05-20 18:23:08', '', 31, 'http://tedsmithdemo.com/?page_id=51', 0, 'page', '', 0),
(52, 1, '2016-05-20 18:23:03', '2016-05-20 18:23:03', 'Traumatic brain injury (TBI) is often the result of car, pedestrian, bicycle, and motorcycle accidents. Other things that commonly result in TBI include slip and fall accidents, roller coasters, collisions, sports-related injury, violence, or explosive blasts. If you have sustained a TBI or other brain injury because of someone else’s negligence, you can sue for financial compensation for medical bills, past and future pain and suffering, lost earning capacity, and more.\r\n<h2>Types of Brain Injuries</h2>\r\nWhile many TBIs are severe, there are minor forms of brain injury as well. An accident victim may not notice mild brain injuries right away, but they will surface over time. For example, children can be susceptible to mild brain injuries from roller coasters with severe motion. These motions can make the brain hit the sides of the skull, resulting in mild traumatic brain injury.\r\n\r\nAt first, a child may complain of a simple headache or slight nausea. Over time, however, parents may see behavioral changes in their child, such as mood swings or trouble concentrating. Often, the parents can trace these changes back to the roller coaster. Symptoms to look for in mild brain injuries include blurred vision, confusion, a few seconds’ lost consciousness, sensitivity to light and sound, and trouble sleeping.\r\n\r\nModerate to severe TBI can result in a few minutes to hours of lost consciousness, persistent nausea, strong headaches, seizures, body numbness, clear liquid leaking from nose and ears, profound confusion, comatose, and death. The long-lasting effects of TBI can range from paralysis to cognitive degeneration. Common long-term effects include permanently slurred speech, developmental issues, difficulty reading and writing, and social issues.\r\n<h2>Common Causes of Brain Injuries</h2>\r\nThe most common cause of traumatic brain injury is falling. Falling out of bed, down stairs, in the bathtub, off of ladders, and other situations can easily result in a brain injury if the skull strikes the ground or other objects on the way down. Fall-related TBI is especially common in older adults who have difficulty moving around as well as in young children.\r\n\r\nThe other common cause of TBI is vehicle collision. The human body cannot withstand the gravitational forces involved in a high-speed vehicle collision, often resulting in internal problems and TBI. Severe rotational forces can cause cellular structures within the brain to tear, while a severe blow can cause the brain to move within the skull. When the head collides with the interior of a vehicle or some other object, the brain can suffer severe blunt force trauma and other damages.\r\n\r\nViolence causes a relatively large number of TBIs, such as shaken baby syndrome, gunshot wounds, objects penetrating the skull, domestic violence, or child abuse. Other causes of TBIs can include sports-related impact injuries, in which high impact jars the brain inside of the skull and causes injury. Finally, explosive blasts in combat cause many TBIs within active duty members of the military. Extreme pressure waves passing through the brain may significantly disrupt brain function.\r\n<h2>Have You Suffered a Brain Injury?</h2>\r\nIf you or a loved one has suffered a temporary or permanent brain injury due to someone else’s negligent or reckless behavior, you may be able to seek financial compensation. The courts may find the defendant guilty in a TBI case if he or she drove recklessly, failed to provide safe premises, created a defective product, incorrectly trained employees, or any number of other circumstances that resulted in the accident.\r\n\r\nTo speak with a personal injury attorney with brain injury experience, <a href="/contact/">contact Ted Smith Law Group, PLLC</a> for a free consultation. We’re dedicated to serving TBI victims throughout central Texas, and we will help you file a claim and maneuver the lawsuit process step by step.', 'Brain Injuries', '', 'inherit', 'closed', 'closed', '', '51-revision-v1', '', '', '2016-05-20 18:23:03', '2016-05-20 18:23:03', '', 51, 'http://tedsmithdemo.com/51-revision-v1/', 0, 'revision', '', 0),
(53, 1, '2016-05-20 18:23:59', '2016-05-20 18:23:59', 'Spine injuries are some of the most life-altering injuries a victim can sustain. Unfortunately, they are also some of the most common. Many car accidents result in spine injuries due to the extreme gravitational forces to which the spine is subjected. The spinal cord is complex and delicate and not built to withstand the severe forces of an auto accident.\r\n<h2>Types of Spine Injuries</h2>\r\nMotorcycle accidents, rear-end collisions, and falls are just a few of the most common accidents resulting in spine injuries. When someone falls wrong, suffers through a high-velocity accident, or withstands some other form of trauma, the spine can easily become injured. Slipped discs, damage to the thoracic spine, and multiple-level spinal cord injuries are common results of most accidents.\r\n\r\nThe spinal cord is a bundle of nerves housed within the spinal column. It is responsible for motor control and sensation as well as communication between the brain and the body. Thus, spine injuries generally have serious consequences, including paralysis and loss of body function. Often, these consequences remain with the victim for the duration of his or her life—resulting in lifelong medical costs and other damages.\r\n<h2>Estimating the Value of Your Spine Injury Claim</h2>\r\nEvaluating spinal cord injuries can be difficult since the courts must consider the long-term mental and emotional ramifications of permanent spinal injuries. With injuries that result in paralysis or permanent disability, the settlement value must include an estimate of that person’s future medical costs, lost earning capacity, and pain and suffering, among other factors.\r\n\r\nEconomic compensatory damages for spine injuries can include past and future medical expenses. Compensation can include the costs of spinal cord surgeries, X-rays, physical therapy, rehabilitation, medication, and special equipment, such as wheelchairs. Economic damage recovery also includes wages lost while in the hospital and lost earning capacity for victims who sustain a permanent injury that affects their ability to work.\r\n\r\nNon-economic compensatory damages are intangible—non-monetary losses associated with mental and emotional damage. It can be difficult to place a dollar value on non-economic compensatory damages, and the jury will rely on evidence such as the severity of the injury, what the victim had to go through, and what he or she lost in the accident.\r\n\r\nThe jury often assesses pain and suffering using a pain multiplier, which takes the victim’s economic damages and multiplies them by a set number. Depending on the severity of the injury, the courts can choose a number between one and ten to multiple the economic compensatory damages by. In the case of a serious injury, the courts will lean towards a higher number.\r\n\r\nWhen injuries are severe enough that a victim’s loved ones (spouses and children) suffer losses such as loss of a marital sexual relationship or parental relationship, the loved ones may recover damages known as <a href="http://www.nolo.com/dictionary/loss-of-consortium-term.html" target="_blank">loss of consortium</a>. This is often the case when a spine injury results in permanent paralysis.\r\n\r\nIf a victim fails to follow doctor’s directions for caring for a spine injury, resulting in a worsened condition, the court may allocate a portion of fault to the victim. The courts refer to this as “failure to mitigate damages.” This may result in the victim receiving considerably less in compensation—or none at all, if the courts place over 50% of fault with the victim.\r\n<h2>Get Help With Your Texas Spine Injury Claim</h2>\r\nIf you need help defending your rights against a negligent party, <a href="/contact/">contact us online</a> or call (254) 690-5688 to speak with an attorney about the accident that caused your spine injury. Whether you have suffered temporary or permanent pain and disability from a spine injury, we’re here to help you obtain financial compensation. Trust Ted Smith Law Group, PLLC, with your spine injury case today.', 'Spinal Cord Injuries', '', 'publish', 'closed', 'closed', '', 'spinal-cord-injuries', '', '', '2016-05-20 18:23:59', '2016-05-20 18:23:59', '', 31, 'http://tedsmithdemo.com/?page_id=53', 0, 'page', '', 0),
(54, 1, '2016-05-20 18:23:59', '2016-05-20 18:23:59', 'Spine injuries are some of the most life-altering injuries a victim can sustain. Unfortunately, they are also some of the most common. Many car accidents result in spine injuries due to the extreme gravitational forces to which the spine is subjected. The spinal cord is complex and delicate and not built to withstand the severe forces of an auto accident.\r\n<h2>Types of Spine Injuries</h2>\r\nMotorcycle accidents, rear-end collisions, and falls are just a few of the most common accidents resulting in spine injuries. When someone falls wrong, suffers through a high-velocity accident, or withstands some other form of trauma, the spine can easily become injured. Slipped discs, damage to the thoracic spine, and multiple-level spinal cord injuries are common results of most accidents.\r\n\r\nThe spinal cord is a bundle of nerves housed within the spinal column. It is responsible for motor control and sensation as well as communication between the brain and the body. Thus, spine injuries generally have serious consequences, including paralysis and loss of body function. Often, these consequences remain with the victim for the duration of his or her life—resulting in lifelong medical costs and other damages.\r\n<h2>Estimating the Value of Your Spine Injury Claim</h2>\r\nEvaluating spinal cord injuries can be difficult since the courts must consider the long-term mental and emotional ramifications of permanent spinal injuries. With injuries that result in paralysis or permanent disability, the settlement value must include an estimate of that person’s future medical costs, lost earning capacity, and pain and suffering, among other factors.\r\n\r\nEconomic compensatory damages for spine injuries can include past and future medical expenses. Compensation can include the costs of spinal cord surgeries, X-rays, physical therapy, rehabilitation, medication, and special equipment, such as wheelchairs. Economic damage recovery also includes wages lost while in the hospital and lost earning capacity for victims who sustain a permanent injury that affects their ability to work.\r\n\r\nNon-economic compensatory damages are intangible—non-monetary losses associated with mental and emotional damage. It can be difficult to place a dollar value on non-economic compensatory damages, and the jury will rely on evidence such as the severity of the injury, what the victim had to go through, and what he or she lost in the accident.\r\n\r\nThe jury often assesses pain and suffering using a pain multiplier, which takes the victim’s economic damages and multiplies them by a set number. Depending on the severity of the injury, the courts can choose a number between one and ten to multiple the economic compensatory damages by. In the case of a serious injury, the courts will lean towards a higher number.\r\n\r\nWhen injuries are severe enough that a victim’s loved ones (spouses and children) suffer losses such as loss of a marital sexual relationship or parental relationship, the loved ones may recover damages known as <a href="http://www.nolo.com/dictionary/loss-of-consortium-term.html" target="_blank">loss of consortium</a>. This is often the case when a spine injury results in permanent paralysis.\r\n\r\nIf a victim fails to follow doctor’s directions for caring for a spine injury, resulting in a worsened condition, the court may allocate a portion of fault to the victim. The courts refer to this as “failure to mitigate damages.” This may result in the victim receiving considerably less in compensation—or none at all, if the courts place over 50% of fault with the victim.\r\n<h2>Get Help With Your Texas Spine Injury Claim</h2>\r\nIf you need help defending your rights against a negligent party, <a href="/contact/">contact us online</a> or call (254) 690-5688 to speak with an attorney about the accident that caused your spine injury. Whether you have suffered temporary or permanent pain and disability from a spine injury, we’re here to help you obtain financial compensation. Trust Ted Smith Law Group, PLLC, with your spine injury case today.', 'Spinal Cord Injuries', '', 'inherit', 'closed', 'closed', '', '53-revision-v1', '', '', '2016-05-20 18:23:59', '2016-05-20 18:23:59', '', 53, 'http://tedsmithdemo.com/53-revision-v1/', 0, 'revision', '', 0),
(55, 1, '2016-05-20 18:24:38', '2016-05-20 18:24:38', 'Due to the severe nature of most burn injuries sustained in an accident, victims are often left with permanent physical and mental scarring. Burn injuries are extremely painful, even throughout the healing process. If you or a loved one has suffered from a burn injury in an accident due to another’s negligence, consider filing a claim to compensate for punitive and compensatory damages.\r\n<h2>What Causes Burn Injuries?</h2>\r\nA burn injury can occur anytime, but it is often the result of someone’s negligence. Victims can sustain a burn injury in a car accident, on unsafe premises, while using a defective product, or in their own homes. Regular, everyday products such as water heaters, electrical cords, or cleaning chemicals can produce first, second, and third degree burns. If a manufacturer error or negligence caused your burn injury, you may be unsure of what your next steps are in seeking fair compensation.\r\n\r\nCatastrophic burn injuries are some of the worst injuries a person can suffer. These burns may be the result of car accident fires, but they occur most often within the victim’s own home. You may assume being scalded from hot liquids or steam in the kitchen are always the victim’s fault, but if the equipment the victim was using at the time was defective and caused the injury, the manufacturer may be responsible for the victim’s injuries.\r\n\r\nContact with toxic chemicals, such as lye, acid, ammonia, and bleach, are other common causes of household burns. Many detergents and cleaners use chemicals that burn exposed skin, leading to soft tissue damage and beyond. While most cleaners have warnings explaining these risks, companies may be negligent in their product warnings or manufacturer a defective cleaning product.\r\n\r\nIf a manufacturer error, defective product, workplace hazard, unsafe premises, reckless driver, or other negligent party caused your burn injury, first seek medical attention. After receiving care, take steps toward filing a negligence claim. Find a local burn injury lawyer with experience handling burn accidents to help you navigate these complex personal injury cases.\r\n<h2>Types of Burn Injuries</h2>\r\nBurn injuries are classified according to levels: first-degree, second-degree, third-degree, and fourth-degree burns. First-degree burns are the least serious, resulting in red but non-blistered skin. They can be painful but do not leave lasting damages. Second-degree burns are more painful and result in visible blistering. Third-degree burns give the skin a white, leathery appearance and can leave permanent scarring.\r\n\r\nFourth-degree burns have the same symptoms of third-degree burns, but they also include damage beyond the skin. These severe burns extend to the tendons and bones and can lead to permanent damage and death. The degree of the burn depends on the cause of the burn, as well as how long the skin is exposed to the source of the heat.\r\n\r\nWhile most burns need medical attention, this is even more important for chemical and electrical burns. They need immediate medical attention due to the propensity for affecting the inside of the body, even if physical damage is minor.\r\n<h2>When to Seek a Lawyer for Burn Injuries</h2>\r\nIf you believe your burn injury would have been prevented with due care on the behalf of a product manufacturer, employer, driver, or other party, seek professional help. Many burn injuries around the home can actually be attributed to faulty equipment and electrical wiring, which deserve the court’s attention.\r\n\r\nTo seek legal representation for your burn injury, regardless of its severity, <a href="/contact/">contact Ted Smith Law Group, PLLC</a>, for a free consultation. We will discuss your burn injury with you and give you legal counsel for what to do moving forward with a lawsuit.', 'Burn Injuries', '', 'publish', 'closed', 'closed', '', 'burn-injuries', '', '', '2016-05-20 18:24:38', '2016-05-20 18:24:38', '', 31, 'http://tedsmithdemo.com/?page_id=55', 0, 'page', '', 0),
(56, 1, '2016-05-20 18:24:38', '2016-05-20 18:24:38', 'Due to the severe nature of most burn injuries sustained in an accident, victims are often left with permanent physical and mental scarring. Burn injuries are extremely painful, even throughout the healing process. If you or a loved one has suffered from a burn injury in an accident due to another’s negligence, consider filing a claim to compensate for punitive and compensatory damages.\r\n<h2>What Causes Burn Injuries?</h2>\r\nA burn injury can occur anytime, but it is often the result of someone’s negligence. Victims can sustain a burn injury in a car accident, on unsafe premises, while using a defective product, or in their own homes. Regular, everyday products such as water heaters, electrical cords, or cleaning chemicals can produce first, second, and third degree burns. If a manufacturer error or negligence caused your burn injury, you may be unsure of what your next steps are in seeking fair compensation.\r\n\r\nCatastrophic burn injuries are some of the worst injuries a person can suffer. These burns may be the result of car accident fires, but they occur most often within the victim’s own home. You may assume being scalded from hot liquids or steam in the kitchen are always the victim’s fault, but if the equipment the victim was using at the time was defective and caused the injury, the manufacturer may be responsible for the victim’s injuries.\r\n\r\nContact with toxic chemicals, such as lye, acid, ammonia, and bleach, are other common causes of household burns. Many detergents and cleaners use chemicals that burn exposed skin, leading to soft tissue damage and beyond. While most cleaners have warnings explaining these risks, companies may be negligent in their product warnings or manufacturer a defective cleaning product.\r\n\r\nIf a manufacturer error, defective product, workplace hazard, unsafe premises, reckless driver, or other negligent party caused your burn injury, first seek medical attention. After receiving care, take steps toward filing a negligence claim. Find a local burn injury lawyer with experience handling burn accidents to help you navigate these complex personal injury cases.\r\n<h2>Types of Burn Injuries</h2>\r\nBurn injuries are classified according to levels: first-degree, second-degree, third-degree, and fourth-degree burns. First-degree burns are the least serious, resulting in red but non-blistered skin. They can be painful but do not leave lasting damages. Second-degree burns are more painful and result in visible blistering. Third-degree burns give the skin a white, leathery appearance and can leave permanent scarring.\r\n\r\nFourth-degree burns have the same symptoms of third-degree burns, but they also include damage beyond the skin. These severe burns extend to the tendons and bones and can lead to permanent damage and death. The degree of the burn depends on the cause of the burn, as well as how long the skin is exposed to the source of the heat.\r\n\r\nWhile most burns need medical attention, this is even more important for chemical and electrical burns. They need immediate medical attention due to the propensity for affecting the inside of the body, even if physical damage is minor.\r\n<h2>When to Seek a Lawyer for Burn Injuries</h2>\r\nIf you believe your burn injury would have been prevented with due care on the behalf of a product manufacturer, employer, driver, or other party, seek professional help. Many burn injuries around the home can actually be attributed to faulty equipment and electrical wiring, which deserve the court’s attention.\r\n\r\nTo seek legal representation for your burn injury, regardless of its severity, <a href="/contact/">contact Ted Smith Law Group, PLLC</a>, for a free consultation. We will discuss your burn injury with you and give you legal counsel for what to do moving forward with a lawsuit.', 'Burn Injuries', '', 'inherit', 'closed', 'closed', '', '55-revision-v1', '', '', '2016-05-20 18:24:38', '2016-05-20 18:24:38', '', 55, 'http://tedsmithdemo.com/55-revision-v1/', 0, 'revision', '', 0),
(57, 1, '2016-05-20 18:25:16', '2016-05-20 18:25:16', 'Texas is the nation’s leader for <a href="http://www.dogsbite.org/dogsbite-newsroom-2013-report-texas-dog-bite-fatalities-8-year-review.php" target="_blank">fatal dog attacks</a>. Dog attacks resulted in 34 fatalities in Texas between 2005 and 2013, most of which affected children under 11 years old. Serious dog attacks can lead to permanent disfigurement, long-lasting emotional damage, and wrongful death. Victims of dog bites in Texas have a number of legal actions available to them against owners who are negligent in the care of their pets, violate animal control laws, or fail to stop or prevent a dog attack.\r\n<h2>Texas Dog Bite Laws</h2>\r\nUnlike many other states, Texas does not have a dog bite statute. It does, however, adhere to the One Bite Rule. Under this rule, if the dog has bitten or tried to bite someone, the owners can be held responsible for the dog’s actions: they had reason to know the dog had violent tendencies but did not take proper precaution to prevent an attack. Since Texas has no dog bite statute, the One Bite Rule always comes into play during dog bite cases.\r\n\r\nAn owner can escape liability if he or she proves that the bitten victim provoked the dog into attacking. For example, if the victim was trespassing with the knowledge that the property has a dog or if the victim was antagonizing the dog on purpose, the courts may find the victim fully or partially responsible.\r\n\r\nDespite its name, the One Bite Rule does not have to apply to a previous dog bite. Even if a dog has never bitten anyone, showing signs of aggressive behavior may be enough for the courts to allocate fault with the dog owner. If the owner knew about dangerous tendencies, he or she can be held liable for a victim’s injuries. It is not enough for a victim to prove the owner knew about the dog’s aggressiveness, however—the victim must also prove that the owner failed to take reasonable care to prevent or control a bite.\r\n<h2>Common Dog Bite Injuries</h2>\r\nDog bite injuries are often traumatic in nature, as many aggressive dogs attack their victims’ face, neck, and chest regions. Sadly, children account for the majority of dog bite fatalities in Texas and beyond. Children often do not know how to act appropriately around dogs, especially canines who are eating or have triggers. Because children are so small and vulnerable, these injuries are generally severe or fatal.\r\n\r\nDog bites can result in puncture wounds, lacerations, fractured bones, infections, and other traumatic injuries. Aside from physical wounds, dog bites can also cause post-traumatic stress disorder, fear of dogs, fear of the outdoors, and other emotional injuries.\r\n<h2>How to Prove Negligence in a Dog Bite Case</h2>\r\nSome dog bite incidents occur out of the blue with a family dog that has never exhibited signs of dangerous behavior in the past. However, owners who were aware of their dogs’ aggressive tendencies could have reasonably prevented most dog attacks. If an owner knows a dog has “triggers,” such as loud noises or strangers entering the home, he or she is legally obligated to take steps toward preventing an attack.\r\n\r\nWhen a dog bites someone, a dog bite lawyer must investigate the case in detail. This includes gathering background information on the dog and the owners. A skilled dog bite lawyer knows how to navigate state and federal dog bite laws, including the One Bite Law, to the victim’s best advantage.\r\n<h2>Let Us Represent Your Dog Bite Case</h2>\r\nIf you need legal representation in a dog bite case, seek help from our experienced dog bite attorneys. Our Texas lawyers have represented dog bite victims in court and know how to conduct a proper investigation into a dog bite case. <a href="/contact/">Contact us</a> for a free case evaluation.', 'Dog Bites', '', 'publish', 'closed', 'closed', '', 'dog-bites', '', '', '2016-05-20 18:25:16', '2016-05-20 18:25:16', '', 31, 'http://tedsmithdemo.com/?page_id=57', 0, 'page', '', 0),
(58, 1, '2016-05-20 18:25:16', '2016-05-20 18:25:16', 'Texas is the nation’s leader for <a href="http://www.dogsbite.org/dogsbite-newsroom-2013-report-texas-dog-bite-fatalities-8-year-review.php" target="_blank">fatal dog attacks</a>. Dog attacks resulted in 34 fatalities in Texas between 2005 and 2013, most of which affected children under 11 years old. Serious dog attacks can lead to permanent disfigurement, long-lasting emotional damage, and wrongful death. Victims of dog bites in Texas have a number of legal actions available to them against owners who are negligent in the care of their pets, violate animal control laws, or fail to stop or prevent a dog attack.\r\n<h2>Texas Dog Bite Laws</h2>\r\nUnlike many other states, Texas does not have a dog bite statute. It does, however, adhere to the One Bite Rule. Under this rule, if the dog has bitten or tried to bite someone, the owners can be held responsible for the dog’s actions: they had reason to know the dog had violent tendencies but did not take proper precaution to prevent an attack. Since Texas has no dog bite statute, the One Bite Rule always comes into play during dog bite cases.\r\n\r\nAn owner can escape liability if he or she proves that the bitten victim provoked the dog into attacking. For example, if the victim was trespassing with the knowledge that the property has a dog or if the victim was antagonizing the dog on purpose, the courts may find the victim fully or partially responsible.\r\n\r\nDespite its name, the One Bite Rule does not have to apply to a previous dog bite. Even if a dog has never bitten anyone, showing signs of aggressive behavior may be enough for the courts to allocate fault with the dog owner. If the owner knew about dangerous tendencies, he or she can be held liable for a victim’s injuries. It is not enough for a victim to prove the owner knew about the dog’s aggressiveness, however—the victim must also prove that the owner failed to take reasonable care to prevent or control a bite.\r\n<h2>Common Dog Bite Injuries</h2>\r\nDog bite injuries are often traumatic in nature, as many aggressive dogs attack their victims’ face, neck, and chest regions. Sadly, children account for the majority of dog bite fatalities in Texas and beyond. Children often do not know how to act appropriately around dogs, especially canines who are eating or have triggers. Because children are so small and vulnerable, these injuries are generally severe or fatal.\r\n\r\nDog bites can result in puncture wounds, lacerations, fractured bones, infections, and other traumatic injuries. Aside from physical wounds, dog bites can also cause post-traumatic stress disorder, fear of dogs, fear of the outdoors, and other emotional injuries.\r\n<h2>How to Prove Negligence in a Dog Bite Case</h2>\r\nSome dog bite incidents occur out of the blue with a family dog that has never exhibited signs of dangerous behavior in the past. However, owners who were aware of their dogs’ aggressive tendencies could have reasonably prevented most dog attacks. If an owner knows a dog has “triggers,” such as loud noises or strangers entering the home, he or she is legally obligated to take steps toward preventing an attack.\r\n\r\nWhen a dog bites someone, a dog bite lawyer must investigate the case in detail. This includes gathering background information on the dog and the owners. A skilled dog bite lawyer knows how to navigate state and federal dog bite laws, including the One Bite Law, to the victim’s best advantage.\r\n<h2>Let Us Represent Your Dog Bite Case</h2>\r\nIf you need legal representation in a dog bite case, seek help from our experienced dog bite attorneys. Our Texas lawyers have represented dog bite victims in court and know how to conduct a proper investigation into a dog bite case. <a href="/contact/">Contact us</a> for a free case evaluation.', 'Dog Bites', '', 'inherit', 'closed', 'closed', '', '57-revision-v1', '', '', '2016-05-20 18:25:16', '2016-05-20 18:25:16', '', 57, 'http://tedsmithdemo.com/57-revision-v1/', 0, 'revision', '', 0),
(59, 1, '2016-05-20 18:26:02', '2016-05-20 18:26:02', 'One of the worst things parents can experience is receiving a call that their children sustained an injury on the playground. While many playground injuries are minor and nobody’s fault, others result in serious injury and can be traced back to someone’s negligence. Whether negligent supervision, manufacturer defect, maintenance error, or equipment failure caused your child’s playground injury, you have the right to investigate and file a claim for your child’s injuries.\r\n<h2>Common Types of Playground Injuries</h2>\r\nIn Ted Smith’s nearly 40 years of litigation experience throughout central Texas, he and his team have represented numerous parents on behalf of children injured on the playground. These injuries range from cuts and bruises to serious falls, fractures, contusions, and even wrongful death. The top four pieces of playground equipment associated with child injury are climbers, swings, slides, and overhead ladders.\r\n\r\nHead and neck injuries can occur as the result of falling off climbers. Children should be supervised while on climbers at all times to prevent falls. Traumatic brain injury, spine injury, and other severe injuries can all occur as a result of falling from playground equipment.\r\n\r\nIf a supervisor is negligent in his or her duties to reasonably provide for the safety of children on the playground and an accident occurs, the courts may hold the supervisor or the school responsible for resulting injuries.\r\n\r\nOther common injuries include fractures, abrasions, sprains, concussions, and lacerations. Many playground injuries in Texas occur on home playgrounds. The number one cause of playground-related fatalities is strangulation from entanglement or entrapment. The other cause is falls to the surface. Many home playgrounds do not come equipped with the proper impact-absorbing ground equipment, leading to worse injuries and fatalities.\r\n<h2>Who Is Responsible?</h2>\r\nAccidental injuries are one thing, but injuries a manufacturer error or negligence caused are punishable by law. If a missing chain link on a swing, jagged piece of metal on a slide, or other manufacturer defect resulted in your child’s injury, you may be able to sue the manufacturer for damage recovery.\r\nThere are three types of defective product liability claims involved in playground accidents:\r\n<ul>\r\n 	<li><strong>Manufacturer error.</strong> This includes errors during the process of making the equipment, such as a swing set made with a broken chain.</li>\r\n 	<li><strong>Defective design.</strong> A design defect could include, for example, a playground with a hazardous design flaw—such as equipment with a tendency to flip—that makes it unreasonably dangerous.</li>\r\n 	<li><strong>Warning defects.</strong> If the manufacturer is aware of a potential hazard, such as falling off horizontal ladders, it must properly warn users of the danger.</li>\r\n</ul>\r\nFor the courts to hold the school or daycare facility responsible for a playground injury instead of the manufacturer, the plaintiff must present evidence that the facility failed to properly maintain playground equipment. This claim would fall under premises liability laws.\r\n\r\nSuing a public school can be difficult, as suing government entities is much more complicated than private schools. Suing an individual supervisor who negligently failed to provide reasonable care to prevent playground injury may be possible, which could extend to the facility that hired the negligent supervisor. Regardless, proving negligence is difficult—especially if multiple parties are at fault. For your best chance at obtaining compensation from a playground injury, hire a personal injury attorney who knows how to prove fault in a playground accident.\r\n<h2>Get Legal Help for Your Child’s Playground Injury</h2>\r\nAt Ted Smith Law Group, PLLC, we sincerely hope you never have to contact us for a playground injury. Unfortunately, however, they do happen. The damages your child can suffer may be long lasting, both physically and emotionally. If your child suffered a playground injury due to someone else’s negligence, <a href="/contact/">contact us</a> for knowledgeable personal injury lawyers who are compassionate about defending your child’s rights.', 'Playground Injuries', '', 'publish', 'closed', 'closed', '', 'playground-injuries', '', '', '2016-05-20 18:26:02', '2016-05-20 18:26:02', '', 31, 'http://tedsmithdemo.com/?page_id=59', 0, 'page', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(60, 1, '2016-05-20 18:26:02', '2016-05-20 18:26:02', 'One of the worst things parents can experience is receiving a call that their children sustained an injury on the playground. While many playground injuries are minor and nobody’s fault, others result in serious injury and can be traced back to someone’s negligence. Whether negligent supervision, manufacturer defect, maintenance error, or equipment failure caused your child’s playground injury, you have the right to investigate and file a claim for your child’s injuries.\r\n<h2>Common Types of Playground Injuries</h2>\r\nIn Ted Smith’s nearly 40 years of litigation experience throughout central Texas, he and his team have represented numerous parents on behalf of children injured on the playground. These injuries range from cuts and bruises to serious falls, fractures, contusions, and even wrongful death. The top four pieces of playground equipment associated with child injury are climbers, swings, slides, and overhead ladders.\r\n\r\nHead and neck injuries can occur as the result of falling off climbers. Children should be supervised while on climbers at all times to prevent falls. Traumatic brain injury, spine injury, and other severe injuries can all occur as a result of falling from playground equipment.\r\n\r\nIf a supervisor is negligent in his or her duties to reasonably provide for the safety of children on the playground and an accident occurs, the courts may hold the supervisor or the school responsible for resulting injuries.\r\n\r\nOther common injuries include fractures, abrasions, sprains, concussions, and lacerations. Many playground injuries in Texas occur on home playgrounds. The number one cause of playground-related fatalities is strangulation from entanglement or entrapment. The other cause is falls to the surface. Many home playgrounds do not come equipped with the proper impact-absorbing ground equipment, leading to worse injuries and fatalities.\r\n<h2>Who Is Responsible?</h2>\r\nAccidental injuries are one thing, but injuries a manufacturer error or negligence caused are punishable by law. If a missing chain link on a swing, jagged piece of metal on a slide, or other manufacturer defect resulted in your child’s injury, you may be able to sue the manufacturer for damage recovery.\r\nThere are three types of defective product liability claims involved in playground accidents:\r\n<ul>\r\n 	<li><strong>Manufacturer error.</strong> This includes errors during the process of making the equipment, such as a swing set made with a broken chain.</li>\r\n 	<li><strong>Defective design.</strong> A design defect could include, for example, a playground with a hazardous design flaw—such as equipment with a tendency to flip—that makes it unreasonably dangerous.</li>\r\n 	<li><strong>Warning defects.</strong> If the manufacturer is aware of a potential hazard, such as falling off horizontal ladders, it must properly warn users of the danger.</li>\r\n</ul>\r\nFor the courts to hold the school or daycare facility responsible for a playground injury instead of the manufacturer, the plaintiff must present evidence that the facility failed to properly maintain playground equipment. This claim would fall under premises liability laws.\r\n\r\nSuing a public school can be difficult, as suing government entities is much more complicated than private schools. Suing an individual supervisor who negligently failed to provide reasonable care to prevent playground injury may be possible, which could extend to the facility that hired the negligent supervisor. Regardless, proving negligence is difficult—especially if multiple parties are at fault. For your best chance at obtaining compensation from a playground injury, hire a personal injury attorney who knows how to prove fault in a playground accident.\r\n<h2>Get Legal Help for Your Child’s Playground Injury</h2>\r\nAt Ted Smith Law Group, PLLC, we sincerely hope you never have to contact us for a playground injury. Unfortunately, however, they do happen. The damages your child can suffer may be long lasting, both physically and emotionally. If your child suffered a playground injury due to someone else’s negligence, <a href="/contact/">contact us</a> for knowledgeable personal injury lawyers who are compassionate about defending your child’s rights.', 'Playground Injuries', '', 'inherit', 'closed', 'closed', '', '59-revision-v1', '', '', '2016-05-20 18:26:02', '2016-05-20 18:26:02', '', 59, 'http://tedsmithdemo.com/59-revision-v1/', 0, 'revision', '', 0),
(61, 1, '2016-05-20 18:26:38', '2016-05-20 18:26:38', 'Birth injuries can be devastating to the future health of the child as well as to parents who have to cope with the effects of the injury. When parents discover their baby’s injury may have resulted from a physician’s negligence, the response is understandably disbelief. Mothers trust physicians to do what’s best for the health of the baby during pregnancy and delivery. Unfortunately, physicians can make mistakes, and those mistakes can lead to birth injuries.\r\n<h2>Types of Birth Injuries</h2>\r\nWhen the brain is deprived of oxygen, it reacts by draining blood from the brain. Hypoxia, anoxia, birth asphyxia, and other birth injuries resulting from oxygen deprivation can lead to various types of brain damage. Birth injuries may not immediately be apparent to parents, but they can surface sometime later as the child develops.\r\n\r\nThe most common birth-related brain damage is cerebral palsy (CP). CP has a variety of causes, including lack of oxygen to the brain, maternal infections, infant stroke, and infant infection. Many cases of CP could have been prevented had the physician taken the proper preventative measures. The attending physician must monitor fetal distress in the womb during birth and look for signs of oxygen deprivation in the mother and baby.\r\n\r\nIn most cases, a physician should detect fetal distress, infection, or oxygen deprivation in time to take action. It is the physician’s responsibility to take due care to monitor and treat infections, as well as a prolapsed umbilical cord cutting off the baby’s oxygen supply. The physician also needs to plan and execute an emergency C-section and use birth-assisting tools correctly.\r\n\r\nIf the physician negligently fails in one or more of the above prevention techniques, the baby is likely to develop CP. CP affects the way a baby’s brain sends communication to the muscles—leading to CP often being misinterpreted as muscle-related instead of a brain-related birth injury. Other common birth injuries include:\r\n<ul>\r\n 	<li>Fetal distress (hypoxia) from lack of oxygen to the brain</li>\r\n 	<li>Brain hemorrhage</li>\r\n 	<li>Electrical disorders</li>\r\n 	<li>Erb’s palsy</li>\r\n 	<li>Brachial plexus</li>\r\n 	<li>Fractures and broken bones</li>\r\n</ul>\r\nErb’s palsy, brachial plexus, Klumpke’s palsy, and shoulder dystocia are forms of muscle-related birth injuries. These injuries are often the result of improper use of birth tools, such as forceps or a vacuum extractor. If a physician improperly handles the infant or is guilty of blatant medical malpractice, like bruising or breaking bones, muscle-related injuries can occur. Serious injuries, such as skull fractures, can lead to permanently damaging brain injuries.\r\n<h2>Birth Injury Vs. Birth Defect</h2>\r\nYou should not confuse birth injuries with birth defects, which inflict your baby based on his or her DNA. Birth defects can, however, result from external factors (like the medications a mother takes while pregnant). If a physician mistakenly prescribes a medication known to cause birth defects, the courts can hold the physician responsible for consequent damage. If, however, the drug’s affects were the result of a manufacturer defect, the drug company may be at fault.\r\n<h2>How to File a Birth Injury Claim</h2>\r\nDiscovering your child suffers from a birth injury, whether with temporary or permanent effects, can be devastating. It may be difficult to think about a lawsuit on top of the problems you are currently facing, but acting fast will benefit your child in the long run. In the state of Texas, parents have two years from the time of the injury or when the injury was discovered to file a claim against the negligent physician.\r\n\r\nFiling a birth injury claim is complicated, and it must be done correctly for the courts to take your case to trial. The defendant must be identified and notified, whether it is the individual physical, a product manufacturer, a birthing facility, or a combination of parties. For help starting your case, <a href="/contact/">contact Ted Smith Law Group, PLLC</a>, today.', 'Birth Injury', '', 'publish', 'closed', 'closed', '', 'birth-injury', '', '', '2016-05-20 18:26:38', '2016-05-20 18:26:38', '', 0, 'http://tedsmithdemo.com/?page_id=61', 0, 'page', '', 0),
(62, 1, '2016-05-20 18:26:38', '2016-05-20 18:26:38', 'Birth injuries can be devastating to the future health of the child as well as to parents who have to cope with the effects of the injury. When parents discover their baby’s injury may have resulted from a physician’s negligence, the response is understandably disbelief. Mothers trust physicians to do what’s best for the health of the baby during pregnancy and delivery. Unfortunately, physicians can make mistakes, and those mistakes can lead to birth injuries.\r\n<h2>Types of Birth Injuries</h2>\r\nWhen the brain is deprived of oxygen, it reacts by draining blood from the brain. Hypoxia, anoxia, birth asphyxia, and other birth injuries resulting from oxygen deprivation can lead to various types of brain damage. Birth injuries may not immediately be apparent to parents, but they can surface sometime later as the child develops.\r\n\r\nThe most common birth-related brain damage is cerebral palsy (CP). CP has a variety of causes, including lack of oxygen to the brain, maternal infections, infant stroke, and infant infection. Many cases of CP could have been prevented had the physician taken the proper preventative measures. The attending physician must monitor fetal distress in the womb during birth and look for signs of oxygen deprivation in the mother and baby.\r\n\r\nIn most cases, a physician should detect fetal distress, infection, or oxygen deprivation in time to take action. It is the physician’s responsibility to take due care to monitor and treat infections, as well as a prolapsed umbilical cord cutting off the baby’s oxygen supply. The physician also needs to plan and execute an emergency C-section and use birth-assisting tools correctly.\r\n\r\nIf the physician negligently fails in one or more of the above prevention techniques, the baby is likely to develop CP. CP affects the way a baby’s brain sends communication to the muscles—leading to CP often being misinterpreted as muscle-related instead of a brain-related birth injury. Other common birth injuries include:\r\n<ul>\r\n 	<li>Fetal distress (hypoxia) from lack of oxygen to the brain</li>\r\n 	<li>Brain hemorrhage</li>\r\n 	<li>Electrical disorders</li>\r\n 	<li>Erb’s palsy</li>\r\n 	<li>Brachial plexus</li>\r\n 	<li>Fractures and broken bones</li>\r\n</ul>\r\nErb’s palsy, brachial plexus, Klumpke’s palsy, and shoulder dystocia are forms of muscle-related birth injuries. These injuries are often the result of improper use of birth tools, such as forceps or a vacuum extractor. If a physician improperly handles the infant or is guilty of blatant medical malpractice, like bruising or breaking bones, muscle-related injuries can occur. Serious injuries, such as skull fractures, can lead to permanently damaging brain injuries.\r\n<h2>Birth Injury Vs. Birth Defect</h2>\r\nYou should not confuse birth injuries with birth defects, which inflict your baby based on his or her DNA. Birth defects can, however, result from external factors (like the medications a mother takes while pregnant). If a physician mistakenly prescribes a medication known to cause birth defects, the courts can hold the physician responsible for consequent damage. If, however, the drug’s affects were the result of a manufacturer defect, the drug company may be at fault.\r\n<h2>How to File a Birth Injury Claim</h2>\r\nDiscovering your child suffers from a birth injury, whether with temporary or permanent effects, can be devastating. It may be difficult to think about a lawsuit on top of the problems you are currently facing, but acting fast will benefit your child in the long run. In the state of Texas, parents have two years from the time of the injury or when the injury was discovered to file a claim against the negligent physician.\r\n\r\nFiling a birth injury claim is complicated, and it must be done correctly for the courts to take your case to trial. The defendant must be identified and notified, whether it is the individual physical, a product manufacturer, a birthing facility, or a combination of parties. For help starting your case, <a href="/contact/">contact Ted Smith Law Group, PLLC</a>, today.', 'Birth Injury', '', 'inherit', 'closed', 'closed', '', '61-revision-v1', '', '', '2016-05-20 18:26:38', '2016-05-20 18:26:38', '', 61, 'http://tedsmithdemo.com/61-revision-v1/', 0, 'revision', '', 0),
(63, 1, '2016-05-20 18:27:26', '2016-05-20 18:27:26', 'The United States’ Social Security Administration (SSA) has two federal programs to provide financial help to disabled citizens: Social Security Disability (SSD) Insurance and Supplemental Security Income (SSI). Claiming social security disability is a process about which many people are confused. Knowing what the law defines as disabled, as well as how the SSD process works, can give you a better understanding of what to expect during your own SSD case.\r\n<h2>What Is Social Security Disability?</h2>\r\nSocial security disability is the classification for those disabled enough to qualify for governmental benefits. Benefits include a monthly cash award to provide a steady income to those who cannot work. The SSA created SSD benefit and insurance programs to help those who suffer from a condition that makes working enough to maintain a living impossible.\r\n\r\nSocial Security Disability Insurance (SSDI) pays a disabled citizen and some family members monthly for the duration of the disability. SSDI does not limit the amount of income a disabled person can have from other benefit programs, but it does impose limits on the amount of income earned at a job.\r\n\r\nIf you qualify for SSD benefits and/or insurance, the amount you receive per month depends on your needs. You will receive SSD benefits until you can return to work or for the duration of your life if you are permanently disabled. When you apply for SSD, you will need a social security disability report with information about physicians and facilities that have treated your condition. You will also need a list of your medical tests, prescriptions, and other healthcare information.\r\n<h2>How Do I Qualify for SSD Benefits?</h2>\r\nTo qualify for social security disability benefits, the SSA has to consider you medically disabled. A disabled person must apply for SSD benefits through the SSA by filling out the appropriate forms. Then, the SSA will conduct a background check and investigation into the applicant’s medical history.\r\n\r\nFor SSD purposes, applicants require an impairment that prevents them from working. The applicant’s impairment must have prevented work for the past 12 months or be expected to do so in the next 12 months. Impairments can be physical, psychological, or psychiatric in nature. Applicants must also be making below the maximum income level per month—not including other forms of financial aid.\r\n\r\nGenerally, each state sets the maximum income amount from a job source at about $1,000 per month. If you make more than the Texas limit from a job source, the SSA will deny your application without even looking at your disability qualifications. This is known as a “technical denial.” However, you may appeal the SSA’s decision and reapply for SSD benefits in the future if your income situation changes.\r\n<h2>More About Social Security Disability Benefits</h2>\r\nThe SSA denies the majority of citizens who apply for SSD benefits and insurance. Many applicants do not suffer from medical conditions on the SSA’s list of qualifying conditions or make too much monthly income to qualify. If the SSA has denied your SSD application, do not worry. Many applicants have to appeal the SSA’s first application decision before successfully receiving benefits.\r\n\r\nFor more information regarding Texas’s SSD system, how to apply, how to appeal a denied claim, how to navigate an SSD hearing, and more, <a href="/contact/">contact Ted Smith Law Group, PLLC</a>. We have helped many disabled citizens appeal denied claims and can handle all communication between you and the SSA.\r\n\r\nIf you need help collecting the necessary documents and forms to apply for SSD benefits in Texas, we can help you with that as well. If you have any questions regarding SSD in our country, do not hesitate to call (254) 690-5688 for a free consultation with our attorneys.', 'Social Security Disability', '', 'publish', 'closed', 'closed', '', 'social-security-disability', '', '', '2016-05-20 18:27:26', '2016-05-20 18:27:26', '', 0, 'http://tedsmithdemo.com/?page_id=63', 0, 'page', '', 0),
(64, 1, '2016-05-20 18:27:26', '2016-05-20 18:27:26', 'The United States’ Social Security Administration (SSA) has two federal programs to provide financial help to disabled citizens: Social Security Disability (SSD) Insurance and Supplemental Security Income (SSI). Claiming social security disability is a process about which many people are confused. Knowing what the law defines as disabled, as well as how the SSD process works, can give you a better understanding of what to expect during your own SSD case.\r\n<h2>What Is Social Security Disability?</h2>\r\nSocial security disability is the classification for those disabled enough to qualify for governmental benefits. Benefits include a monthly cash award to provide a steady income to those who cannot work. The SSA created SSD benefit and insurance programs to help those who suffer from a condition that makes working enough to maintain a living impossible.\r\n\r\nSocial Security Disability Insurance (SSDI) pays a disabled citizen and some family members monthly for the duration of the disability. SSDI does not limit the amount of income a disabled person can have from other benefit programs, but it does impose limits on the amount of income earned at a job.\r\n\r\nIf you qualify for SSD benefits and/or insurance, the amount you receive per month depends on your needs. You will receive SSD benefits until you can return to work or for the duration of your life if you are permanently disabled. When you apply for SSD, you will need a social security disability report with information about physicians and facilities that have treated your condition. You will also need a list of your medical tests, prescriptions, and other healthcare information.\r\n<h2>How Do I Qualify for SSD Benefits?</h2>\r\nTo qualify for social security disability benefits, the SSA has to consider you medically disabled. A disabled person must apply for SSD benefits through the SSA by filling out the appropriate forms. Then, the SSA will conduct a background check and investigation into the applicant’s medical history.\r\n\r\nFor SSD purposes, applicants require an impairment that prevents them from working. The applicant’s impairment must have prevented work for the past 12 months or be expected to do so in the next 12 months. Impairments can be physical, psychological, or psychiatric in nature. Applicants must also be making below the maximum income level per month—not including other forms of financial aid.\r\n\r\nGenerally, each state sets the maximum income amount from a job source at about $1,000 per month. If you make more than the Texas limit from a job source, the SSA will deny your application without even looking at your disability qualifications. This is known as a “technical denial.” However, you may appeal the SSA’s decision and reapply for SSD benefits in the future if your income situation changes.\r\n<h2>More About Social Security Disability Benefits</h2>\r\nThe SSA denies the majority of citizens who apply for SSD benefits and insurance. Many applicants do not suffer from medical conditions on the SSA’s list of qualifying conditions or make too much monthly income to qualify. If the SSA has denied your SSD application, do not worry. Many applicants have to appeal the SSA’s first application decision before successfully receiving benefits.\r\n\r\nFor more information regarding Texas’s SSD system, how to apply, how to appeal a denied claim, how to navigate an SSD hearing, and more, <a href="/contact/">contact Ted Smith Law Group, PLLC</a>. We have helped many disabled citizens appeal denied claims and can handle all communication between you and the SSA.\r\n\r\nIf you need help collecting the necessary documents and forms to apply for SSD benefits in Texas, we can help you with that as well. If you have any questions regarding SSD in our country, do not hesitate to call (254) 690-5688 for a free consultation with our attorneys.', 'Social Security Disability', '', 'inherit', 'closed', 'closed', '', '63-revision-v1', '', '', '2016-05-20 18:27:26', '2016-05-20 18:27:26', '', 63, 'http://tedsmithdemo.com/63-revision-v1/', 0, 'revision', '', 0),
(65, 1, '2016-05-20 18:28:24', '2016-05-20 18:28:24', 'When a disabled citizen receives notice that the Social Security Administration (SSA) denied his or her Social Security Disability (SSD) claim, the future can seem hopeless. Many disabled citizens ride the line between what the SSA defines as disabled and what their medical conditions are. Others make too much monthly income to qualify, yet not enough to uphold a standard of living. If the SSA has denied your SSD claim, there is hope for a future appeal.\r\n<h2>Why Does the SSA Deny Claims?</h2>\r\nThere a few reasons the SSA will deny an applicant’s SSD claim. The first reason is if the applicant does not suffer from any of the medical conditions on the SSA’s official list of qualifying conditions. It includes disorders affecting the following areas:\r\n<ul>\r\n 	<li>Musculoskeletal system</li>\r\n 	<li>Cardiovascular system</li>\r\n 	<li>Immune system</li>\r\n 	<li>Digestive system</li>\r\n 	<li>Respiratory system</li>\r\n 	<li>Hematological issues</li>\r\n 	<li>Congenital issues</li>\r\n 	<li>Neurological issues</li>\r\n 	<li>Endocrine issues</li>\r\n 	<li>Mental issues</li>\r\n</ul>\r\nWhen you access the SSA’s database online, you can find the full list of qualifying disabilities and the provisions of each condition. The SSA will grant anyone with a disability on their list immediate SSD benefits for life or until the condition improves. If an applicant’s disability is not on the list, the SSA will often deny the first claim. However, it will rethink the denial if the applicant appeals the decision.\r\n\r\nThe SSA may also deny claims if the applicant makes more than the maximum amount of monthly income from job-related payment. This amount varies state by state, but it generally stays around $1,000 per month. This amount does not include any benefit payments—only income the applicant earns from a job. If an applicant makes more than the maximum amount, the SSA will deny the claim on a technicality.\r\n<h2>What Can I Do if the SSA Denies My SSD Claim?</h2>\r\nIf you have applied for SSD benefits and faced denial, you have options. You should always appeal the SSA’s decision on the understanding that it denies nearly every applicant’s first try. Appeal by sending the SSA what’s known as a “reconsideration” along with your medical history and/or income statements to prove you deserve benefits. Enlist the help of an SSD lawyer to collect the proper documentation and appeal your denial.\r\n\r\nIf the SSA denies your reconsideration appeal, you can take your appeal to a hearing with an administrative law judge (ALJ). The judge will investigate your case, including new evidence you and your lawyer provide. You will have the opportunity to provide an expert medical witness to vouch for your disability. If the ALJ denies your appeal at this state, you can take your case to the appeals council and the federal court.\r\n\r\nHiring an SSD lawyer will make the difficult appeal process much easier. You need to understand what the SSA and judges look for to have the best chance of receiving benefits and/or insurance. An SSD appeal can take months to complete, but it will be worth it if the SSA grants you benefits.\r\n<h2>What to Do if You Think You Are Eligible for Benefits</h2>\r\nIf you firmly believe you are eligible for benefits but are facing an SSD denial from the SSA, <a href="/contact/">contact Ted Smith Law Group, PLLC</a>, for experienced advice as to how to proceed with an appeal. Our lawyers understand federal and state laws surrounding SSD and can tell you what your best options are moving forward. We will be with you every step of the way through an appeal and will do everything in our power to prove your disability to the judges involved.\r\n\r\nOur <a href="/social-security-disability/">SSD lawyers</a> can help those whom the SSA denies for eligibility by filing the correct appeal documents and more. When seeking SSD benefits is overwhelming, trust us to lift the burden from your shoulders.', 'SSD Denied Claims', '', 'publish', 'closed', 'closed', '', 'ssd-denied-claims', '', '', '2016-05-20 18:28:24', '2016-05-20 18:28:24', '', 63, 'http://tedsmithdemo.com/?page_id=65', 0, 'page', '', 0),
(66, 1, '2016-05-20 18:28:24', '2016-05-20 18:28:24', 'When a disabled citizen receives notice that the Social Security Administration (SSA) denied his or her Social Security Disability (SSD) claim, the future can seem hopeless. Many disabled citizens ride the line between what the SSA defines as disabled and what their medical conditions are. Others make too much monthly income to qualify, yet not enough to uphold a standard of living. If the SSA has denied your SSD claim, there is hope for a future appeal.\r\n<h2>Why Does the SSA Deny Claims?</h2>\r\nThere a few reasons the SSA will deny an applicant’s SSD claim. The first reason is if the applicant does not suffer from any of the medical conditions on the SSA’s official list of qualifying conditions. It includes disorders affecting the following areas:\r\n<ul>\r\n 	<li>Musculoskeletal system</li>\r\n 	<li>Cardiovascular system</li>\r\n 	<li>Immune system</li>\r\n 	<li>Digestive system</li>\r\n 	<li>Respiratory system</li>\r\n 	<li>Hematological issues</li>\r\n 	<li>Congenital issues</li>\r\n 	<li>Neurological issues</li>\r\n 	<li>Endocrine issues</li>\r\n 	<li>Mental issues</li>\r\n</ul>\r\nWhen you access the SSA’s database online, you can find the full list of qualifying disabilities and the provisions of each condition. The SSA will grant anyone with a disability on their list immediate SSD benefits for life or until the condition improves. If an applicant’s disability is not on the list, the SSA will often deny the first claim. However, it will rethink the denial if the applicant appeals the decision.\r\n\r\nThe SSA may also deny claims if the applicant makes more than the maximum amount of monthly income from job-related payment. This amount varies state by state, but it generally stays around $1,000 per month. This amount does not include any benefit payments—only income the applicant earns from a job. If an applicant makes more than the maximum amount, the SSA will deny the claim on a technicality.\r\n<h2>What Can I Do if the SSA Denies My SSD Claim?</h2>\r\nIf you have applied for SSD benefits and faced denial, you have options. You should always appeal the SSA’s decision on the understanding that it denies nearly every applicant’s first try. Appeal by sending the SSA what’s known as a “reconsideration” along with your medical history and/or income statements to prove you deserve benefits. Enlist the help of an SSD lawyer to collect the proper documentation and appeal your denial.\r\n\r\nIf the SSA denies your reconsideration appeal, you can take your appeal to a hearing with an administrative law judge (ALJ). The judge will investigate your case, including new evidence you and your lawyer provide. You will have the opportunity to provide an expert medical witness to vouch for your disability. If the ALJ denies your appeal at this state, you can take your case to the appeals council and the federal court.\r\n\r\nHiring an SSD lawyer will make the difficult appeal process much easier. You need to understand what the SSA and judges look for to have the best chance of receiving benefits and/or insurance. An SSD appeal can take months to complete, but it will be worth it if the SSA grants you benefits.\r\n<h2>What to Do if You Think You Are Eligible for Benefits</h2>\r\nIf you firmly believe you are eligible for benefits but are facing an SSD denial from the SSA, <a href="/contact/">contact Ted Smith Law Group, PLLC</a>, for experienced advice as to how to proceed with an appeal. Our lawyers understand federal and state laws surrounding SSD and can tell you what your best options are moving forward. We will be with you every step of the way through an appeal and will do everything in our power to prove your disability to the judges involved.\r\n\r\nOur <a href="/social-security-disability/">SSD lawyers</a> can help those whom the SSA denies for eligibility by filing the correct appeal documents and more. When seeking SSD benefits is overwhelming, trust us to lift the burden from your shoulders.', 'SSD Denied Claims', '', 'inherit', 'closed', 'closed', '', '65-revision-v1', '', '', '2016-05-20 18:28:24', '2016-05-20 18:28:24', '', 65, 'http://tedsmithdemo.com/65-revision-v1/', 0, 'revision', '', 0),
(67, 1, '2016-05-20 18:29:13', '2016-05-20 18:29:13', 'Social security disability (SSD) hearings can be stressful. The financial security of your future is at stake, and you need to prepare to appeal the Social Security Administration’s (SSA) decision to deny your SSD claim. From the first hearing with the administrative law judge (ALJ) to a final hearing with the federal court, you have to supply appropriate documentation of your disability, including medical records and key witnesses, to earn SSD benefits.\r\n\r\nThe first step in the appeals process of an SSD claim is reconsideration—a document the applicant sends to the SSA with appropriate updated medical information and other evidence of disability. If the SSA denies the reconsideration, the appeal will move to the second step – the SSD hearing.\r\n<h2>Who Is the Administrative Law Judge?</h2>\r\nAt every SSD appeal hearing, the presiding judge is an administrative law judge (ALJ). The ALJ hears the claims or disputes involving administrative law. An SSD appeal hearing is less formal and simpler than other cases but still requires proper preparation on the plaintiff’s part.\r\n\r\nYour lawyer can provide in-depth information on what you can expect from the ALJ. An experienced local lawyer will most likely have an existing relationship with the presiding ALJ, which will help your case during the hearing stage of the appeals process. Remember: the ALJ has as much authority as a judge in a regular hearing, even though SSA hearings are less formal.\r\n<h2>How Do I Prepare for an SSD Hearing?</h2>\r\nThe first step in preparing for an SSD hearing is to know how far away your court date is. Your lawyer can warn you ahead of time so you can prepare. The time required to get an SSD hearing can be extensive depending on which hearing office your case goes to (and the population of people that office handles).\r\n\r\nGetting a disability lawyer in Texas is the best way to prepare for an SSD hearing. A lawyer with experience handling SSD cases can help you file the appropriate appeal documentation, hire a key medical witness to attest to your condition, and more. With an SSD lawyer by your side, you do not have to worry about doing or saying something wrong during a hearing.\r\n\r\nUnlike other attorneys who wait until the hearing date to meet with a new client, the <a href="/social-security-disability/">SSD attorneys</a> at Ted Smith Law Group, PLLC, will meet with you about your case in person long before the hearing to prepare you for what to expect in front of the ALJ. We will also keep you updated about your case the entire time.\r\n\r\nKnowing as much as you can about your case is another way to prepare for your SSD hearing. That includes reviewing your personal Social Security file to find out exactly why the SSA denied your original claim and the reconsideration. You also need to know the details about your disability, including your current prognosis, treatments, and full medical history. Since the SSA denies most claims on the grounds that the applicant can perform some form of work (even if he or she cannot return to a past job), you will also need to learn about your work history and have a solid argument with proof as to why you cannot work.\r\n<h2>Need Legal Help With Your SSD Hearing?</h2>\r\nRemember, the number one way to achieve a “yes” decision in an SSD hearing is to come prepared with an experienced lawyer. Trust Ted Smith Law Group, PLLC, to help you with your SSD hearing. Benefit from a group of lawyers who have the ability and resources to help you succeed. <a href="/contact/">Contact us today</a> to discuss your SSD case in full, on the phone or in person, at one of our Texas locations.', 'SSD Hearings', '', 'publish', 'closed', 'closed', '', 'ssd-hearings', '', '', '2016-05-20 18:29:13', '2016-05-20 18:29:13', '', 63, 'http://tedsmithdemo.com/?page_id=67', 0, 'page', '', 0),
(68, 1, '2016-05-20 18:29:13', '2016-05-20 18:29:13', 'Social security disability (SSD) hearings can be stressful. The financial security of your future is at stake, and you need to prepare to appeal the Social Security Administration’s (SSA) decision to deny your SSD claim. From the first hearing with the administrative law judge (ALJ) to a final hearing with the federal court, you have to supply appropriate documentation of your disability, including medical records and key witnesses, to earn SSD benefits.\r\n\r\nThe first step in the appeals process of an SSD claim is reconsideration—a document the applicant sends to the SSA with appropriate updated medical information and other evidence of disability. If the SSA denies the reconsideration, the appeal will move to the second step – the SSD hearing.\r\n<h2>Who Is the Administrative Law Judge?</h2>\r\nAt every SSD appeal hearing, the presiding judge is an administrative law judge (ALJ). The ALJ hears the claims or disputes involving administrative law. An SSD appeal hearing is less formal and simpler than other cases but still requires proper preparation on the plaintiff’s part.\r\n\r\nYour lawyer can provide in-depth information on what you can expect from the ALJ. An experienced local lawyer will most likely have an existing relationship with the presiding ALJ, which will help your case during the hearing stage of the appeals process. Remember: the ALJ has as much authority as a judge in a regular hearing, even though SSA hearings are less formal.\r\n<h2>How Do I Prepare for an SSD Hearing?</h2>\r\nThe first step in preparing for an SSD hearing is to know how far away your court date is. Your lawyer can warn you ahead of time so you can prepare. The time required to get an SSD hearing can be extensive depending on which hearing office your case goes to (and the population of people that office handles).\r\n\r\nGetting a disability lawyer in Texas is the best way to prepare for an SSD hearing. A lawyer with experience handling SSD cases can help you file the appropriate appeal documentation, hire a key medical witness to attest to your condition, and more. With an SSD lawyer by your side, you do not have to worry about doing or saying something wrong during a hearing.\r\n\r\nUnlike other attorneys who wait until the hearing date to meet with a new client, the <a href="/social-security-disability/">SSD attorneys</a> at Ted Smith Law Group, PLLC, will meet with you about your case in person long before the hearing to prepare you for what to expect in front of the ALJ. We will also keep you updated about your case the entire time.\r\n\r\nKnowing as much as you can about your case is another way to prepare for your SSD hearing. That includes reviewing your personal Social Security file to find out exactly why the SSA denied your original claim and the reconsideration. You also need to know the details about your disability, including your current prognosis, treatments, and full medical history. Since the SSA denies most claims on the grounds that the applicant can perform some form of work (even if he or she cannot return to a past job), you will also need to learn about your work history and have a solid argument with proof as to why you cannot work.\r\n<h2>Need Legal Help With Your SSD Hearing?</h2>\r\nRemember, the number one way to achieve a “yes” decision in an SSD hearing is to come prepared with an experienced lawyer. Trust Ted Smith Law Group, PLLC, to help you with your SSD hearing. Benefit from a group of lawyers who have the ability and resources to help you succeed. <a href="/contact/">Contact us today</a> to discuss your SSD case in full, on the phone or in person, at one of our Texas locations.', 'SSD Hearings', '', 'inherit', 'closed', 'closed', '', '67-revision-v1', '', '', '2016-05-20 18:29:13', '2016-05-20 18:29:13', '', 67, 'http://tedsmithdemo.com/67-revision-v1/', 0, 'revision', '', 0),
(69, 1, '2016-05-20 18:29:57', '2016-05-20 18:29:57', 'Filing for Social Security Disability (SSD) benefits can be a daunting process, especially if you are new to the Social Security Administration’s (SSA) procedures and expectations. Knowing when to file, how to file, and what kind of information the SSA needs can help your first SSD application receive a positive response instead of a denial.\r\n<h2>When Should I File for SSD Benefits?</h2>\r\nTiming can be everything in an SSD case. It can affect how long you must wait to receive SSD benefits or to receive an SSD hearing for an appeal. If you apply at the wrong time—for example, if you apply when a condition is still manageable enough for you to work—the SSA will deny your claim, and you will have to face the lengthy appeals process as your condition worsens.\r\n\r\nIf the condition has not lasted a full 12 months when you file the application, the SSA will need medical evidence supporting the fact that your disability will reasonably prevent you from working in the next 12 months. If you do not fulfill either of these expectations, you can expect the SSA to deny your claim.\r\n\r\nKnowing when to stop working can be difficult since it drastically affects your living situation until you secure SSD benefits. The ideal time to stop working is exactly when your doctor recommends. Your doctor can document that he or she advised you to stop working due to your deteriorating medical condition, and you will not face repercussions for quitting. On the other hand, you do not want to work past this point and risk furthering your injury.\r\n\r\nTo avoid the appeals process, you should understand which disabilities qualify you as disabled to the SSA. You can find the criteria for these disabilities on the SSA’s website. SSD benefits are needs-based, so you cannot have more than the maximum amount in assets. In Texas, this limit is currently set at $2,000. Once you understand what qualifies an individual to receive SSD benefits in Texas, you can begin the application process with confidence.\r\n<h2>How Do I Apply for SSD Benefits in Texas?</h2>\r\nGenerally, you can find an SSD application through someone at your local social security office by calling for an interview. You can also find the application online. Since SSD benefits are a federal program, filing for SSD benefits in Texas is nearly identical to every other state. You can make applying for SSD benefits and Social Security Disability Insurance (SSDI) easy by asking a lawyer to help you with the process in your area.\r\n\r\nWhen you apply, ensure you have every piece of documentation the SSA requires. This includes medical documentation of your disability, a full history of your condition, treatments your doctor prescribed, your diagnosis, and prognosis. It also includes your income documentation and current assets. If you do not feel comfortable applying online by yourself, call the Social Security office or a lawyer for help.\r\n<h2>What if the SSA Denies My First Claim?</h2>\r\nIf the SSA denies your initial SSD claim, it is mostly likely because your disability did not meet the proper criteria or you do not have enough evidence to support the claim that you cannot return to work (even if it is not your previous job). If you have been denied, do not worry—the majority of SSD applicants’ first claims get denied. Speak with an SSD attorney in your area to begin the appeal process.\r\n\r\nFor help filing your initial claim, gathering the proper medical documents, communicating with the SSA, or other things related to your SSD claim, contact Ted Smith Law Group, PLLC. We understand the importance of securing SSD benefits and will take your claim seriously. Call us at (254) 690-5688 or <a href="/contact/">contact us online</a> to speak with a representative today.', 'Filing for SSD Benefits', '', 'publish', 'closed', 'closed', '', 'filing-ssd-benefits', '', '', '2016-05-20 18:29:57', '2016-05-20 18:29:57', '', 63, 'http://tedsmithdemo.com/?page_id=69', 0, 'page', '', 0),
(70, 1, '2016-05-20 18:29:57', '2016-05-20 18:29:57', 'Filing for Social Security Disability (SSD) benefits can be a daunting process, especially if you are new to the Social Security Administration’s (SSA) procedures and expectations. Knowing when to file, how to file, and what kind of information the SSA needs can help your first SSD application receive a positive response instead of a denial.\r\n<h2>When Should I File for SSD Benefits?</h2>\r\nTiming can be everything in an SSD case. It can affect how long you must wait to receive SSD benefits or to receive an SSD hearing for an appeal. If you apply at the wrong time—for example, if you apply when a condition is still manageable enough for you to work—the SSA will deny your claim, and you will have to face the lengthy appeals process as your condition worsens.\r\n\r\nIf the condition has not lasted a full 12 months when you file the application, the SSA will need medical evidence supporting the fact that your disability will reasonably prevent you from working in the next 12 months. If you do not fulfill either of these expectations, you can expect the SSA to deny your claim.\r\n\r\nKnowing when to stop working can be difficult since it drastically affects your living situation until you secure SSD benefits. The ideal time to stop working is exactly when your doctor recommends. Your doctor can document that he or she advised you to stop working due to your deteriorating medical condition, and you will not face repercussions for quitting. On the other hand, you do not want to work past this point and risk furthering your injury.\r\n\r\nTo avoid the appeals process, you should understand which disabilities qualify you as disabled to the SSA. You can find the criteria for these disabilities on the SSA’s website. SSD benefits are needs-based, so you cannot have more than the maximum amount in assets. In Texas, this limit is currently set at $2,000. Once you understand what qualifies an individual to receive SSD benefits in Texas, you can begin the application process with confidence.\r\n<h2>How Do I Apply for SSD Benefits in Texas?</h2>\r\nGenerally, you can find an SSD application through someone at your local social security office by calling for an interview. You can also find the application online. Since SSD benefits are a federal program, filing for SSD benefits in Texas is nearly identical to every other state. You can make applying for SSD benefits and Social Security Disability Insurance (SSDI) easy by asking a lawyer to help you with the process in your area.\r\n\r\nWhen you apply, ensure you have every piece of documentation the SSA requires. This includes medical documentation of your disability, a full history of your condition, treatments your doctor prescribed, your diagnosis, and prognosis. It also includes your income documentation and current assets. If you do not feel comfortable applying online by yourself, call the Social Security office or a lawyer for help.\r\n<h2>What if the SSA Denies My First Claim?</h2>\r\nIf the SSA denies your initial SSD claim, it is mostly likely because your disability did not meet the proper criteria or you do not have enough evidence to support the claim that you cannot return to work (even if it is not your previous job). If you have been denied, do not worry—the majority of SSD applicants’ first claims get denied. Speak with an SSD attorney in your area to begin the appeal process.\r\n\r\nFor help filing your initial claim, gathering the proper medical documents, communicating with the SSA, or other things related to your SSD claim, contact Ted Smith Law Group, PLLC. We understand the importance of securing SSD benefits and will take your claim seriously. Call us at (254) 690-5688 or <a href="/contact/">contact us online</a> to speak with a representative today.', 'Filing for SSD Benefits', '', 'inherit', 'closed', 'closed', '', '69-revision-v1', '', '', '2016-05-20 18:29:57', '2016-05-20 18:29:57', '', 69, 'http://tedsmithdemo.com/69-revision-v1/', 0, 'revision', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(71, 1, '2016-05-20 18:30:49', '2016-05-20 18:30:49', 'The Social Security Administration (SSA) receives thousands of applications for Social Security Disability (SSD) benefits and insurance from around the country. Since SSD programs are federally managed, the SSA has to process applications from all 50 states. Due to the high volume of applicants, the SSA is stringent about who they select to receive benefits.\r\n\r\nLuckily, an initial denial does not mean you cannot receive SSD benefits or Social Security Disability Insurance (SSDI). In fact, most of the citizens the SSA approves for benefits get approved during the appeals process instead of their first application.\r\n<h2>The Appeal Process</h2>\r\nIf the SSA determines you do not qualify for SSD benefits, it can be easy to give up. However, if you are truly disabled and unable to work, you may not be able to afford to give up on SSD benefits. The appeals process can be an uphill battle, but it is worth the effort if you are certain you deserve benefits.\r\n\r\nThe best chance you have at maneuvering the complex appeals process is to hire an SSD denied claims lawyer. That way, you do not have to fear not having the correct documentation or otherwise hurting your chance of securing benefits. The appeals process can be extensive or simple depending on your specific case and how each step goes.\r\n<h2>Reconsideration</h2>\r\nThe first step of the process after you have hired a lawyer is to file an official request for appeal. This is called a reconsideration, which you send to the SSA within 60 days of first receiving a denial. In your reconsideration, you must provide updated documentation of your medical condition from a qualified physician. If the SSA continues to deny your reconsideration, your case will move to the hearing phase.\r\n<h2>Hearing</h2>\r\nThe hearing phase of an appeal involves a judge presiding in court to hear the details of your case and consider your claim according to the new documentation you provide. The judge is known as the administrative law judge. The hearing is not as official as other types of hearings, and your lawyer will be with you every step of the way. However, you should take measures on your own to prepare, such as understanding why the SSA denied your application and reconsideration.\r\n<h2>Appeals Council</h2>\r\nIf the judge denies your claim at the hearing, your appeal will move to stage three: the Social Security Appeals Council. The Council will decide whether or not to review your case by looking at your past requests. If the Council reviews your case and believes you qualify for SSD benefits, the appeals process will end there. If your request for a review or your claim after the review is denied, you can move to the final step: a lawsuit with the federal district court.\r\n<h2>Federal Court</h2>\r\nThe final effort you can make to receive benefits after the SSA denies your claim is to file a lawsuit with the federal district court, taking the case to trial. The judge in this trial will look at every piece of documentation in your case up to this point, including new developments with your medical condition and work history. The judge will then come to a final decision about your case.\r\n\r\nIf all four of the appeals processes fail to accept your SSD benefits or insurance claim, you can wait for a designated period of time and reapply to the SSA, beginning the process over again. For expert advice about filing for SSD benefits, <a href="/contact/">contact us</a> to speak with an SSD representative. Your attorney at Ted Smith Law Group, PLLC will communicate with medical personnel on your behalf, acquiring solid documentation of your disability to present to the judge throughout the SSD appeals process.', 'SSD Appeals', '', 'publish', 'closed', 'closed', '', 'ssd-appeals', '', '', '2016-05-20 18:30:49', '2016-05-20 18:30:49', '', 63, 'http://tedsmithdemo.com/?page_id=71', 0, 'page', '', 0),
(72, 1, '2016-05-20 18:30:49', '2016-05-20 18:30:49', 'The Social Security Administration (SSA) receives thousands of applications for Social Security Disability (SSD) benefits and insurance from around the country. Since SSD programs are federally managed, the SSA has to process applications from all 50 states. Due to the high volume of applicants, the SSA is stringent about who they select to receive benefits.\r\n\r\nLuckily, an initial denial does not mean you cannot receive SSD benefits or Social Security Disability Insurance (SSDI). In fact, most of the citizens the SSA approves for benefits get approved during the appeals process instead of their first application.\r\n<h2>The Appeal Process</h2>\r\nIf the SSA determines you do not qualify for SSD benefits, it can be easy to give up. However, if you are truly disabled and unable to work, you may not be able to afford to give up on SSD benefits. The appeals process can be an uphill battle, but it is worth the effort if you are certain you deserve benefits.\r\n\r\nThe best chance you have at maneuvering the complex appeals process is to hire an SSD denied claims lawyer. That way, you do not have to fear not having the correct documentation or otherwise hurting your chance of securing benefits. The appeals process can be extensive or simple depending on your specific case and how each step goes.\r\n<h2>Reconsideration</h2>\r\nThe first step of the process after you have hired a lawyer is to file an official request for appeal. This is called a reconsideration, which you send to the SSA within 60 days of first receiving a denial. In your reconsideration, you must provide updated documentation of your medical condition from a qualified physician. If the SSA continues to deny your reconsideration, your case will move to the hearing phase.\r\n<h2>Hearing</h2>\r\nThe hearing phase of an appeal involves a judge presiding in court to hear the details of your case and consider your claim according to the new documentation you provide. The judge is known as the administrative law judge. The hearing is not as official as other types of hearings, and your lawyer will be with you every step of the way. However, you should take measures on your own to prepare, such as understanding why the SSA denied your application and reconsideration.\r\n<h2>Appeals Council</h2>\r\nIf the judge denies your claim at the hearing, your appeal will move to stage three: the Social Security Appeals Council. The Council will decide whether or not to review your case by looking at your past requests. If the Council reviews your case and believes you qualify for SSD benefits, the appeals process will end there. If your request for a review or your claim after the review is denied, you can move to the final step: a lawsuit with the federal district court.\r\n<h2>Federal Court</h2>\r\nThe final effort you can make to receive benefits after the SSA denies your claim is to file a lawsuit with the federal district court, taking the case to trial. The judge in this trial will look at every piece of documentation in your case up to this point, including new developments with your medical condition and work history. The judge will then come to a final decision about your case.\r\n\r\nIf all four of the appeals processes fail to accept your SSD benefits or insurance claim, you can wait for a designated period of time and reapply to the SSA, beginning the process over again. For expert advice about filing for SSD benefits, <a href="/contact/">contact us</a> to speak with an SSD representative. Your attorney at Ted Smith Law Group, PLLC will communicate with medical personnel on your behalf, acquiring solid documentation of your disability to present to the judge throughout the SSD appeals process.', 'SSD Appeals', '', 'inherit', 'closed', 'closed', '', '71-revision-v1', '', '', '2016-05-20 18:30:49', '2016-05-20 18:30:49', '', 71, 'http://tedsmithdemo.com/71-revision-v1/', 0, 'revision', '', 0),
(73, 1, '2016-05-20 18:31:21', '2016-05-20 18:31:21', 'Understanding the requirements the Social Security Administration (SSA) imposes on who qualifies to receive Social Security Disability Insurance (SSDI) or Social Security Disability (SSD) benefits can help you save time and energy. If you fail to properly prepare for the SSD application process before applying, you can get stuck in a lengthy appeals process while your debilitating condition worsens—waiting months to secure the benefits you need.\r\n<h2>What Does the SSA Look for in an Applicant?</h2>\r\nWhen the SSA receives an application for SSD benefits or insurance, it reviews your medical treatment history, your diagnosis, prognosis, current income, job history, and the potential your condition has for allowing you to work. If your condition permits you to work at a job different from your previous one, you can anticipate that the SSA will deny your benefits claim.\r\n\r\nTo qualify as “disabled,” an applicant must have a condition that meets the criteria outlined in the SSA’s list of disabling impairments. This list includes a variety of disorders (i.e., cardiovascular system and congenital disorders) as well as conditions like malignant cancer and neurological issues. To see if your condition meets the SSA’s criteria, read the list on the SSA’s website. If your condition is not listed, the SSA will most likely deny your initial claim.\r\n\r\nThe SSA often hires the Disability Determination Services (DDS) to investigate an applicant whose medical sources are not enough to determine disability. The DDS will likely contact you to arrange its own medical examination with a medical and/or psychological healthcare professional. If the DDS does not find you meet the criteria for disability, the SSA will deny your request and hold on to its files in case you make an appeal.\r\n\r\nSSD benefits are needs-based, meaning an applicant cannot earn too much per month from a job source to qualify for benefits. While the SSA does not impose a cap on how much the applicant can receive from other benefit programs, it does place a maximum of $2,000 in assets. The maximum income earned from a job per month varies state by state. Ask your lawyer about the current cap in Texas to see if you qualify.\r\n<h2>What Documents Do I Need to Apply?</h2>\r\nApplying for SSD or benefits is more than simply entering your information into an application. You need to provide the necessary documentation about your case. The SSA requires that you supply current and previous medical records relative to your condition as well as records of any treatment methods. Your current medical records should be no older than 60 days to provide the SSA with an accurate portrayal of your condition. Your older records should date as far back as the very first record of the condition to establish a pre-existing complication.\r\n\r\nYou will also need to provide evidence of your vocational history, including past jobs you have held, your last job, duties performed, job titles, length of time worked, and more. You can trace most denied claims back to incomplete or inaccurate job history. You should not underestimate the importance of getting your work history correct the first time. Ask for a lawyer’s help if you are unsure of what the SSA is looking for.\r\n<h2>Hire an Experienced SSD Attorney Near You</h2>\r\nIf you do not know where to begin collecting the necessary documentation of your disability, work with an SSD lawyer to make the process easy. Your lawyer can handle all communications with your medical practitioner and gather all the paperwork the SSA requires for filing a claim.\r\n\r\nCall Ted Smith Law Group, PLLC, at (254) 690-5688 or fill out our <a href="/contact/">online form</a> to make an appointment with one of our SSD lawyers regarding your case. We will help you understand whether you meet the SSA’s requirements and walk you through the filing and appeals processes.', 'SSD Requirements', '', 'publish', 'closed', 'closed', '', 'ssd-requirements', '', '', '2016-05-20 18:31:21', '2016-05-20 18:31:21', '', 63, 'http://tedsmithdemo.com/?page_id=73', 0, 'page', '', 0),
(74, 1, '2016-05-20 18:31:21', '2016-05-20 18:31:21', 'Understanding the requirements the Social Security Administration (SSA) imposes on who qualifies to receive Social Security Disability Insurance (SSDI) or Social Security Disability (SSD) benefits can help you save time and energy. If you fail to properly prepare for the SSD application process before applying, you can get stuck in a lengthy appeals process while your debilitating condition worsens—waiting months to secure the benefits you need.\r\n<h2>What Does the SSA Look for in an Applicant?</h2>\r\nWhen the SSA receives an application for SSD benefits or insurance, it reviews your medical treatment history, your diagnosis, prognosis, current income, job history, and the potential your condition has for allowing you to work. If your condition permits you to work at a job different from your previous one, you can anticipate that the SSA will deny your benefits claim.\r\n\r\nTo qualify as “disabled,” an applicant must have a condition that meets the criteria outlined in the SSA’s list of disabling impairments. This list includes a variety of disorders (i.e., cardiovascular system and congenital disorders) as well as conditions like malignant cancer and neurological issues. To see if your condition meets the SSA’s criteria, read the list on the SSA’s website. If your condition is not listed, the SSA will most likely deny your initial claim.\r\n\r\nThe SSA often hires the Disability Determination Services (DDS) to investigate an applicant whose medical sources are not enough to determine disability. The DDS will likely contact you to arrange its own medical examination with a medical and/or psychological healthcare professional. If the DDS does not find you meet the criteria for disability, the SSA will deny your request and hold on to its files in case you make an appeal.\r\n\r\nSSD benefits are needs-based, meaning an applicant cannot earn too much per month from a job source to qualify for benefits. While the SSA does not impose a cap on how much the applicant can receive from other benefit programs, it does place a maximum of $2,000 in assets. The maximum income earned from a job per month varies state by state. Ask your lawyer about the current cap in Texas to see if you qualify.\r\n<h2>What Documents Do I Need to Apply?</h2>\r\nApplying for SSD or benefits is more than simply entering your information into an application. You need to provide the necessary documentation about your case. The SSA requires that you supply current and previous medical records relative to your condition as well as records of any treatment methods. Your current medical records should be no older than 60 days to provide the SSA with an accurate portrayal of your condition. Your older records should date as far back as the very first record of the condition to establish a pre-existing complication.\r\n\r\nYou will also need to provide evidence of your vocational history, including past jobs you have held, your last job, duties performed, job titles, length of time worked, and more. You can trace most denied claims back to incomplete or inaccurate job history. You should not underestimate the importance of getting your work history correct the first time. Ask for a lawyer’s help if you are unsure of what the SSA is looking for.\r\n<h2>Hire an Experienced SSD Attorney Near You</h2>\r\nIf you do not know where to begin collecting the necessary documentation of your disability, work with an SSD lawyer to make the process easy. Your lawyer can handle all communications with your medical practitioner and gather all the paperwork the SSA requires for filing a claim.\r\n\r\nCall Ted Smith Law Group, PLLC, at (254) 690-5688 or fill out our <a href="/contact/">online form</a> to make an appointment with one of our SSD lawyers regarding your case. We will help you understand whether you meet the SSA’s requirements and walk you through the filing and appeals processes.', 'SSD Requirements', '', 'inherit', 'closed', 'closed', '', '73-revision-v1', '', '', '2016-05-20 18:31:21', '2016-05-20 18:31:21', '', 73, 'http://tedsmithdemo.com/73-revision-v1/', 0, 'revision', '', 0),
(75, 1, '2016-05-20 18:43:01', '2016-05-20 18:43:01', 'It is never too early to speak with an attorney about estate planning. While many people do not want to think about what will happen to their estates and assets after they pass on, it is a necessary part of life. Without estate planning, the loved ones who survive you will be left to sort through a difficult legal situation surrounding your estate. Instead of forcing your loved ones to deal with a legal battle, plan for your estate’s future today.\r\n<h2>About Estate Planning</h2>\r\nWith the right estate planning lawyers, mapping out the future of your estate and assets does not have to be a hassle. For over 40 years, Ted Smith has assisted people throughout Texas communities with both simple and complex estate planning. Our team is compassionate about your life and legacy and understands the emotional connection many people have with their estates.\r\n\r\nWe can help you assign a beneficiary, choose an asset protect solution, create a living will, update your last will and testament, and more. Our <a href="/reviews/">reputation in Texas</a> is as a law firm that cares about our clients’ futures and families, even after death. Whether you need help with wills, trusts, powers of attorney, or other elements of estate planning, Ted Smith Law Group, PLLC, can serve your needs with competent, trustworthy care.\r\n\r\nWhen you embark on an estate planning session, you need the help of someone who has a firm understanding of Texas’s complex estate services and other related legalities. If your estate includes high-value assets, you may require targeted planning that assesses your specific needs. Our firm is happy to sit with clients individually to create a targeted plan. When you have goals you want to achieve with your estate plan, we will help you make them a reality.\r\n<h2>What Your Estate Plan Needs to Cover</h2>\r\nJust as every life is different, every estate plan looks different. However, there are a few general items yours should cover. You must name who your belongings will go to after your death, but strong estate planning extends well beyond just this. Include instructions for passing your values to the future generation, such as your religion. You should also name a guardian if you have minor children and a predecessor to take over family businesses.\r\n\r\nPlan for the possibility of becoming disabled before you die. Your estate plan should include instructions for your healthcare if you cannot make decisions, including resuscitation, donating organs, and end of life decisions. If you fail to provide directions for your care while you are incapacitated, you could be subject to uncomfortable healthcare measures that are out of your control.\r\n\r\nEstate planning should not be something you do once in your life. As your life changes, you need to consistently update your estate plan to include new additions to the family, new assets you acquire, and other significant changes. Your family lawyer can help you update and make changes to your estate plan as often as you need. The most important thing to remember is that you should feel confident about your estate plan and trust your lawyer.\r\n<h2>Texas Estate Planning Lawyers With a Reputation</h2>\r\nThe citizens of Texas have known and worked with Ted Smith for over four decades for a variety of estate planning needs. We have the ability, resources, and credibility to support our firm as one of the top estate planning teams in Texas. To get started on your estate planning, <a href="/contact/">contact Ted Smith Law Group, PLLC</a>, for a free consultation today. We will meet with you in person to discuss your plans further. Remember, estate planning is not only for the retired—get started early, and secure peace of mind.', 'Estate Planning', '', 'publish', 'closed', 'closed', '', 'estate-planning', '', '', '2016-05-20 18:43:01', '2016-05-20 18:43:01', '', 0, 'http://tedsmithdemo.com/?page_id=75', 0, 'page', '', 0),
(76, 1, '2016-05-20 18:43:01', '2016-05-20 18:43:01', 'It is never too early to speak with an attorney about estate planning. While many people do not want to think about what will happen to their estates and assets after they pass on, it is a necessary part of life. Without estate planning, the loved ones who survive you will be left to sort through a difficult legal situation surrounding your estate. Instead of forcing your loved ones to deal with a legal battle, plan for your estate’s future today.\r\n<h2>About Estate Planning</h2>\r\nWith the right estate planning lawyers, mapping out the future of your estate and assets does not have to be a hassle. For over 40 years, Ted Smith has assisted people throughout Texas communities with both simple and complex estate planning. Our team is compassionate about your life and legacy and understands the emotional connection many people have with their estates.\r\n\r\nWe can help you assign a beneficiary, choose an asset protect solution, create a living will, update your last will and testament, and more. Our <a href="/reviews/">reputation in Texas</a> is as a law firm that cares about our clients’ futures and families, even after death. Whether you need help with wills, trusts, powers of attorney, or other elements of estate planning, Ted Smith Law Group, PLLC, can serve your needs with competent, trustworthy care.\r\n\r\nWhen you embark on an estate planning session, you need the help of someone who has a firm understanding of Texas’s complex estate services and other related legalities. If your estate includes high-value assets, you may require targeted planning that assesses your specific needs. Our firm is happy to sit with clients individually to create a targeted plan. When you have goals you want to achieve with your estate plan, we will help you make them a reality.\r\n<h2>What Your Estate Plan Needs to Cover</h2>\r\nJust as every life is different, every estate plan looks different. However, there are a few general items yours should cover. You must name who your belongings will go to after your death, but strong estate planning extends well beyond just this. Include instructions for passing your values to the future generation, such as your religion. You should also name a guardian if you have minor children and a predecessor to take over family businesses.\r\n\r\nPlan for the possibility of becoming disabled before you die. Your estate plan should include instructions for your healthcare if you cannot make decisions, including resuscitation, donating organs, and end of life decisions. If you fail to provide directions for your care while you are incapacitated, you could be subject to uncomfortable healthcare measures that are out of your control.\r\n\r\nEstate planning should not be something you do once in your life. As your life changes, you need to consistently update your estate plan to include new additions to the family, new assets you acquire, and other significant changes. Your family lawyer can help you update and make changes to your estate plan as often as you need. The most important thing to remember is that you should feel confident about your estate plan and trust your lawyer.\r\n<h2>Texas Estate Planning Lawyers With a Reputation</h2>\r\nThe citizens of Texas have known and worked with Ted Smith for over four decades for a variety of estate planning needs. We have the ability, resources, and credibility to support our firm as one of the top estate planning teams in Texas. To get started on your estate planning, <a href="/contact/">contact Ted Smith Law Group, PLLC</a>, for a free consultation today. We will meet with you in person to discuss your plans further. Remember, estate planning is not only for the retired—get started early, and secure peace of mind.', 'Estate Planning', '', 'inherit', 'closed', 'closed', '', '75-revision-v1', '', '', '2016-05-20 18:43:01', '2016-05-20 18:43:01', '', 75, 'http://tedsmithdemo.com/75-revision-v1/', 0, 'revision', '', 0),
(77, 1, '2016-05-20 18:48:02', '2016-05-20 18:48:02', 'Probate administration is the legal process needed to prove the will of a deceased person is valid or to assign assets if no will is provided. After a loved one passes on, the probate process begins. If the loved one provided a will, the heirs established in the will can take over their legal titles once probate administration ends. If there is no will, state laws will determine who inherits.\r\n\r\nDuring probate administration, it is best to have your family lawyer navigate the process and ensure your loved one’s final wishes are honored. Those who survive a loved one must pay off the loved one’s debts and ensure the assets are distributed according to the last will and testament. To make the probate administration process as fast and efficient as possible, trust a probate lawyer to handle your case.\r\n<h2>What Does Probate Administration Involve?</h2>\r\nDuring a probate administration, a legal representative known as the “administrator” (usually the closest relative) must probate the will. This means that the courts give the will legal effect, with validity confirmed under state law. Will probation gives the administrator power to perform his or her duties according to the directions stated in the will.\r\n\r\nThe assets that are subject to probate administration are those the person owns at the time of his or her death (known as the probate’s estate). These may include the contents of bank accounts, property, high-value assets such as vehicles, and investments. Assets that comprise a probate estate are those held in the deceased person’s name alone, those the deceased person owned as a tenant in common with another person, and those owed to the deceased person before death.\r\n\r\nOther assets involved in probate administration are household items such as clothing and jewelry. If the deceased person stated to whom he or she would give each belonging, the administrator would follow orders according to the last will. If they do not specify who receives household items, the administrator assigns these items.\r\n<h2>The Probate Process</h2>\r\nThe process of probate administration includes transferring assets to beneficiaries of the deceased person but also ensuring all debts the deceased person still owes get paid. The court that oversees the probate process is the probate court, a state court that follows rules specific to Texas. The probate process differs state to state, but not by much.\r\n\r\nIn general, the probate process will include the swearing in of the deceased person’s administrator. If the deceased person for some reason did not name an administrator or the administrator cannot perform his or her duties, the court will determine the personal representative instead. Probate administration serves to notify heirs, creditors, and the public that the deceased person has passed away. It also inventories the property of the loved one, taking note of existing debts that must be paid after death.\r\n\r\nThe administrator will then divvy up the deceased person’s assets according to the contents of the will. If the deceased person did not supply a will, the courts will place the decision in the administrator’s hands. The deceased person’s debts and taxes owed to the government must be settled completely using the assets or another form of payment. The remaining assets will go to the person specified in the will or be divided by the administrator.\r\n<h2>Seek Legal Help With Your Probate Administration</h2>\r\nHopefully your loved one provided a clear, efficient estate plan. However, if you need legal help for a no-will situation or another issue, contact Ted Smith Law Group, PLLC, for expert legal advice. For a probate administration attorney you can trust with your loved one’s assets and final wishes, call (254) 690-5688 or <a href="/contact/">contact us online</a> for a free consultation.', 'Probate Administration', '', 'publish', 'closed', 'closed', '', 'probate-administration', '', '', '2016-05-20 18:49:09', '2016-05-20 18:49:09', '', 75, 'http://tedsmithdemo.com/?page_id=77', 0, 'page', '', 0),
(78, 1, '2016-05-20 18:48:02', '2016-05-20 18:48:02', 'Probate administration is the legal process needed to prove the will of a deceased person is valid or to assign assets if no will is provided. After a loved one passes on, the probate process begins. If the loved one provided a will, the heirs established in the will can take over their legal titles once probate administration ends. If there is no will, state laws will determine who inherits.\r\n\r\nDuring probate administration, it is best to have your family lawyer navigate the process and ensure your loved one’s final wishes are honored. Those who survive a loved one must pay off the loved one’s debts and ensure the assets are distributed according to the last will and testament. To make the probate administration process as fast and efficient as possible, trust a probate lawyer to handle your case.\r\n<h2>What Does Probate Administration Involve?</h2>\r\nDuring a probate administration, a legal representative known as the “administrator” (usually the closest relative) must probate the will. This means that the courts give the will legal effect, with validity confirmed under state law. Will probation gives the administrator power to perform his or her duties according to the directions stated in the will.\r\n\r\nThe assets that are subject to probate administration are those the person owns at the time of his or her death (known as the probate’s estate). These may include the contents of bank accounts, property, high-value assets such as vehicles, and investments. Assets that comprise a probate estate are those held in the deceased person’s name alone, those the deceased person owned as a tenant in common with another person, and those owed to the deceased person before death.\r\n\r\nOther assets involved in probate administration are household items such as clothing and jewelry. If the deceased person stated to whom he or she would give each belonging, the administrator would follow orders according to the last will. If they do not specify who receives household items, the administrator assigns these items.\r\n<h2>The Probate Process</h2>\r\nThe process of probate administration includes transferring assets to beneficiaries of the deceased person but also ensuring all debts the deceased person still owes get paid. The court that oversees the probate process is the probate court, a state court that follows rules specific to Texas. The probate process differs state to state, but not by much.\r\n\r\nIn general, the probate process will include the swearing in of the deceased person’s administrator. If the deceased person for some reason did not name an administrator or the administrator cannot perform his or her duties, the court will determine the personal representative instead. Probate administration serves to notify heirs, creditors, and the public that the deceased person has passed away. It also inventories the property of the loved one, taking note of existing debts that must be paid after death.\r\n\r\nThe administrator will then divvy up the deceased person’s assets according to the contents of the will. If the deceased person did not supply a will, the courts will place the decision in the administrator’s hands. The deceased person’s debts and taxes owed to the government must be settled completely using the assets or another form of payment. The remaining assets will go to the person specified in the will or be divided by the administrator.\r\n<h2>Seek Legal Help With Your Probate Administration</h2>\r\nHopefully your loved one provided a clear, efficient estate plan. However, if you need legal help for a no-will situation or another issue, contact Ted Smith Law Group, PLLC, for expert legal advice. For a probate administration attorney you can trust with your loved one’s assets and final wishes, call (254) 690-5688 or <a href="/contact/">contact us online</a> for a free consultation.', 'Probate Administration', '', 'inherit', 'closed', 'closed', '', '77-revision-v1', '', '', '2016-05-20 18:48:02', '2016-05-20 18:48:02', '', 77, 'http://tedsmithdemo.com/77-revision-v1/', 0, 'revision', '', 0),
(79, 1, '2016-05-20 18:48:51', '2016-05-20 18:48:51', 'Even the best estate planning does not guarantee smooth probate administration when the time comes. If children survive a deceased person, probate litigation may occur. A deceased person’s children are the chief reason for disputes over wills—for example, one sibling may feel wronged and take other siblings to court for probate litigation.\r\n<h2>What Causes Probate Litigation?</h2>\r\nProbate litigation is an action by the probate court to resolve a dispute relating to a deceased person’s wishes. Any number of situations may call for probate litigation, from guardianship contests to trust termination. Members of the family who feel their loved one’s last wishes deserve a second look may file for probate litigation, which can take months or years to settle.\r\n\r\nDuring probate litigation, the plaintiff(s) may challenge the validity of a will, request the court rule on the legal meaning of a particular part of a will, or involve lawsuits against a fiduciary agent who negligently caused damage to the beneficiaries. Risks that increase the chances of probate litigation include:\r\n<ul>\r\n 	<li>Multiple marriages with no prenuptial agreements</li>\r\n 	<li>Dysfunctional families with many people who have different desires</li>\r\n 	<li>A “nonstandard” estate plan that makes a controversial decision, such as cutting out a child or giving a gift to a mistress</li>\r\n 	<li>Appointing a poor fiduciary agent</li>\r\n 	<li>Faulty or conceived estate planning</li>\r\n</ul>\r\nA number of different factors contribute to the need for probate litigation. Basically, if someone in the family is unhappy about the results of probate administration, he or she can demand probate litigation. The litigation process can be very lengthy and complex, and the plaintiff(s) needs to hire a skilled probate lawyer to handle it efficiently.\r\n<h2>How to Avoid Probate Litigation</h2>\r\nIn some families, probate litigation may be unavoidable, but in many situations, a deceased person’s preparations before death can go great lengths toward avoiding lengthy and stressful probate litigations. When a person carefully plans the fate of his or her estate, including large and small assets, investments, family businesses, etc., he or she can leave no room for argument. By working with an estate-planning lawyer to plan for the future with clarity and tact, you can maximize the benefits to your family while ensuring your exact wishes are upheld.\r\n\r\nIn over 40 years of probate litigation experience, Ted Smith Law Group, PLLC has learned that the more explanatory an estate plan is, the less likely the surviving family will enter probate litigation. For example, say you have to make a tough decision regarding who will inherit a family business. Your oldest son may assume he will inherit the company, but you may feel your second son is a better fit for a management position. These decisions can easily result in probate litigation after your death unless you clearly explain the reasons for your plan in a way that is calm and rational.\r\n<h2>Need Help During Probate Litigation?</h2>\r\nThe steps involved in proper probate litigation can be difficult for families of a deceased person to handle. Probate litigation is often wrought with emotion, including anger and sadness. Probate attorneys are not therapists, but they often play the part of a family mediator in these tricky situations. Finding a lawyer you feel good about can increase the chances of an amicable resolution during litigation.\r\n\r\nTrust the attorneys at Ted Smith Law Group, PLLC, for honest, dependable legal representation. Ted Smith and his team of probate attorneys pride themselves on building a personal relationship with past and present clients. We know what it takes to successfully navigate delicate familial probate litigation. <a href="/contact/">Contact us today</a> for a free case evaluation, and find out the difference an experienced probate lawyer makes.<strong>\r\n</strong>', 'Probate Litigation', '', 'publish', 'closed', 'closed', '', 'probate-litigation', '', '', '2016-05-20 18:49:17', '2016-05-20 18:49:17', '', 75, 'http://tedsmithdemo.com/?page_id=79', 0, 'page', '', 0),
(80, 1, '2016-05-20 18:48:51', '2016-05-20 18:48:51', 'Even the best estate planning does not guarantee smooth probate administration when the time comes. If children survive a deceased person, probate litigation may occur. A deceased person’s children are the chief reason for disputes over wills—for example, one sibling may feel wronged and take other siblings to court for probate litigation.\r\n<h2>What Causes Probate Litigation?</h2>\r\nProbate litigation is an action by the probate court to resolve a dispute relating to a deceased person’s wishes. Any number of situations may call for probate litigation, from guardianship contests to trust termination. Members of the family who feel their loved one’s last wishes deserve a second look may file for probate litigation, which can take months or years to settle.\r\n\r\nDuring probate litigation, the plaintiff(s) may challenge the validity of a will, request the court rule on the legal meaning of a particular part of a will, or involve lawsuits against a fiduciary agent who negligently caused damage to the beneficiaries. Risks that increase the chances of probate litigation include:\r\n<ul>\r\n 	<li>Multiple marriages with no prenuptial agreements</li>\r\n 	<li>Dysfunctional families with many people who have different desires</li>\r\n 	<li>A “nonstandard” estate plan that makes a controversial decision, such as cutting out a child or giving a gift to a mistress</li>\r\n 	<li>Appointing a poor fiduciary agent</li>\r\n 	<li>Faulty or conceived estate planning</li>\r\n</ul>\r\nA number of different factors contribute to the need for probate litigation. Basically, if someone in the family is unhappy about the results of probate administration, he or she can demand probate litigation. The litigation process can be very lengthy and complex, and the plaintiff(s) needs to hire a skilled probate lawyer to handle it efficiently.\r\n<h2>How to Avoid Probate Litigation</h2>\r\nIn some families, probate litigation may be unavoidable, but in many situations, a deceased person’s preparations before death can go great lengths toward avoiding lengthy and stressful probate litigations. When a person carefully plans the fate of his or her estate, including large and small assets, investments, family businesses, etc., he or she can leave no room for argument. By working with an estate-planning lawyer to plan for the future with clarity and tact, you can maximize the benefits to your family while ensuring your exact wishes are upheld.\r\n\r\nIn over 40 years of probate litigation experience, Ted Smith Law Group, PLLC has learned that the more explanatory an estate plan is, the less likely the surviving family will enter probate litigation. For example, say you have to make a tough decision regarding who will inherit a family business. Your oldest son may assume he will inherit the company, but you may feel your second son is a better fit for a management position. These decisions can easily result in probate litigation after your death unless you clearly explain the reasons for your plan in a way that is calm and rational.\r\n<h2>Need Help During Probate Litigation?</h2>\r\nThe steps involved in proper probate litigation can be difficult for families of a deceased person to handle. Probate litigation is often wrought with emotion, including anger and sadness. Probate attorneys are not therapists, but they often play the part of a family mediator in these tricky situations. Finding a lawyer you feel good about can increase the chances of an amicable resolution during litigation.\r\n\r\nTrust the attorneys at Ted Smith Law Group, PLLC, for honest, dependable legal representation. Ted Smith and his team of probate attorneys pride themselves on building a personal relationship with past and present clients. We know what it takes to successfully navigate delicate familial probate litigation. <a href="/contact/">Contact us today</a> for a free case evaluation, and find out the difference an experienced probate lawyer makes.<strong>\r\n</strong>', 'Probate Litigation', '', 'inherit', 'closed', 'closed', '', '79-revision-v1', '', '', '2016-05-20 18:48:51', '2016-05-20 18:48:51', '', 79, 'http://tedsmithdemo.com/79-revision-v1/', 0, 'revision', '', 0),
(81, 1, '2016-05-20 18:50:05', '2016-05-20 18:50:05', 'When a loved one dies, we hope you are not caught in a legal battle to decide the legitimacy of his or her last will and testament. Unfortunately, going to court is often the only solution to settling a will dispute—especially if the deceased left behind high-value or complex assets and did not have leave a clear estate plan.\r\n<h2>About Contested Wills</h2>\r\nWhen a dispute arises between the surviving members of a deceased person’s family about the terms of the will, emotions run high. The legal issues involved with contested wills on top of strained family relationships can make will contests some of the most complex lawsuits for everyone involved. When a family member believes he or she has lost a rightful inheritance, the litigation process is much less simple than standard probate administration.\r\n\r\nIn Texas, when a person dies with an uncontested will (valid or invalid), his or her property goes to those named in the will. When there is no will or the will is contested, the deceased person’s property instead goes through <a href="http://www.nolo.com/legal-encyclopedia/intestate-succession" target="_blank">intestate succession</a>. Property is then subject to probate litigation. When a will is successfully contested, the children of the deceased person will inherit most of the assets. Texas courts will consider family members besides children rightful heirs if the deceased had no spouse or children.\r\n<h2>Why a Party Might Contest a Will</h2>\r\nAlthough will contests can be daunting legal actions, they are often worth the effort. If the plaintiffs honestly believe they deserve more than what the will laid out or if they suspect foul play in the deceased person’s final will, a will contest can secure justice. For example, elders are more and more often the subjects of financial abuse—from caretakers, friends, neighbors, and even family members. When someone suspects another person forced a loved one to revise his or her wishes, the law can intervene.\r\n\r\nA family member may call into question the validity of a will if the deceased person was not in his or her right mind toward end of life or if the deceased person made a sudden change to the contents of the will. Sudden changes may be a sign of foul play, such as an outside influence deceiving or threatening the deceased person into changing the will. In any case, if someone has reason to question a will’s validity, he or she may contest the document.\r\n<h2>The Process to Contest a Will</h2>\r\nTo start litigation for a will contest, the plaintiff must qualify as an interested party: a child, heir, spouse, creditor, or any person with a claim against the estate the court is administering. If you identify as an interested party, you then need to hire a will contest attorney with experience in the area. Will contests can be extremely complex lawsuits and need the expertise of a reliable attorney to succeed.\r\n\r\nAfter you have hired a trusted attorney, you need to file a claim within Texas’s statute of limitations for will contests. The statute of limitations regarding contested wills is complicated. It centers on the date the will was admitted to probate, not the death of the deceased person. It also depends on the person doing the contesting and can vary from two years from the start of probate to no limit in the event of fraud.\r\n<h2>Local Lawyers On Your Side</h2>\r\nWhen your loved one’s estate plans cause more strife than peace, look to Ted Smith Law Group, PLLC, for help. Filing for a will contest can mean familial strife and a long legal battle ahead. If you need legal help with your will contest, <a href="/contact/">contact us</a> for a free legal consultation.', 'Contested Wills', '', 'publish', 'closed', 'closed', '', 'contested-wills', '', '', '2016-05-20 18:50:05', '2016-05-20 18:50:05', '', 75, 'http://tedsmithdemo.com/?page_id=81', 0, 'page', '', 0),
(82, 1, '2016-05-20 18:50:05', '2016-05-20 18:50:05', 'When a loved one dies, we hope you are not caught in a legal battle to decide the legitimacy of his or her last will and testament. Unfortunately, going to court is often the only solution to settling a will dispute—especially if the deceased left behind high-value or complex assets and did not have leave a clear estate plan.\r\n<h2>About Contested Wills</h2>\r\nWhen a dispute arises between the surviving members of a deceased person’s family about the terms of the will, emotions run high. The legal issues involved with contested wills on top of strained family relationships can make will contests some of the most complex lawsuits for everyone involved. When a family member believes he or she has lost a rightful inheritance, the litigation process is much less simple than standard probate administration.\r\n\r\nIn Texas, when a person dies with an uncontested will (valid or invalid), his or her property goes to those named in the will. When there is no will or the will is contested, the deceased person’s property instead goes through <a href="http://www.nolo.com/legal-encyclopedia/intestate-succession" target="_blank">intestate succession</a>. Property is then subject to probate litigation. When a will is successfully contested, the children of the deceased person will inherit most of the assets. Texas courts will consider family members besides children rightful heirs if the deceased had no spouse or children.\r\n<h2>Why a Party Might Contest a Will</h2>\r\nAlthough will contests can be daunting legal actions, they are often worth the effort. If the plaintiffs honestly believe they deserve more than what the will laid out or if they suspect foul play in the deceased person’s final will, a will contest can secure justice. For example, elders are more and more often the subjects of financial abuse—from caretakers, friends, neighbors, and even family members. When someone suspects another person forced a loved one to revise his or her wishes, the law can intervene.\r\n\r\nA family member may call into question the validity of a will if the deceased person was not in his or her right mind toward end of life or if the deceased person made a sudden change to the contents of the will. Sudden changes may be a sign of foul play, such as an outside influence deceiving or threatening the deceased person into changing the will. In any case, if someone has reason to question a will’s validity, he or she may contest the document.\r\n<h2>The Process to Contest a Will</h2>\r\nTo start litigation for a will contest, the plaintiff must qualify as an interested party: a child, heir, spouse, creditor, or any person with a claim against the estate the court is administering. If you identify as an interested party, you then need to hire a will contest attorney with experience in the area. Will contests can be extremely complex lawsuits and need the expertise of a reliable attorney to succeed.\r\n\r\nAfter you have hired a trusted attorney, you need to file a claim within Texas’s statute of limitations for will contests. The statute of limitations regarding contested wills is complicated. It centers on the date the will was admitted to probate, not the death of the deceased person. It also depends on the person doing the contesting and can vary from two years from the start of probate to no limit in the event of fraud.\r\n<h2>Local Lawyers On Your Side</h2>\r\nWhen your loved one’s estate plans cause more strife than peace, look to Ted Smith Law Group, PLLC, for help. Filing for a will contest can mean familial strife and a long legal battle ahead. If you need legal help with your will contest, <a href="/contact/">contact us</a> for a free legal consultation.', 'Contested Wills', '', 'inherit', 'closed', 'closed', '', '81-revision-v1', '', '', '2016-05-20 18:50:05', '2016-05-20 18:50:05', '', 81, 'http://tedsmithdemo.com/81-revision-v1/', 0, 'revision', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(83, 1, '2016-05-20 18:51:02', '2016-05-20 18:51:02', 'Whether your doctor prescribed you the wrong medication for your illness or misdiagnosed your condition, you may have a case of medical malpractice. Medical malpractice laws in Texas differ from laws in other states, but many main factors remain the same. Understanding what constitutes medical malpractice, how to prove negligence, and how to file a medical malpractice claim in Texas can help you obtain compensation for damages.\r\n<h2>What Is Medical Malpractice in Texas?</h2>\r\nAny form of harm a healthcare professional inflicts on a patient during the course of treatment is considered medical malpractice. For grounds of a medical malpractice lawsuit, however, the injured party must prove that the healthcare professional’s action or inaction was negligent and that this negligence caused an injury.\r\n\r\nProving your healthcare practitioner made a mistake is not enough to demonstrate a medical malpractice claim. The mistake must have been negligent or reckless in nature and be the direct cause of an injury. For example, the courts may not consider a doctor misdiagnosing terminal cancer medical malpractice since the outcome would have remained the same even with a correct diagnosis. Since the misdiagnoses caused no injury, it is not malpractice.\r\n\r\nHowever, if a doctor misdiagnoses a treatable form of cancer, the condition can worsen due to lack of proper treatment. This is especially true for fast-spreading forms of the condition, such as colon cancer. Most patients with malignant cancer have a much better chance of surviving if it is properly diagnosed before it has time to spread to other parts of the body.\r\n\r\nOther common forms of medical malpractice include:\r\n<ul>\r\n 	<li>Delayed diagnosis</li>\r\n 	<li>Medication error</li>\r\n 	<li>Surgical error</li>\r\n 	<li>Anesthesia error</li>\r\n 	<li>Birth injury</li>\r\n 	<li>Neglect</li>\r\n 	<li>Wrongful death</li>\r\n</ul>\r\nThe consequences of medical malpractice range from minor to deadly. As long as the victim can prove his or her injuries are the direct result of someone else’s negligence, he or she may be able to win compensation for medical expenses, pain and suffering, mental anguish, lost wages, and other punitive and compensatory damages.\r\n<h2>Who Is Responsible for Malpractice?</h2>\r\nDepending on the situation, the court may hold different people involved in the medical malpractice case responsible for resulting damages. When employees of the hospital cause the injury, such as nurses or maintenance crews, the courts will hold the hospital strictly responsible. Most doctors, however, are independent contractors and not employees of the hospital.\r\n\r\nIf an independently contracted physician caused your injuries, you can sue the individual but not the hospital. If a drug caused your injuries, you may be able to sue the manufacturing company if the drug itself was defective, the distributer, or the physician who prescribed the drug. Your lawyer can help you identify the party responsible for your injuries.\r\n<h2>How to File a Medical Malpractice Claim in Texas</h2>\r\nMedical malpractice lawsuits can be complex and difficult to prove. You need the help of experienced malpractice lawyers to file the proper paperwork in time to take your case to court. Texas has a two-year statute of limitations after the malpractice incident or two years after the realization of an injury to file a claim. Seek legal help the moment you suspect medical malpractice. The faster you do so, the faster your case can develop—and the sooner you can receive compensation.\r\n\r\nIf you are ready to file a medical malpractice claim in Texas, <a href="/contact/">contact Ted Smith Law Group, PLLC</a>, for a free case evaluation. We have helped victims of medical malpractice recover damages for injuries caused by others’ neglect and carelessness. Let our 40+ years of experience benefit you and your family during this difficult time so you can focus on healing.', 'Medical Malpractice', '', 'publish', 'closed', 'closed', '', 'medical-malpractice', '', '', '2016-05-20 18:51:02', '2016-05-20 18:51:02', '', 0, 'http://tedsmithdemo.com/?page_id=83', 0, 'page', '', 0),
(84, 1, '2016-05-20 18:51:02', '2016-05-20 18:51:02', 'Whether your doctor prescribed you the wrong medication for your illness or misdiagnosed your condition, you may have a case of medical malpractice. Medical malpractice laws in Texas differ from laws in other states, but many main factors remain the same. Understanding what constitutes medical malpractice, how to prove negligence, and how to file a medical malpractice claim in Texas can help you obtain compensation for damages.\r\n<h2>What Is Medical Malpractice in Texas?</h2>\r\nAny form of harm a healthcare professional inflicts on a patient during the course of treatment is considered medical malpractice. For grounds of a medical malpractice lawsuit, however, the injured party must prove that the healthcare professional’s action or inaction was negligent and that this negligence caused an injury.\r\n\r\nProving your healthcare practitioner made a mistake is not enough to demonstrate a medical malpractice claim. The mistake must have been negligent or reckless in nature and be the direct cause of an injury. For example, the courts may not consider a doctor misdiagnosing terminal cancer medical malpractice since the outcome would have remained the same even with a correct diagnosis. Since the misdiagnoses caused no injury, it is not malpractice.\r\n\r\nHowever, if a doctor misdiagnoses a treatable form of cancer, the condition can worsen due to lack of proper treatment. This is especially true for fast-spreading forms of the condition, such as colon cancer. Most patients with malignant cancer have a much better chance of surviving if it is properly diagnosed before it has time to spread to other parts of the body.\r\n\r\nOther common forms of medical malpractice include:\r\n<ul>\r\n 	<li>Delayed diagnosis</li>\r\n 	<li>Medication error</li>\r\n 	<li>Surgical error</li>\r\n 	<li>Anesthesia error</li>\r\n 	<li>Birth injury</li>\r\n 	<li>Neglect</li>\r\n 	<li>Wrongful death</li>\r\n</ul>\r\nThe consequences of medical malpractice range from minor to deadly. As long as the victim can prove his or her injuries are the direct result of someone else’s negligence, he or she may be able to win compensation for medical expenses, pain and suffering, mental anguish, lost wages, and other punitive and compensatory damages.\r\n<h2>Who Is Responsible for Malpractice?</h2>\r\nDepending on the situation, the court may hold different people involved in the medical malpractice case responsible for resulting damages. When employees of the hospital cause the injury, such as nurses or maintenance crews, the courts will hold the hospital strictly responsible. Most doctors, however, are independent contractors and not employees of the hospital.\r\n\r\nIf an independently contracted physician caused your injuries, you can sue the individual but not the hospital. If a drug caused your injuries, you may be able to sue the manufacturing company if the drug itself was defective, the distributer, or the physician who prescribed the drug. Your lawyer can help you identify the party responsible for your injuries.\r\n<h2>How to File a Medical Malpractice Claim in Texas</h2>\r\nMedical malpractice lawsuits can be complex and difficult to prove. You need the help of experienced malpractice lawyers to file the proper paperwork in time to take your case to court. Texas has a two-year statute of limitations after the malpractice incident or two years after the realization of an injury to file a claim. Seek legal help the moment you suspect medical malpractice. The faster you do so, the faster your case can develop—and the sooner you can receive compensation.\r\n\r\nIf you are ready to file a medical malpractice claim in Texas, <a href="/contact/">contact Ted Smith Law Group, PLLC</a>, for a free case evaluation. We have helped victims of medical malpractice recover damages for injuries caused by others’ neglect and carelessness. Let our 40+ years of experience benefit you and your family during this difficult time so you can focus on healing.', 'Medical Malpractice', '', 'inherit', 'closed', 'closed', '', '83-revision-v1', '', '', '2016-05-20 18:51:02', '2016-05-20 18:51:02', '', 83, 'http://tedsmithdemo.com/83-revision-v1/', 0, 'revision', '', 0),
(85, 1, '2016-05-20 18:51:24', '2016-05-20 18:51:24', 'Page content being updated.', 'Home', '', 'publish', 'closed', 'closed', '', 'home', '', '', '2016-05-20 18:51:24', '2016-05-20 18:51:24', '', 0, 'http://tedsmithdemo.com/?page_id=85', 0, 'page', '', 0),
(86, 1, '2016-05-20 18:51:24', '2016-05-20 18:51:24', 'Page content being updated.', 'Home', '', 'inherit', 'closed', 'closed', '', '85-revision-v1', '', '', '2016-05-20 18:51:24', '2016-05-20 18:51:24', '', 85, 'http://tedsmithdemo.com/85-revision-v1/', 0, 'revision', '', 0),
(87, 1, '2016-05-20 18:53:30', '2016-05-20 18:53:30', 'Page being updated.', 'Site Map', '', 'publish', 'closed', 'closed', '', 'site-map', '', '', '2016-05-20 18:53:30', '2016-05-20 18:53:30', '', 0, 'http://tedsmithdemo.com/?page_id=87', 0, 'page', '', 0),
(88, 1, '2016-05-20 18:53:30', '2016-05-20 18:53:30', 'Page being updated.', 'Site Map', '', 'inherit', 'closed', 'closed', '', '87-revision-v1', '', '', '2016-05-20 18:53:30', '2016-05-20 18:53:30', '', 87, 'http://tedsmithdemo.com/87-revision-v1/', 0, 'revision', '', 0),
(89, 1, '2016-05-20 18:55:58', '2016-05-20 18:55:58', '<h2>Defending for your rights in Bell County and surrounding communities</h2>\r\nIf you have been charged with a felony or misdemeanor, you need a Texas criminal defense attorney. At Ted Smith Law Group, PLLC, we understand the criminal process and we will take the time to explain that process to our clients. <a href="/contact/" target="_self">Contact us </a>to schedule a <strong>free initial consultation</strong> and discuss your criminal case. Our law firm was founded on the belief that everyone is entitled to a defense that preserves their rights.\r\n\r\nOur criminal defense attorney handles a wide variety of criminal cases, from Class C misdemeanors to first degree felonies, such as:\r\n<h2><strong>Assault Offenses:</strong></h2>\r\n<ul>\r\n 	<li>Assault on a family member</li>\r\n 	<li>Felony assault on a family member\r\n<ul>\r\n 	<li>Enhanced assault</li>\r\n 	<li class="last-child">Choking/impeding breathing</li>\r\n</ul>\r\n</li>\r\n 	<li>Injury to child/elderly/disabled</li>\r\n 	<li class="last-child">Aggravated assaults\r\n<ul>\r\n 	<li>Assault causing serious bodily injury</li>\r\n 	<li class="last-child">Assault with a Deadly Weapon</li>\r\n</ul>\r\n</li>\r\n</ul>\r\n<h2><strong>Burglary:</strong></h2>\r\n<ul>\r\n 	<li>Burglary of a Vehicle</li>\r\n 	<li>Burglary of a Building</li>\r\n 	<li class="last-child">Burglary of a Habitation</li>\r\n</ul>\r\n<h2><strong>Criminal Mischief</strong></h2>\r\n<h2><strong>Criminal Trespass</strong></h2>\r\n<h2><strong>Driving with a Suspended License</strong></h2>\r\n<h2><strong>Drug Charges:</strong></h2>\r\n<ul>\r\n 	<li>Misdemeanors or felonies</li>\r\n 	<li>Marijuana, cocaine, heroin, methamphetamines, ecstacy</li>\r\n 	<li>Prescription drug fraud</li>\r\n 	<li>Possession and delivery of a controlled substance</li>\r\n 	<li class="last-child">Illegal investment</li>\r\n</ul>\r\n<h2><strong>DWI/DUI Defense:</strong></h2>\r\n<ul>\r\n 	<li>Misdemeanor or felony DWI / DUI</li>\r\n 	<li>DWI Charges with or without a breath sample/breathalyzer test</li>\r\n 	<li>DWI Cases with or without a blood sample</li>\r\n 	<li class="last-child">DWI/DUI Cases with or without standardized field sobriety tests</li>\r\n</ul>\r\n<h2><strong>Juvenile Crimes</strong></h2>\r\n<h2><strong>Prostitution Charges</strong></h2>\r\n<h2><strong>Robbery:</strong></h2>\r\n<ul>\r\n 	<li class="last-child">Aggravated robbery</li>\r\n</ul>\r\n<h2><strong>Sex Crimes:</strong></h2>\r\n<ul>\r\n 	<li>Sexual assault</li>\r\n 	<li>Possession of child pornography</li>\r\n 	<li class="last-child">Indecency</li>\r\n</ul>\r\n<h2><strong>Tampering with government records</strong></h2>\r\n<h2><strong>Tampering with evidence</strong></h2>\r\n<h2><strong>Theft:</strong></h2>\r\n<ul>\r\n 	<li>Shoplifting</li>\r\n 	<li>Theft from person</li>\r\n 	<li class="last-child">Theft by check</li>\r\n</ul>\r\n<h2><strong>Traffic Offenses</strong></h2>', 'Criminal Defense', '', 'publish', 'closed', 'closed', '', 'criminal-defense', '', '', '2016-05-20 18:55:58', '2016-05-20 18:55:58', '', 0, 'http://tedsmithdemo.com/?page_id=89', 0, 'page', '', 0),
(90, 1, '2016-05-20 18:55:58', '2016-05-20 18:55:58', '<h2>Defending for your rights in Bell County and surrounding communities</h2>\r\nIf you have been charged with a felony or misdemeanor, you need a Texas criminal defense attorney. At Ted Smith Law Group, PLLC, we understand the criminal process and we will take the time to explain that process to our clients. <a href="/contact/" target="_self">Contact us </a>to schedule a <strong>free initial consultation</strong> and discuss your criminal case. Our law firm was founded on the belief that everyone is entitled to a defense that preserves their rights.\r\n\r\nOur criminal defense attorney handles a wide variety of criminal cases, from Class C misdemeanors to first degree felonies, such as:\r\n<h2><strong>Assault Offenses:</strong></h2>\r\n<ul>\r\n 	<li>Assault on a family member</li>\r\n 	<li>Felony assault on a family member\r\n<ul>\r\n 	<li>Enhanced assault</li>\r\n 	<li class="last-child">Choking/impeding breathing</li>\r\n</ul>\r\n</li>\r\n 	<li>Injury to child/elderly/disabled</li>\r\n 	<li class="last-child">Aggravated assaults\r\n<ul>\r\n 	<li>Assault causing serious bodily injury</li>\r\n 	<li class="last-child">Assault with a Deadly Weapon</li>\r\n</ul>\r\n</li>\r\n</ul>\r\n<h2><strong>Burglary:</strong></h2>\r\n<ul>\r\n 	<li>Burglary of a Vehicle</li>\r\n 	<li>Burglary of a Building</li>\r\n 	<li class="last-child">Burglary of a Habitation</li>\r\n</ul>\r\n<h2><strong>Criminal Mischief</strong></h2>\r\n<h2><strong>Criminal Trespass</strong></h2>\r\n<h2><strong>Driving with a Suspended License</strong></h2>\r\n<h2><strong>Drug Charges:</strong></h2>\r\n<ul>\r\n 	<li>Misdemeanors or felonies</li>\r\n 	<li>Marijuana, cocaine, heroin, methamphetamines, ecstacy</li>\r\n 	<li>Prescription drug fraud</li>\r\n 	<li>Possession and delivery of a controlled substance</li>\r\n 	<li class="last-child">Illegal investment</li>\r\n</ul>\r\n<h2><strong>DWI/DUI Defense:</strong></h2>\r\n<ul>\r\n 	<li>Misdemeanor or felony DWI / DUI</li>\r\n 	<li>DWI Charges with or without a breath sample/breathalyzer test</li>\r\n 	<li>DWI Cases with or without a blood sample</li>\r\n 	<li class="last-child">DWI/DUI Cases with or without standardized field sobriety tests</li>\r\n</ul>\r\n<h2><strong>Juvenile Crimes</strong></h2>\r\n<h2><strong>Prostitution Charges</strong></h2>\r\n<h2><strong>Robbery:</strong></h2>\r\n<ul>\r\n 	<li class="last-child">Aggravated robbery</li>\r\n</ul>\r\n<h2><strong>Sex Crimes:</strong></h2>\r\n<ul>\r\n 	<li>Sexual assault</li>\r\n 	<li>Possession of child pornography</li>\r\n 	<li class="last-child">Indecency</li>\r\n</ul>\r\n<h2><strong>Tampering with government records</strong></h2>\r\n<h2><strong>Tampering with evidence</strong></h2>\r\n<h2><strong>Theft:</strong></h2>\r\n<ul>\r\n 	<li>Shoplifting</li>\r\n 	<li>Theft from person</li>\r\n 	<li class="last-child">Theft by check</li>\r\n</ul>\r\n<h2><strong>Traffic Offenses</strong></h2>', 'Criminal Defense', '', 'inherit', 'closed', 'closed', '', '89-revision-v1', '', '', '2016-05-20 18:55:58', '2016-05-20 18:55:58', '', 89, 'http://tedsmithdemo.com/89-revision-v1/', 0, 'revision', '', 0),
(91, 1, '2016-05-20 18:57:08', '2016-05-20 18:57:08', '"In this world nothing can be said to be certain, except death and taxes."\r\n\r\n- Ben Franklin, Letter dated November 13, 1789 to Jean Baptiste LeRoy\r\n\r\nTruer words were never spoken! You may not realize it, but you are paying taxes almost every day. Federal income taxes, social security taxes, and Medicaid taxes, and that\'s just while you are working. In Texas there are sales taxes on many items. You pay a gasoline tax when you pump gas. If you stay in a hotel you pay an occupancy tax. Texas has property taxes if you own a home or land. Taxes are almost ubiquitous. But what happens when you fail to pay your taxes? The government, both federal and state, have a wide range of options when it comes to pursuing tax debtors for delinquent taxes.\r\n\r\nYou may think, "that can\'t happen to me, only rich people have to worry about avoiding taxes." You\'d be wrong. Many people use tax preparers and think they will be fine. That\'s not necessarily true, either. Often times, it may be the inexperienced person making ten dollars an hour that makes the mistake. Who does the IRS go after when that happens? I\'ll give you a hint-it\'s not the tax preparer.\r\n\r\nOne common mistake is married couples filing separate returns and both of them claiming head of household. This is not allowed. Even if you are separated, you must file Married Filing Separate. If you claim head of household and weren\'t supposed to, the IRS can come after you for back taxes, including penalties, fees, and interest. This can amount to tens of thousands of dollars. If they believe you did it with an intent to defraud, it can even mean prison.\r\n\r\nThe IRS can garnish wages, setoff your tax refunds in the future, and can even put a lien on your property, preventing you from selling it without paying them first. All is not lost, though. There are ways to work with the IRS to reduce the amounts you owe. Whether through bankruptcy or negotiating directly with the IRS through an offer in compromise, there are solutions to federal tax issues, but don\'t delay, the fees and interest only add up.\r\n<h2>Get A Free Consultation With A Lawyer</h2>\r\nCall 254-690-5688 or reach out to our accident lawyers <a href="/contact/" target="_self">online</a>. We look forward to serving your legal needs.', 'Tax Law', '', 'publish', 'closed', 'closed', '', 'tax-law', '', '', '2016-05-20 18:57:08', '2016-05-20 18:57:08', '', 0, 'http://tedsmithdemo.com/?page_id=91', 0, 'page', '', 0),
(92, 1, '2016-05-20 18:57:08', '2016-05-20 18:57:08', '"In this world nothing can be said to be certain, except death and taxes."\r\n\r\n- Ben Franklin, Letter dated November 13, 1789 to Jean Baptiste LeRoy\r\n\r\nTruer words were never spoken! You may not realize it, but you are paying taxes almost every day. Federal income taxes, social security taxes, and Medicaid taxes, and that\'s just while you are working. In Texas there are sales taxes on many items. You pay a gasoline tax when you pump gas. If you stay in a hotel you pay an occupancy tax. Texas has property taxes if you own a home or land. Taxes are almost ubiquitous. But what happens when you fail to pay your taxes? The government, both federal and state, have a wide range of options when it comes to pursuing tax debtors for delinquent taxes.\r\n\r\nYou may think, "that can\'t happen to me, only rich people have to worry about avoiding taxes." You\'d be wrong. Many people use tax preparers and think they will be fine. That\'s not necessarily true, either. Often times, it may be the inexperienced person making ten dollars an hour that makes the mistake. Who does the IRS go after when that happens? I\'ll give you a hint-it\'s not the tax preparer.\r\n\r\nOne common mistake is married couples filing separate returns and both of them claiming head of household. This is not allowed. Even if you are separated, you must file Married Filing Separate. If you claim head of household and weren\'t supposed to, the IRS can come after you for back taxes, including penalties, fees, and interest. This can amount to tens of thousands of dollars. If they believe you did it with an intent to defraud, it can even mean prison.\r\n\r\nThe IRS can garnish wages, setoff your tax refunds in the future, and can even put a lien on your property, preventing you from selling it without paying them first. All is not lost, though. There are ways to work with the IRS to reduce the amounts you owe. Whether through bankruptcy or negotiating directly with the IRS through an offer in compromise, there are solutions to federal tax issues, but don\'t delay, the fees and interest only add up.\r\n<h2>Get A Free Consultation With A Lawyer</h2>\r\nCall 254-690-5688 or reach out to our accident lawyers <a href="/contact/" target="_self">online</a>. We look forward to serving your legal needs.', 'Tax Law', '', 'inherit', 'closed', 'closed', '', '91-revision-v1', '', '', '2016-05-20 18:57:08', '2016-05-20 18:57:08', '', 91, 'http://tedsmithdemo.com/91-revision-v1/', 0, 'revision', '', 0),
(93, 1, '2016-05-20 18:57:13', '2016-05-20 18:57:13', '"In this world nothing can be said to be certain, except death and taxes."\n\n- Ben Franklin, Letter dated November 13, 1789 to Jean Baptiste LeRoy\n\nTruer words were never spoken! You may not realize it, but you are paying taxes almost every day. Federal income taxes, social security taxes, and Medicaid taxes, and that\'s just while you are working. In Texas there are sales taxes on many items. You pay a gasoline tax when you pump gas. If you stay in a hotel you pay an occupancy tax. Texas has property taxes if you own a home or land. Taxes are almost ubiquitous. But what happens when you fail to pay your taxes? The government, both federal and state, have a wide range of options when it comes to pursuing tax debtors for delinquent taxes.\n\nYou may think, "that can\'t happen to me, only rich people have to worry about avoiding taxes." You\'d be wrong. Many people use tax preparers and think they will be fine. That\'s not necessarily true, either. Often times, it may be the inexperienced person making ten dollars an hour that makes the mistake. Who does the IRS go after when that happens? I\'ll give you a hint-it\'s not the tax preparer.\n\nOne common mistake is married couples filing separate returns and both of them claiming head of household. This is not allowed. Even if you are separated, you must file Married Filing Separate. If you claim head of household and weren\'t supposed to, the IRS can come after you for back taxes, including penalties, fees, and interest. This can amount to tens of thousands of dollars. If they believe you did it with an intent to defraud, it can even mean prison.\n\nThe IRS can garnish wages, setoff your tax refunds in the future, and can even put a lien on your property, preventing you from selling it without paying them first. All is not lost, though. There are ways to work with the IRS to reduce the amounts you owe. Whether through bankruptcy or negotiating directly with the IRS through an offer in compromise, there are solutions to federal tax issues, but don\'t delay, the fees and interest only add up.\n<h2>Get A Free Consultation With A Lawyer</h2>\nCall 254-690-5688 or reach out to our accident lawyers <a href="/contact/" target="_self">online</a>. We look forward to serving your legal needs.', 'Tax Law', '', 'inherit', 'closed', 'closed', '', '91-autosave-v1', '', '', '2016-05-20 18:57:13', '2016-05-20 18:57:13', '', 91, 'http://tedsmithdemo.com/91-autosave-v1/', 0, 'revision', '', 0),
(94, 1, '2016-05-20 18:58:11', '2016-05-20 18:58:11', '<h2>Real Estate Attorney in Harker Heights</h2>\r\nFor the past thirty-five years, Ted Smith has successfully assisted clients in every aspect of real estate law. During this time, Ted Smith has helped his clients avoid many of the problems associated with complex real estate transactions. Ted Smith has represented associations, builders, buyers, contractors, developers, property management companies, home owners, real estate agents, and sellers. Ted Smith takes the time to help his clients understand all of their options under the law. The real estate lawyers at Ted Smith Law Group, PLLC can draft every type of real estate document, including closing documents, deeds, easements, notes, and security agreements. Our real estate attorneys have experience in every facet of real estate law and know how to get the results you deserve. Come in to see us today and let us help you with your real estate transactions.\r\n<ul>\r\n 	<li>Buying, Selling, or Leasing Residential and Commercial Properties</li>\r\n 	<li>Real Estate Closings</li>\r\n 	<li>For Sale by Owner</li>\r\n 	<li>Deeds - Transferring Title</li>\r\n 	<li>Mixed-Use Properties</li>\r\n 	<li>Eminent Domain and Condemnation</li>\r\n 	<li>Property Management</li>\r\n 	<li>Foreclosures</li>\r\n 	<li>Mechanic\'s Liens</li>\r\n 	<li>Construction and Contractor Disputes</li>\r\n 	<li>Boundary Disputes (Fences, Boundary, Encroachment)</li>\r\n 	<li class="last-child">Zoning and Variances</li>\r\n</ul>\r\n<h2>Buying, Selling, or Leasing Residential and Commercial Properties</h2>\r\nThe real estate lawyers at Ted Smith Law Group, PLLC can help you review or draft lease agreements for your residential or commercial property. We can advise you on the purchase or sale of residential or commercial property. We can also help you resolve legal disputes that arise from ownership of residential or commercial property. Let our law firm handle your real estate matter. Ted Smith has been Board Certified in Residential and Commercial Real Estate by the Texas Board of Legal Specialization since 1983.\r\n<h2>Real Estate Closings</h2>\r\nTed Smith Law Group, PLLC handles real estate closings for both residential and commercial properties. If you are a bank, title insurance company, real estate agent, buyer, or seller, contact us today for a free consultation on your real estate closing.\r\n<h2>For Sale by Owner</h2>\r\nIf you have decided to sell your home without the assistance of a real estate agent, let the attorneys at Ted Smith Law Group draft your purchase agreement and other legal documents associated with the sale transaction. Contact the Ted Smith Law Group, PLLC today at 254-690-5688.\r\n<h2>Deeds - Transferring Title</h2>\r\nDid you know that the Ted Smith Law Group, PLLC drafts real estate documents? We can draft deeds to transfer title to your property. There are many types of deeds including: General Warranty Deeds, Special Warranty Deeds, Deeds without Warranties, Assumption Deeds, Wraparound Deeds, and Deeds of Trust. Let the Ted Smith Law Group, PLLC help you choose which deed you need for your particular property transfer. Contact the real estate lawyers at Ted Smith Law Group, PLLC today at 254-690-5688.\r\n<h2>Mixed-Use Properties</h2>\r\nAs a tenant or owner of a mixed use property, you understand the challenges associated with living in, working in, or owning mixed-use property. If you want to purchase or sell mixed use property, we can advise you on the process, draft documents, and provide general legal guidance. If you are involved in a legal dispute regarding mixed use property, let the Ted Smith Law Group, PLLC be your advocate and fight for your interests.\r\n<h2>Eminent Domain and Condemnation</h2>\r\nIs the government trying to take your property by eminent domain? We can handle all aspects of these types of proceedings including: determining whether the government is authorized to take your property, property valuation, settlement negotiations, and representing you at trial. Contact the real estate lawyers at Ted Smith Law Group, PLLC today for a free consultation.\r\n<h2>Property Management</h2>\r\nDo you own a property management company? Do you want to start a property management company? Are you involved in a dispute as the owner of a property management company or do you have a dispute with a property management company? Let the Ted Smith Law Group, PLLC help you draft lease agreements, review lease agreements, incorporate your business, negotiate a settlement, represent you at trial, and much more. Call the Ted Smith Law Group, PLLC today!\r\n<h2>Foreclosures</h2>\r\nAre you behind on your mortgage payments or has the bank foreclosed on your property? Contact our real estate attorneys today for a free consultation on your foreclosure matter.\r\n<h2>Mechanic\'s Liens</h2>\r\nDo you need help placing a mechanics lien on a property? Are you trying to sell your property, but need a mechanic\'s lien removed? Let a real estate lawyer help you through this process. When a home or business owner decides to remodel their property many problems can occur. For example, the remodel may have been done wrong and the owner does not want to pay for the work done, the owner may have run out of funding, and the contractor may have left the project without paying the subcontractors. These types of issues may result in the need for a mechanic\'s lien to be placed on the property. A mechanic\'s lien is a security interest in the title of the property for the benefit of those who supplied material and labor for the property\'s improvement. Mechanic\'s liens are recorded and may cause problems when the homeowner decides to sell their property. If you need help with a mechanic\'s lien contact the Ted Smith Law Group, PLLC today.\r\n<h2>Construction and Contractor Disputes</h2>\r\nAre you a contractor or construction company being sued by one of your customers or subcontractors? We can help. Contact our real estate attorneys today for a free consultation on your real estate matter.\r\n<h2>Boundary Disputes (Fences, Boundary, Encroachment)</h2>\r\nYou may find yourself in a dispute over where your property line begins and where it ends. You may want to live in peace with your neighbors, but find that it has become unbearable to do so. If you want to take legal action or if you have been served with legal papers regarding a boundary dispute, contact the Ted Smith Law Group, PLLC today. Our experienced attorneys can help fight for your interests and rights in a variety of boundary dispute claims. Contact our real estate lawyers today.\r\n<h2>Zoning and Variances</h2>\r\nIf you need your property rezoned or if you need to apply for a variance to use your property in a different way, contact Ted Smith Law Group, PLLC today. We can help familiarize you with local zoning requirements, advise you on your legal options, help you apply for a variance, and argue your case in front of local government officials and homeowner\'s associations.', 'Real Estate', '', 'publish', 'closed', 'closed', '', 'real-estate', '', '', '2016-05-20 18:58:11', '2016-05-20 18:58:11', '', 0, 'http://tedsmithdemo.com/?page_id=94', 0, 'page', '', 0),
(95, 1, '2016-05-20 18:58:11', '2016-05-20 18:58:11', '<h2>Real Estate Attorney in Harker Heights</h2>\r\nFor the past thirty-five years, Ted Smith has successfully assisted clients in every aspect of real estate law. During this time, Ted Smith has helped his clients avoid many of the problems associated with complex real estate transactions. Ted Smith has represented associations, builders, buyers, contractors, developers, property management companies, home owners, real estate agents, and sellers. Ted Smith takes the time to help his clients understand all of their options under the law. The real estate lawyers at Ted Smith Law Group, PLLC can draft every type of real estate document, including closing documents, deeds, easements, notes, and security agreements. Our real estate attorneys have experience in every facet of real estate law and know how to get the results you deserve. Come in to see us today and let us help you with your real estate transactions.\r\n<ul>\r\n 	<li>Buying, Selling, or Leasing Residential and Commercial Properties</li>\r\n 	<li>Real Estate Closings</li>\r\n 	<li>For Sale by Owner</li>\r\n 	<li>Deeds - Transferring Title</li>\r\n 	<li>Mixed-Use Properties</li>\r\n 	<li>Eminent Domain and Condemnation</li>\r\n 	<li>Property Management</li>\r\n 	<li>Foreclosures</li>\r\n 	<li>Mechanic\'s Liens</li>\r\n 	<li>Construction and Contractor Disputes</li>\r\n 	<li>Boundary Disputes (Fences, Boundary, Encroachment)</li>\r\n 	<li class="last-child">Zoning and Variances</li>\r\n</ul>\r\n<h2>Buying, Selling, or Leasing Residential and Commercial Properties</h2>\r\nThe real estate lawyers at Ted Smith Law Group, PLLC can help you review or draft lease agreements for your residential or commercial property. We can advise you on the purchase or sale of residential or commercial property. We can also help you resolve legal disputes that arise from ownership of residential or commercial property. Let our law firm handle your real estate matter. Ted Smith has been Board Certified in Residential and Commercial Real Estate by the Texas Board of Legal Specialization since 1983.\r\n<h2>Real Estate Closings</h2>\r\nTed Smith Law Group, PLLC handles real estate closings for both residential and commercial properties. If you are a bank, title insurance company, real estate agent, buyer, or seller, contact us today for a free consultation on your real estate closing.\r\n<h2>For Sale by Owner</h2>\r\nIf you have decided to sell your home without the assistance of a real estate agent, let the attorneys at Ted Smith Law Group draft your purchase agreement and other legal documents associated with the sale transaction. Contact the Ted Smith Law Group, PLLC today at 254-690-5688.\r\n<h2>Deeds - Transferring Title</h2>\r\nDid you know that the Ted Smith Law Group, PLLC drafts real estate documents? We can draft deeds to transfer title to your property. There are many types of deeds including: General Warranty Deeds, Special Warranty Deeds, Deeds without Warranties, Assumption Deeds, Wraparound Deeds, and Deeds of Trust. Let the Ted Smith Law Group, PLLC help you choose which deed you need for your particular property transfer. Contact the real estate lawyers at Ted Smith Law Group, PLLC today at 254-690-5688.\r\n<h2>Mixed-Use Properties</h2>\r\nAs a tenant or owner of a mixed use property, you understand the challenges associated with living in, working in, or owning mixed-use property. If you want to purchase or sell mixed use property, we can advise you on the process, draft documents, and provide general legal guidance. If you are involved in a legal dispute regarding mixed use property, let the Ted Smith Law Group, PLLC be your advocate and fight for your interests.\r\n<h2>Eminent Domain and Condemnation</h2>\r\nIs the government trying to take your property by eminent domain? We can handle all aspects of these types of proceedings including: determining whether the government is authorized to take your property, property valuation, settlement negotiations, and representing you at trial. Contact the real estate lawyers at Ted Smith Law Group, PLLC today for a free consultation.\r\n<h2>Property Management</h2>\r\nDo you own a property management company? Do you want to start a property management company? Are you involved in a dispute as the owner of a property management company or do you have a dispute with a property management company? Let the Ted Smith Law Group, PLLC help you draft lease agreements, review lease agreements, incorporate your business, negotiate a settlement, represent you at trial, and much more. Call the Ted Smith Law Group, PLLC today!\r\n<h2>Foreclosures</h2>\r\nAre you behind on your mortgage payments or has the bank foreclosed on your property? Contact our real estate attorneys today for a free consultation on your foreclosure matter.\r\n<h2>Mechanic\'s Liens</h2>\r\nDo you need help placing a mechanics lien on a property? Are you trying to sell your property, but need a mechanic\'s lien removed? Let a real estate lawyer help you through this process. When a home or business owner decides to remodel their property many problems can occur. For example, the remodel may have been done wrong and the owner does not want to pay for the work done, the owner may have run out of funding, and the contractor may have left the project without paying the subcontractors. These types of issues may result in the need for a mechanic\'s lien to be placed on the property. A mechanic\'s lien is a security interest in the title of the property for the benefit of those who supplied material and labor for the property\'s improvement. Mechanic\'s liens are recorded and may cause problems when the homeowner decides to sell their property. If you need help with a mechanic\'s lien contact the Ted Smith Law Group, PLLC today.\r\n<h2>Construction and Contractor Disputes</h2>\r\nAre you a contractor or construction company being sued by one of your customers or subcontractors? We can help. Contact our real estate attorneys today for a free consultation on your real estate matter.\r\n<h2>Boundary Disputes (Fences, Boundary, Encroachment)</h2>\r\nYou may find yourself in a dispute over where your property line begins and where it ends. You may want to live in peace with your neighbors, but find that it has become unbearable to do so. If you want to take legal action or if you have been served with legal papers regarding a boundary dispute, contact the Ted Smith Law Group, PLLC today. Our experienced attorneys can help fight for your interests and rights in a variety of boundary dispute claims. Contact our real estate lawyers today.\r\n<h2>Zoning and Variances</h2>\r\nIf you need your property rezoned or if you need to apply for a variance to use your property in a different way, contact Ted Smith Law Group, PLLC today. We can help familiarize you with local zoning requirements, advise you on your legal options, help you apply for a variance, and argue your case in front of local government officials and homeowner\'s associations.', 'Real Estate', '', 'inherit', 'closed', 'closed', '', '94-revision-v1', '', '', '2016-05-20 18:58:11', '2016-05-20 18:58:11', '', 94, 'http://tedsmithdemo.com/94-revision-v1/', 0, 'revision', '', 0),
(96, 1, '2016-05-20 18:59:30', '2016-05-20 18:59:30', '<h2>Chapter 7 and Chapter 13 Bankruptcy Attorneys</h2>\r\nFiling for bankruptcy is a tough decision. There are many questions to answer, and you don\'t have to go through bankruptcy alone. If you are asking questions like: "What chapter should I file under?"; "What are the deadlines?"; "What are all of these meetings?"; "What is a trustee?", or "What debts can I discharge with my bankruptcy?". These bankruptcy questions can often make the bankruptcy process confusing and frightening. Let the bankruptcy professionals at the Ted Smith Law Group, PLLC help you answer these questions. If you need to file for chapter 7, 11,or 13, the bankruptcy lawyers at Ted Smith Law Group, PLLC, can help.\r\n<div id="video_video-v2-Bankruptcy" class="findlawPlayer "><object id="myExperience_video-v2-Bankruptcy" class="BrightcoveExperience" width="300" height="150" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000">            <param name="objectID" value="myExperience_video-v2-Bankruptcy" />            <param name="@videoPlayer" value="3818040494001" />            <param name="@playlistTabs" value="3617254611001" />            <param name="@playlistTabs.featured" value="3617254611001" />            <param name="@playlistCombo" value="3617254611001" />            <param name="@playlistCombo.featured" value="3617254611001" />            <param name="@videoList" value="3617254611001" />            <param name="@videoList.featured" value="3818040494001" />            <param name="movie" value="http://video-transcripts.findlaw.com/html5/swf/dots.swf" />            <param name="bgcolor" value="#FFFFFF" />            <param name="width" value="384" />            <param name="height" value="216" />            <param name="playerID" value="731020614001" />            <param name="playerKey" value="AQ~~,AAAAADqBmOk~,Bp73JJAqj95RQozo02HPJuOEXjlZDp28" />            <param name="isVid" value="true" />            <param name="isUI" value="true" />            <param name="dynamicStreaming" value="true" />            <param name="SubscriptionID" value="2265508" />            <param name="hasTranscripts" value="true" />            <param name="autoStart" value="false" />            <param name="guid" value="qERmmeTx2gY0XT1WWo+FaGbsiNjZv4Q+lmXQywXJ8UXLM4fSZY96ZH/ByrWbSoK8iAiXr9mzwGQsHz48urSakCU7FMnUIHKvzN/LTfBp86U8PMHf5Acl4FUEsJt9Uq1B6xr9LGAm/geHWQAUSEhAvbn1ZSCLUWbU1nDjueQqJGA=" />            <param name="wld_id" value="4463096" />            <param name="email_subject" value="Web site message from www.tedsmithlawgroup.com : Contact" />            <param name="domainName" value="www.tedsmithlawgroup.com" />            <param name="layoutBoxes" value="http://www.tedsmithlawgroup.com/content/css/video-v2-Bankruptcy/layoutBoxes.css" />            <param name="css" value="mediaControls=http://www.tedsmithlawgroup.com/content/css/video-v2-Bankruptcy/mediaControls.css&amp;videoList=http://www.tedsmithlawgroup.com/content/css/video-v2-Bankruptcy/videoList.css&amp;playlistCombo=http://www.tedsmithlawgroup.com/content/css/video-v2-Bankruptcy/playlistCombo.css" />        </object></div>', 'Bankruptcy', '', 'publish', 'closed', 'closed', '', 'bankruptcy', '', '', '2016-05-20 18:59:30', '2016-05-20 18:59:30', '', 0, 'http://tedsmithdemo.com/?page_id=96', 0, 'page', '', 0),
(97, 1, '2016-05-20 18:59:30', '2016-05-20 18:59:30', '<h2>Chapter 7 and Chapter 13 Bankruptcy Attorneys</h2>\r\nFiling for bankruptcy is a tough decision. There are many questions to answer, and you don\'t have to go through bankruptcy alone. If you are asking questions like: "What chapter should I file under?"; "What are the deadlines?"; "What are all of these meetings?"; "What is a trustee?", or "What debts can I discharge with my bankruptcy?". These bankruptcy questions can often make the bankruptcy process confusing and frightening. Let the bankruptcy professionals at the Ted Smith Law Group, PLLC help you answer these questions. If you need to file for chapter 7, 11,or 13, the bankruptcy lawyers at Ted Smith Law Group, PLLC, can help.\r\n<div id="video_video-v2-Bankruptcy" class="findlawPlayer "><object id="myExperience_video-v2-Bankruptcy" class="BrightcoveExperience" width="300" height="150" classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000">            <param name="objectID" value="myExperience_video-v2-Bankruptcy" />            <param name="@videoPlayer" value="3818040494001" />            <param name="@playlistTabs" value="3617254611001" />            <param name="@playlistTabs.featured" value="3617254611001" />            <param name="@playlistCombo" value="3617254611001" />            <param name="@playlistCombo.featured" value="3617254611001" />            <param name="@videoList" value="3617254611001" />            <param name="@videoList.featured" value="3818040494001" />            <param name="movie" value="http://video-transcripts.findlaw.com/html5/swf/dots.swf" />            <param name="bgcolor" value="#FFFFFF" />            <param name="width" value="384" />            <param name="height" value="216" />            <param name="playerID" value="731020614001" />            <param name="playerKey" value="AQ~~,AAAAADqBmOk~,Bp73JJAqj95RQozo02HPJuOEXjlZDp28" />            <param name="isVid" value="true" />            <param name="isUI" value="true" />            <param name="dynamicStreaming" value="true" />            <param name="SubscriptionID" value="2265508" />            <param name="hasTranscripts" value="true" />            <param name="autoStart" value="false" />            <param name="guid" value="qERmmeTx2gY0XT1WWo+FaGbsiNjZv4Q+lmXQywXJ8UXLM4fSZY96ZH/ByrWbSoK8iAiXr9mzwGQsHz48urSakCU7FMnUIHKvzN/LTfBp86U8PMHf5Acl4FUEsJt9Uq1B6xr9LGAm/geHWQAUSEhAvbn1ZSCLUWbU1nDjueQqJGA=" />            <param name="wld_id" value="4463096" />            <param name="email_subject" value="Web site message from www.tedsmithlawgroup.com : Contact" />            <param name="domainName" value="www.tedsmithlawgroup.com" />            <param name="layoutBoxes" value="http://www.tedsmithlawgroup.com/content/css/video-v2-Bankruptcy/layoutBoxes.css" />            <param name="css" value="mediaControls=http://www.tedsmithlawgroup.com/content/css/video-v2-Bankruptcy/mediaControls.css&amp;videoList=http://www.tedsmithlawgroup.com/content/css/video-v2-Bankruptcy/videoList.css&amp;playlistCombo=http://www.tedsmithlawgroup.com/content/css/video-v2-Bankruptcy/playlistCombo.css" />        </object></div>', 'Bankruptcy', '', 'inherit', 'closed', 'closed', '', '96-revision-v1', '', '', '2016-05-20 18:59:30', '2016-05-20 18:59:30', '', 96, 'http://tedsmithdemo.com/96-revision-v1/', 0, 'revision', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(98, 1, '2016-05-20 19:00:21', '2016-05-20 19:00:21', '<h2><em>Representing Small Businesses in and around Bell County, TX</em></h2>\r\nFor over thirty-five years, Ted Smith has been helping businesses navigate the complex world of Texas business law. At the Ted Smith Law Group, your businesses needs will be addressed in an efficient and professional manner. Ted Smith has experience helping clients at the beginning of the entity formation process through the winding down of the entity. He has helped clients create all kinds of partnerships and every kind of corporation.\r\n<h2><em>Business Litigation Examples:</em></h2>\r\n<table border="1" cellspacing="5" cellpadding="2">\r\n<tbody>\r\n<tr>\r\n<td valign="top" width="250">Abuse of Executive Power</td>\r\n<td valign="top" width="250">Accounting Fraud</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Admissions</td>\r\n<td valign="top" width="250">Appeals</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Boundary Disputes</td>\r\n<td valign="top" width="250">Business Divorces</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Case Evaluation</td>\r\n<td valign="top" width="250">Commercial Collections</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Construction Defects</td>\r\n<td valign="top" width="250">Construction Litigation</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Contract Litigation</td>\r\n<td valign="top" width="250">Contractor/Subcontractor Disputes</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Control Disputes</td>\r\n<td valign="top" width="250">Copyright Infringement</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Corporate Embezzlement</td>\r\n<td valign="top" width="250">Corporate Litigation</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Counterclaims</td>\r\n<td valign="top" width="250">Default Judgments</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Delay Claims</td>\r\n<td valign="top" width="250">Depositions</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Derivative Actions</td>\r\n<td valign="top" width="250">Disputed Transactions</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Easement Disputes</td>\r\n<td valign="top" width="250">Failing to Disclose Defects</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Foreign Judgments</td>\r\n<td valign="top" width="250">Fraudulent Conveyances</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Improper Compensation</td>\r\n<td valign="top" width="250">Insider Trading</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Insurance Coverage Disputes</td>\r\n<td valign="top" width="250">Interrogatories</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Investment Fraud</td>\r\n<td valign="top" width="250">Investment Litigation</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Jurisdiction</td>\r\n<td valign="top" width="250">Mechanic\'s Liens</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Mediation</td>\r\n<td valign="top" width="250">Misrepresentation</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Motions for Summary Judgment</td>\r\n<td valign="top" width="250">Partition Actions</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Real Estate Litigation</td>\r\n<td valign="top" width="250">Removal to Federal Court</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Requests for Production</td>\r\n<td valign="top" width="250">Settlement</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Shareholder Litigation</td>\r\n<td valign="top" width="250">Stipulations</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Trade Names</td>\r\n<td valign="top" width="250">Trade Secret Litigation</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Venue</td>\r\n<td valign="top" width="250">Written Discovery</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<h2><em>Business Transactions:</em></h2>\r\n<table border="1" cellspacing="5" cellpadding="2">\r\n<tbody>\r\n<tr>\r\n<td valign="top" width="250">Asset Purchases</td>\r\n<td valign="top" width="250">Business Contracts</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Buying or Selling a Business</td>\r\n<td valign="top" width="250">Buy-Sell Agreements</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Closing a Business</td>\r\n<td valign="top" width="250">Complex Business Startups</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Covenants Not to Compete</td>\r\n<td valign="top" width="250">Financings</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Franchisees/Franchisors</td>\r\n<td valign="top" width="250">Limited Liability Companies</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Limited Liability Partnerships</td>\r\n<td valign="top" width="250">Limited Partnerships</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Mergers and Acquisitions</td>\r\n<td valign="top" width="250">Private Offerings</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Reorganizations</td>\r\n<td valign="top" width="250">S Corporations</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Shareholder Agreements</td>\r\n<td valign="top" width="250">Venture Capital Investments</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Controversial Litigation</td>\r\n<td valign="top" width="250">Business Torts</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Conspiracy Litigation</td>\r\n<td valign="top" width="250">Fiduciary Duty Litigation</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Fraud Litigation</td>\r\n<td valign="top" width="250">Tortious Interference Litigation</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Unfair Competition</td>\r\n<td valign="top" width="250"></td>\r\n</tr>\r\n</tbody>\r\n</table>\r\nThe Ted Smith Law Group has the experience to help you take your business to the next level. Don\'t make these very important decisions on your own, come in and let the Ted Smith Law Group help you do it right the first time.', 'Business Law', '', 'publish', 'closed', 'closed', '', 'business-law', '', '', '2016-05-20 19:00:21', '2016-05-20 19:00:21', '', 0, 'http://tedsmithdemo.com/?page_id=98', 0, 'page', '', 0),
(99, 1, '2016-05-20 19:00:21', '2016-05-20 19:00:21', '<h2><em>Representing Small Businesses in and around Bell County, TX</em></h2>\r\nFor over thirty-five years, Ted Smith has been helping businesses navigate the complex world of Texas business law. At the Ted Smith Law Group, your businesses needs will be addressed in an efficient and professional manner. Ted Smith has experience helping clients at the beginning of the entity formation process through the winding down of the entity. He has helped clients create all kinds of partnerships and every kind of corporation.\r\n<h2><em>Business Litigation Examples:</em></h2>\r\n<table border="1" cellspacing="5" cellpadding="2">\r\n<tbody>\r\n<tr>\r\n<td valign="top" width="250">Abuse of Executive Power</td>\r\n<td valign="top" width="250">Accounting Fraud</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Admissions</td>\r\n<td valign="top" width="250">Appeals</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Boundary Disputes</td>\r\n<td valign="top" width="250">Business Divorces</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Case Evaluation</td>\r\n<td valign="top" width="250">Commercial Collections</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Construction Defects</td>\r\n<td valign="top" width="250">Construction Litigation</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Contract Litigation</td>\r\n<td valign="top" width="250">Contractor/Subcontractor Disputes</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Control Disputes</td>\r\n<td valign="top" width="250">Copyright Infringement</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Corporate Embezzlement</td>\r\n<td valign="top" width="250">Corporate Litigation</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Counterclaims</td>\r\n<td valign="top" width="250">Default Judgments</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Delay Claims</td>\r\n<td valign="top" width="250">Depositions</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Derivative Actions</td>\r\n<td valign="top" width="250">Disputed Transactions</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Easement Disputes</td>\r\n<td valign="top" width="250">Failing to Disclose Defects</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Foreign Judgments</td>\r\n<td valign="top" width="250">Fraudulent Conveyances</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Improper Compensation</td>\r\n<td valign="top" width="250">Insider Trading</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Insurance Coverage Disputes</td>\r\n<td valign="top" width="250">Interrogatories</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Investment Fraud</td>\r\n<td valign="top" width="250">Investment Litigation</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Jurisdiction</td>\r\n<td valign="top" width="250">Mechanic\'s Liens</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Mediation</td>\r\n<td valign="top" width="250">Misrepresentation</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Motions for Summary Judgment</td>\r\n<td valign="top" width="250">Partition Actions</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Real Estate Litigation</td>\r\n<td valign="top" width="250">Removal to Federal Court</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Requests for Production</td>\r\n<td valign="top" width="250">Settlement</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Shareholder Litigation</td>\r\n<td valign="top" width="250">Stipulations</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Trade Names</td>\r\n<td valign="top" width="250">Trade Secret Litigation</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Venue</td>\r\n<td valign="top" width="250">Written Discovery</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<h2><em>Business Transactions:</em></h2>\r\n<table border="1" cellspacing="5" cellpadding="2">\r\n<tbody>\r\n<tr>\r\n<td valign="top" width="250">Asset Purchases</td>\r\n<td valign="top" width="250">Business Contracts</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Buying or Selling a Business</td>\r\n<td valign="top" width="250">Buy-Sell Agreements</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Closing a Business</td>\r\n<td valign="top" width="250">Complex Business Startups</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Covenants Not to Compete</td>\r\n<td valign="top" width="250">Financings</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Franchisees/Franchisors</td>\r\n<td valign="top" width="250">Limited Liability Companies</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Limited Liability Partnerships</td>\r\n<td valign="top" width="250">Limited Partnerships</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Mergers and Acquisitions</td>\r\n<td valign="top" width="250">Private Offerings</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Reorganizations</td>\r\n<td valign="top" width="250">S Corporations</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Shareholder Agreements</td>\r\n<td valign="top" width="250">Venture Capital Investments</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Controversial Litigation</td>\r\n<td valign="top" width="250">Business Torts</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Conspiracy Litigation</td>\r\n<td valign="top" width="250">Fiduciary Duty Litigation</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Fraud Litigation</td>\r\n<td valign="top" width="250">Tortious Interference Litigation</td>\r\n</tr>\r\n<tr>\r\n<td valign="top" width="250">Unfair Competition</td>\r\n<td valign="top" width="250"></td>\r\n</tr>\r\n</tbody>\r\n</table>\r\nThe Ted Smith Law Group has the experience to help you take your business to the next level. Don\'t make these very important decisions on your own, come in and let the Ted Smith Law Group help you do it right the first time.', 'Business Law', '', 'inherit', 'closed', 'closed', '', '98-revision-v1', '', '', '2016-05-20 19:00:21', '2016-05-20 19:00:21', '', 98, 'http://tedsmithdemo.com/98-revision-v1/', 0, 'revision', '', 0),
(100, 1, '2016-05-20 19:06:25', '2016-05-20 19:06:25', '<h2>Your \'Peace Of Mind\' Attorney For Important Immigration Matters</h2>\r\nWhen navigating the immigration system — either for yourself or on behalf of a loved one — there are many pitfalls that can derail your immigration-related aspirations. In order to avoid the potential issues that arise during the immigration process, or to keep these issues from delaying your application for months or years, you need the counsel of an experienced attorney.\r\n\r\nAt Ted Smith Law Group, we know how to guide clients through all varieties of immigration issues in a timely, cost-effective manner. When you retain our services, you obtain the peace of mind that comes from knowing your case is in the hands of insightful attorneys who will give you the personal attention you deserve. We recognize how important your case is to you, and will take the time to listen to all of your concerns, answer your questions, and provide you with the guidance you need to make well-informed decisions.\r\n<h2>Trusted Counsel For All Types Of Immigration Cases</h2>\r\nWith our help, clients in the Harker Heights-Killeen area have successfully navigated the immigration process and obtained the approval they need to meet their business, educational and family-related goals. Our services encompass immigration matters involving:\r\n<table border="0" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr>\r\n<td width="50%">\r\n<ul>\r\n 	<li>Citizenship</li>\r\n 	<li>Permanent Residence (Green Cards)</li>\r\n 	<li>Immigration waivers</li>\r\n 	<li>Business visas</li>\r\n 	<li class="last-child">Student visas</li>\r\n</ul>\r\n</td>\r\n<td width="50%">\r\n<ul>\r\n 	<li>Investment visas</li>\r\n 	<li>Fiancé/fiancée visas</li>\r\n 	<li>Immigration appeals</li>\r\n 	<li>Asylum</li>\r\n 	<li>Naturalization</li>\r\n 	<li class="last-child">Military Citizenship</li>\r\n</ul>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\nWhen a case involves these or any similar issues, we draw on the skills and knowledge that have led to a long history of success to provide effective representation to clients throughout Texas.\r\n<h2>Get The Trusted Advice You Need | Free Attorney Consultation</h2>\r\nCall our conveniently located office at 254-690-5688 to schedule a <a href="/contact/" target="_self">free initial consultation</a> with our immigration lawyers.', 'Immigration', '', 'publish', 'closed', 'closed', '', 'immigration', '', '', '2016-05-20 19:06:25', '2016-05-20 19:06:25', '', 0, 'http://tedsmithdemo.com/?page_id=100', 0, 'page', '', 0),
(101, 1, '2016-05-20 19:06:25', '2016-05-20 19:06:25', '<h2>Your \'Peace Of Mind\' Attorney For Important Immigration Matters</h2>\r\nWhen navigating the immigration system — either for yourself or on behalf of a loved one — there are many pitfalls that can derail your immigration-related aspirations. In order to avoid the potential issues that arise during the immigration process, or to keep these issues from delaying your application for months or years, you need the counsel of an experienced attorney.\r\n\r\nAt Ted Smith Law Group, we know how to guide clients through all varieties of immigration issues in a timely, cost-effective manner. When you retain our services, you obtain the peace of mind that comes from knowing your case is in the hands of insightful attorneys who will give you the personal attention you deserve. We recognize how important your case is to you, and will take the time to listen to all of your concerns, answer your questions, and provide you with the guidance you need to make well-informed decisions.\r\n<h2>Trusted Counsel For All Types Of Immigration Cases</h2>\r\nWith our help, clients in the Harker Heights-Killeen area have successfully navigated the immigration process and obtained the approval they need to meet their business, educational and family-related goals. Our services encompass immigration matters involving:\r\n<table border="0" cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr>\r\n<td width="50%">\r\n<ul>\r\n 	<li>Citizenship</li>\r\n 	<li>Permanent Residence (Green Cards)</li>\r\n 	<li>Immigration waivers</li>\r\n 	<li>Business visas</li>\r\n 	<li class="last-child">Student visas</li>\r\n</ul>\r\n</td>\r\n<td width="50%">\r\n<ul>\r\n 	<li>Investment visas</li>\r\n 	<li>Fiancé/fiancée visas</li>\r\n 	<li>Immigration appeals</li>\r\n 	<li>Asylum</li>\r\n 	<li>Naturalization</li>\r\n 	<li class="last-child">Military Citizenship</li>\r\n</ul>\r\n</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\nWhen a case involves these or any similar issues, we draw on the skills and knowledge that have led to a long history of success to provide effective representation to clients throughout Texas.\r\n<h2>Get The Trusted Advice You Need | Free Attorney Consultation</h2>\r\nCall our conveniently located office at 254-690-5688 to schedule a <a href="/contact/" target="_self">free initial consultation</a> with our immigration lawyers.', 'Immigration', '', 'inherit', 'closed', 'closed', '', '100-revision-v1', '', '', '2016-05-20 19:06:25', '2016-05-20 19:06:25', '', 100, 'http://tedsmithdemo.com/100-revision-v1/', 0, 'revision', '', 0),
(102, 1, '2016-05-20 19:07:10', '2016-05-20 19:07:10', 'Ted Smith has been assisting people with their litigation needs for over thirty-five years. Ted has been involved in every aspect of the litigation process, and has represented clients from all walks of life against every type of adversary. Because of Ted\'s tenure practicing law, the Ted Smith Law Group has the connections and the resources to handle your case. Whether it be a suit against your landlord or against your tenant, a suit for a breach of contract, a probate dispute, a fight over property, or any other type of litigation; call the Ted Smith Law Group, PLLC, and we will get right to work protecting your rights.', 'General Civil Practice', '', 'publish', 'closed', 'closed', '', 'general-civil-practice', '', '', '2016-05-20 19:07:10', '2016-05-20 19:07:10', '', 0, 'http://tedsmithdemo.com/?page_id=102', 0, 'page', '', 0),
(103, 1, '2016-05-20 19:07:10', '2016-05-20 19:07:10', 'Ted Smith has been assisting people with their litigation needs for over thirty-five years. Ted has been involved in every aspect of the litigation process, and has represented clients from all walks of life against every type of adversary. Because of Ted\'s tenure practicing law, the Ted Smith Law Group has the connections and the resources to handle your case. Whether it be a suit against your landlord or against your tenant, a suit for a breach of contract, a probate dispute, a fight over property, or any other type of litigation; call the Ted Smith Law Group, PLLC, and we will get right to work protecting your rights.', 'General Civil Practice', '', 'inherit', 'closed', 'closed', '', '102-revision-v1', '', '', '2016-05-20 19:07:10', '2016-05-20 19:07:10', '', 102, 'http://tedsmithdemo.com/102-revision-v1/', 0, 'revision', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(104, 1, '2016-05-20 19:08:49', '2016-05-20 19:08:49', '<strong>Ted Smith Law Group, PLLC</strong>\r\n660 West FM 2410\r\nHarker Heights, TX 76548\r\nPhone: 254-690-5688\r\nFax: 254-690-5685\r\n<a href="http://maps.google.com/maps?f=q&amp;hl=en&amp;geocode=&amp;q=660%20West%20FM%202410%20Harker%20Heights%2C%20TX%2076548%20US" target="_blank">Map and Directions</a>', 'Contact', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2016-05-20 19:08:49', '2016-05-20 19:08:49', '', 0, 'http://tedsmithdemo.com/?page_id=104', 0, 'page', '', 0),
(105, 1, '2016-05-20 19:08:49', '2016-05-20 19:08:49', '<strong>Ted Smith Law Group, PLLC</strong>\r\n660 West FM 2410\r\nHarker Heights, TX 76548\r\nPhone: 254-690-5688\r\nFax: 254-690-5685\r\n<a href="http://maps.google.com/maps?f=q&amp;hl=en&amp;geocode=&amp;q=660%20West%20FM%202410%20Harker%20Heights%2C%20TX%2076548%20US" target="_blank">Map and Directions</a>', 'Contact', '', 'inherit', 'closed', 'closed', '', '104-revision-v1', '', '', '2016-05-20 19:08:49', '2016-05-20 19:08:49', '', 104, 'http://tedsmithdemo.com/104-revision-v1/', 0, 'revision', '', 0),
(106, 1, '2016-05-20 19:09:30', '2016-05-20 19:09:30', '<div class="review-page-wrap">\r\n<h2>We value your feedback</h2>\r\n<h3>If you liked our service please tell others about your experience</h3>\r\n<div class="yelp-review review-single"><img src="/images/yelp_logo.png" alt="" />\r\n<a class="rev" href="#" target="_blank">Click here to review us on Yelp</a></div>\r\n\r\n<div class="google-review review-single"><img src="/images/google_logo.png" alt="" />\r\n<a class="rev" href="#" target="_blank">Click here to review us on Google</a></div>\r\n\r\n<div class="google-review review-single last-review"><img src="/images/facebook_logo.png" alt="" />\r\n<a class="rev" href="#" target="_blank">Click here to review us on Facebook</a></div>\r\n\r\n<div style="clear: both;"></div>\r\n<h3 class="video-watch">Watch this video on how to write a review on google</h3>\r\n<div id="wistia_uptwyj8l7a" class="wistia_embed" style="width:760px;height:428px;"><div itemprop="video" itemscope itemtype="http://schema.org/VideoObject"><meta itemprop="name" content="Review 2013" /><meta itemprop="duration" content="PT50S" /><meta itemprop="thumbnailUrl" content="https://embed-ssl.wistia.com/deliveries/c378b5118f36ecc9c05b37bb4e1050e545051864.bin" /><meta itemprop="contentURL" content="https://embed-ssl.wistia.com/deliveries/d17ff98f4145b4fd94a194096a0b9970bc4bfcf8.bin" /><meta itemprop="embedURL" content="https://embed-ssl.wistia.com/flash/embed_player_v2.0.swf?2015-02-27&controlsVisibleOnLoad=true&customColor=7b796a&fullscreenDisabled=true&hdUrl%5B2pass%5D=true&hdUrl%5Bext%5D=flv&hdUrl%5Bheight%5D=720&hdUrl%5Bsize%5D=2505626&hdUrl%5Btype%5D=hdflv&hdUrl%5Burl%5D=https%3A%2F%2Fembed-ssl.wistia.com%2Fdeliveries%2Fd17ff98f4145b4fd94a194096a0b9970bc4bfcf8.bin&hdUrl%5Bwidth%5D=1280&mediaDuration=50.802&showVolume=true&stillUrl=https%3A%2F%2Fembed-ssl.wistia.com%2Fdeliveries%2Fc378b5118f36ecc9c05b37bb4e1050e545051864.bin%3Fimage_crop_resized%3D760x428&unbufferedSeek=true&videoUrl=https%3A%2F%2Fembed-ssl.wistia.com%2Fdeliveries%2Fd17ff98f4145b4fd94a194096a0b9970bc4bfcf8.bin" /><meta itemprop="uploadDate" content="2013-11-22T19:36:37Z" /><object id="wistia_uptwyj8l7a_seo" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" style="display:block;height:428px;position:relative;width:760px;"><param name="movie" value="https://embed-ssl.wistia.com/flash/embed_player_v2.0.swf?2015-02-27"></param><param name="allowfullscreen" value="true"></param><param name="bgcolor" value="#000000"></param><param name="wmode" value="opaque"></param><param name="flashvars" value="controlsVisibleOnLoad=true&customColor=7b796a&fullscreenDisabled=true&hdUrl%5B2pass%5D=true&hdUrl%5Bext%5D=flv&hdUrl%5Bheight%5D=720&hdUrl%5Bsize%5D=2505626&hdUrl%5Btype%5D=hdflv&hdUrl%5Burl%5D=https%3A%2F%2Fembed-ssl.wistia.com%2Fdeliveries%2Fd17ff98f4145b4fd94a194096a0b9970bc4bfcf8.bin&hdUrl%5Bwidth%5D=1280&mediaDuration=50.802&showVolume=true&stillUrl=https%3A%2F%2Fembed-ssl.wistia.com%2Fdeliveries%2Fc378b5118f36ecc9c05b37bb4e1050e545051864.bin%3Fimage_crop_resized%3D760x428&unbufferedSeek=true&videoUrl=https%3A%2F%2Fembed-ssl.wistia.com%2Fdeliveries%2Fd17ff98f4145b4fd94a194096a0b9970bc4bfcf8.bin"></param><embed src="https://embed-ssl.wistia.com/flash/embed_player_v2.0.swf?2015-02-27" allowfullscreen="true" bgcolor=#000000 flashvars="controlsVisibleOnLoad=true&customColor=7b796a&fullscreenDisabled=true&hdUrl%5B2pass%5D=true&hdUrl%5Bext%5D=flv&hdUrl%5Bheight%5D=720&hdUrl%5Bsize%5D=2505626&hdUrl%5Btype%5D=hdflv&hdUrl%5Burl%5D=https%3A%2F%2Fembed-ssl.wistia.com%2Fdeliveries%2Fd17ff98f4145b4fd94a194096a0b9970bc4bfcf8.bin&hdUrl%5Bwidth%5D=1280&mediaDuration=50.802&showVolume=true&stillUrl=https%3A%2F%2Fembed-ssl.wistia.com%2Fdeliveries%2Fc378b5118f36ecc9c05b37bb4e1050e545051864.bin%3Fimage_crop_resized%3D760x428&unbufferedSeek=true&videoUrl=https%3A%2F%2Fembed-ssl.wistia.com%2Fdeliveries%2Fd17ff98f4145b4fd94a194096a0b9970bc4bfcf8.bin" name="wistia_uptwyj8l7a_html" style="display:block;height:100%;position:relative;width:100%;" type="application/x-shockwave-flash" wmode="opaque"></embed></object><noscript itemprop="description">Review 2013</noscript></div></div>\r\n<script charset="ISO-8859-1" src="//fast.wistia.com/assets/external/E-v1.js"></script>\r\n<script>\r\nwistiaEmbed = Wistia.embed("uptwyj8l7a", {\r\n  videoFoam: true\r\n});\r\n</script>\r\n<script charset="ISO-8859-1" src="//fast.wistia.com/embed/medias/uptwyj8l7a/metadata.js"></script>\r\n\r\n</div>', 'Reviews', '', 'publish', 'closed', 'closed', '', 'reviews', '', '', '2016-05-20 19:09:30', '2016-05-20 19:09:30', '', 0, 'http://tedsmithdemo.com/?page_id=106', 0, 'page', '', 0),
(107, 1, '2016-05-20 19:09:30', '2016-05-20 19:09:30', '<div class="review-page-wrap">\r\n<h2>We value your feedback</h2>\r\n<h3>If you liked our service please tell others about your experience</h3>\r\n<div class="yelp-review review-single"><img src="/images/yelp_logo.png" alt="" />\r\n<a class="rev" href="#" target="_blank">Click here to review us on Yelp</a></div>\r\n\r\n<div class="google-review review-single"><img src="/images/google_logo.png" alt="" />\r\n<a class="rev" href="#" target="_blank">Click here to review us on Google</a></div>\r\n\r\n<div class="google-review review-single last-review"><img src="/images/facebook_logo.png" alt="" />\r\n<a class="rev" href="#" target="_blank">Click here to review us on Facebook</a></div>\r\n\r\n<div style="clear: both;"></div>\r\n<h3 class="video-watch">Watch this video on how to write a review on google</h3>\r\n<div id="wistia_uptwyj8l7a" class="wistia_embed" style="width:760px;height:428px;"><div itemprop="video" itemscope itemtype="http://schema.org/VideoObject"><meta itemprop="name" content="Review 2013" /><meta itemprop="duration" content="PT50S" /><meta itemprop="thumbnailUrl" content="https://embed-ssl.wistia.com/deliveries/c378b5118f36ecc9c05b37bb4e1050e545051864.bin" /><meta itemprop="contentURL" content="https://embed-ssl.wistia.com/deliveries/d17ff98f4145b4fd94a194096a0b9970bc4bfcf8.bin" /><meta itemprop="embedURL" content="https://embed-ssl.wistia.com/flash/embed_player_v2.0.swf?2015-02-27&controlsVisibleOnLoad=true&customColor=7b796a&fullscreenDisabled=true&hdUrl%5B2pass%5D=true&hdUrl%5Bext%5D=flv&hdUrl%5Bheight%5D=720&hdUrl%5Bsize%5D=2505626&hdUrl%5Btype%5D=hdflv&hdUrl%5Burl%5D=https%3A%2F%2Fembed-ssl.wistia.com%2Fdeliveries%2Fd17ff98f4145b4fd94a194096a0b9970bc4bfcf8.bin&hdUrl%5Bwidth%5D=1280&mediaDuration=50.802&showVolume=true&stillUrl=https%3A%2F%2Fembed-ssl.wistia.com%2Fdeliveries%2Fc378b5118f36ecc9c05b37bb4e1050e545051864.bin%3Fimage_crop_resized%3D760x428&unbufferedSeek=true&videoUrl=https%3A%2F%2Fembed-ssl.wistia.com%2Fdeliveries%2Fd17ff98f4145b4fd94a194096a0b9970bc4bfcf8.bin" /><meta itemprop="uploadDate" content="2013-11-22T19:36:37Z" /><object id="wistia_uptwyj8l7a_seo" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" style="display:block;height:428px;position:relative;width:760px;"><param name="movie" value="https://embed-ssl.wistia.com/flash/embed_player_v2.0.swf?2015-02-27"></param><param name="allowfullscreen" value="true"></param><param name="bgcolor" value="#000000"></param><param name="wmode" value="opaque"></param><param name="flashvars" value="controlsVisibleOnLoad=true&customColor=7b796a&fullscreenDisabled=true&hdUrl%5B2pass%5D=true&hdUrl%5Bext%5D=flv&hdUrl%5Bheight%5D=720&hdUrl%5Bsize%5D=2505626&hdUrl%5Btype%5D=hdflv&hdUrl%5Burl%5D=https%3A%2F%2Fembed-ssl.wistia.com%2Fdeliveries%2Fd17ff98f4145b4fd94a194096a0b9970bc4bfcf8.bin&hdUrl%5Bwidth%5D=1280&mediaDuration=50.802&showVolume=true&stillUrl=https%3A%2F%2Fembed-ssl.wistia.com%2Fdeliveries%2Fc378b5118f36ecc9c05b37bb4e1050e545051864.bin%3Fimage_crop_resized%3D760x428&unbufferedSeek=true&videoUrl=https%3A%2F%2Fembed-ssl.wistia.com%2Fdeliveries%2Fd17ff98f4145b4fd94a194096a0b9970bc4bfcf8.bin"></param><embed src="https://embed-ssl.wistia.com/flash/embed_player_v2.0.swf?2015-02-27" allowfullscreen="true" bgcolor=#000000 flashvars="controlsVisibleOnLoad=true&customColor=7b796a&fullscreenDisabled=true&hdUrl%5B2pass%5D=true&hdUrl%5Bext%5D=flv&hdUrl%5Bheight%5D=720&hdUrl%5Bsize%5D=2505626&hdUrl%5Btype%5D=hdflv&hdUrl%5Burl%5D=https%3A%2F%2Fembed-ssl.wistia.com%2Fdeliveries%2Fd17ff98f4145b4fd94a194096a0b9970bc4bfcf8.bin&hdUrl%5Bwidth%5D=1280&mediaDuration=50.802&showVolume=true&stillUrl=https%3A%2F%2Fembed-ssl.wistia.com%2Fdeliveries%2Fc378b5118f36ecc9c05b37bb4e1050e545051864.bin%3Fimage_crop_resized%3D760x428&unbufferedSeek=true&videoUrl=https%3A%2F%2Fembed-ssl.wistia.com%2Fdeliveries%2Fd17ff98f4145b4fd94a194096a0b9970bc4bfcf8.bin" name="wistia_uptwyj8l7a_html" style="display:block;height:100%;position:relative;width:100%;" type="application/x-shockwave-flash" wmode="opaque"></embed></object><noscript itemprop="description">Review 2013</noscript></div></div>\r\n<script charset="ISO-8859-1" src="//fast.wistia.com/assets/external/E-v1.js"></script>\r\n<script>\r\nwistiaEmbed = Wistia.embed("uptwyj8l7a", {\r\n  videoFoam: true\r\n});\r\n</script>\r\n<script charset="ISO-8859-1" src="//fast.wistia.com/embed/medias/uptwyj8l7a/metadata.js"></script>\r\n\r\n</div>', 'Reviews', '', 'inherit', 'closed', 'closed', '', '106-revision-v1', '', '', '2016-05-20 19:09:30', '2016-05-20 19:09:30', '', 106, 'http://tedsmithdemo.com/106-revision-v1/', 0, 'revision', '', 0),
(108, 1, '2016-05-20 19:10:48', '2016-05-20 19:10:48', '<h2>Integrity, Strength, Results — Not Just Words At Ted Smith Law Group</h2>\r\nOur Texas attorneys strive to provide you the best legal services available. Their knowledge, work ethic and high level of professionalism allow you to put your trust in our team as we address any legal issues that concern you. We have the resources and skill necessary to address <a href="/personal-injury/">personal injury</a> claims, family law disputes, criminal defense cases, real estate matters and everything in between.\r\n\r\nTed Smith has more than 40 years of legal experience, and he wants that experience to benefit you. Jeremy Brewer, Elizabeth Shehan bring to your team a willingness to provide you with an energetic approach to solving your legal difficulties.\r\n<p class="callOut">"I love how they give back to the community and really go above and beyond to make sure their clients are entirely taken care of. I am a huge fan of that. Very happy with working with them." — Client Ryan Anderson (June 2013)</p>\r\nLearn more about our legal team by clicking on the profile links below.\r\n<ul>\r\n 	<li class="itemFirst">Ted Smith</li>\r\n 	<li>Grace A. Wilhem</li>\r\n 	<li>Richard Lee King</li>\r\n 	<li class="itemLast last-child">Nicholas R. Smith</li>\r\n</ul>\r\nOur Harker Heights area lawyers are ready to be your advocates and guides on whatever legal roads you might be facing. <a href="/contact/" target="_self">Contact us</a> today and put them to work for you — call 254-690-5688 or contact us online.', 'Attorneys', '', 'publish', 'closed', 'closed', '', 'attorneys', '', '', '2016-05-20 19:10:48', '2016-05-20 19:10:48', '', 0, 'http://tedsmithdemo.com/?page_id=108', 0, 'page', '', 0),
(109, 1, '2016-05-20 19:10:48', '2016-05-20 19:10:48', '<h2>Integrity, Strength, Results — Not Just Words At Ted Smith Law Group</h2>\r\nOur Texas attorneys strive to provide you the best legal services available. Their knowledge, work ethic and high level of professionalism allow you to put your trust in our team as we address any legal issues that concern you. We have the resources and skill necessary to address <a href="/personal-injury/">personal injury</a> claims, family law disputes, criminal defense cases, real estate matters and everything in between.\r\n\r\nTed Smith has more than 40 years of legal experience, and he wants that experience to benefit you. Jeremy Brewer, Elizabeth Shehan bring to your team a willingness to provide you with an energetic approach to solving your legal difficulties.\r\n<p class="callOut">"I love how they give back to the community and really go above and beyond to make sure their clients are entirely taken care of. I am a huge fan of that. Very happy with working with them." — Client Ryan Anderson (June 2013)</p>\r\nLearn more about our legal team by clicking on the profile links below.\r\n<ul>\r\n 	<li class="itemFirst">Ted Smith</li>\r\n 	<li>Grace A. Wilhem</li>\r\n 	<li>Richard Lee King</li>\r\n 	<li class="itemLast last-child">Nicholas R. Smith</li>\r\n</ul>\r\nOur Harker Heights area lawyers are ready to be your advocates and guides on whatever legal roads you might be facing. <a href="/contact/" target="_self">Contact us</a> today and put them to work for you — call 254-690-5688 or contact us online.', 'Attorneys', '', 'inherit', 'closed', 'closed', '', '108-revision-v1', '', '', '2016-05-20 19:10:48', '2016-05-20 19:10:48', '', 108, 'http://tedsmithdemo.com/108-revision-v1/', 0, 'revision', '', 0),
(110, 1, '2016-05-20 19:14:11', '2016-05-20 19:14:11', ' ', '', '', 'publish', 'closed', 'closed', '', '110', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 0, 'http://tedsmithdemo.com/?p=110', 1, 'nav_menu_item', '', 0),
(111, 1, '2016-05-20 19:14:11', '2016-05-20 19:14:11', ' ', '', '', 'publish', 'closed', 'closed', '', '111', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 0, 'http://tedsmithdemo.com/?p=111', 2, 'nav_menu_item', '', 0),
(112, 1, '2016-05-20 19:14:11', '2016-05-20 19:14:11', ' ', '', '', 'publish', 'closed', 'closed', '', '112', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 0, 'http://tedsmithdemo.com/?p=112', 3, 'nav_menu_item', '', 0),
(113, 1, '2016-05-20 19:14:11', '2016-05-20 19:14:11', ' ', '', '', 'publish', 'closed', 'closed', '', '113', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 0, 'http://tedsmithdemo.com/?p=113', 4, 'nav_menu_item', '', 0),
(114, 1, '2016-05-20 19:14:11', '2016-05-20 19:14:11', ' ', '', '', 'publish', 'closed', 'closed', '', '114', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 0, 'http://tedsmithdemo.com/?p=114', 5, 'nav_menu_item', '', 0),
(115, 1, '2016-05-20 19:14:12', '2016-05-20 19:14:12', ' ', '', '', 'publish', 'closed', 'closed', '', '115', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 75, 'http://tedsmithdemo.com/?p=115', 6, 'nav_menu_item', '', 0),
(116, 1, '2016-05-20 19:14:12', '2016-05-20 19:14:12', ' ', '', '', 'publish', 'closed', 'closed', '', '116', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 75, 'http://tedsmithdemo.com/?p=116', 7, 'nav_menu_item', '', 0),
(117, 1, '2016-05-20 19:14:12', '2016-05-20 19:14:12', ' ', '', '', 'publish', 'closed', 'closed', '', '117', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 75, 'http://tedsmithdemo.com/?p=117', 8, 'nav_menu_item', '', 0),
(118, 1, '2016-05-20 19:14:12', '2016-05-20 19:14:12', ' ', '', '', 'publish', 'closed', 'closed', '', '118', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 0, 'http://tedsmithdemo.com/?p=118', 9, 'nav_menu_item', '', 0),
(119, 1, '2016-05-20 19:14:12', '2016-05-20 19:14:12', ' ', '', '', 'publish', 'closed', 'closed', '', '119', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 4, 'http://tedsmithdemo.com/?p=119', 10, 'nav_menu_item', '', 0),
(120, 1, '2016-05-20 19:14:12', '2016-05-20 19:14:12', ' ', '', '', 'publish', 'closed', 'closed', '', '120', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 4, 'http://tedsmithdemo.com/?p=120', 11, 'nav_menu_item', '', 0),
(121, 1, '2016-05-20 19:14:12', '2016-05-20 19:14:12', ' ', '', '', 'publish', 'closed', 'closed', '', '121', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 4, 'http://tedsmithdemo.com/?p=121', 12, 'nav_menu_item', '', 0),
(122, 1, '2016-05-20 19:14:12', '2016-05-20 19:14:12', ' ', '', '', 'publish', 'closed', 'closed', '', '122', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 4, 'http://tedsmithdemo.com/?p=122', 13, 'nav_menu_item', '', 0),
(123, 1, '2016-05-20 19:14:12', '2016-05-20 19:14:12', ' ', '', '', 'publish', 'closed', 'closed', '', '123', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 4, 'http://tedsmithdemo.com/?p=123', 14, 'nav_menu_item', '', 0),
(124, 1, '2016-05-20 19:14:12', '2016-05-20 19:14:12', ' ', '', '', 'publish', 'closed', 'closed', '', '124', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 4, 'http://tedsmithdemo.com/?p=124', 15, 'nav_menu_item', '', 0),
(125, 1, '2016-05-20 19:14:12', '2016-05-20 19:14:12', '', 'Fathers\' Rights', '', 'publish', 'closed', 'closed', '', 'fathers-rights', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 4, 'http://tedsmithdemo.com/?p=125', 16, 'nav_menu_item', '', 0),
(126, 1, '2016-05-20 19:14:12', '2016-05-20 19:14:12', ' ', '', '', 'publish', 'closed', 'closed', '', '126', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 4, 'http://tedsmithdemo.com/?p=126', 17, 'nav_menu_item', '', 0),
(127, 1, '2016-05-20 19:14:12', '2016-05-20 19:14:12', ' ', '', '', 'publish', 'closed', 'closed', '', '127', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 4, 'http://tedsmithdemo.com/?p=127', 18, 'nav_menu_item', '', 0),
(128, 1, '2016-05-20 19:14:12', '2016-05-20 19:14:12', ' ', '', '', 'publish', 'closed', 'closed', '', '128', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 4, 'http://tedsmithdemo.com/?p=128', 19, 'nav_menu_item', '', 0),
(129, 1, '2016-05-20 19:14:12', '2016-05-20 19:14:12', ' ', '', '', 'publish', 'closed', 'closed', '', '129', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 4, 'http://tedsmithdemo.com/?p=129', 20, 'nav_menu_item', '', 0),
(130, 1, '2016-05-20 19:14:12', '2016-05-20 19:14:12', ' ', '', '', 'publish', 'closed', 'closed', '', '130', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 4, 'http://tedsmithdemo.com/?p=130', 21, 'nav_menu_item', '', 0),
(131, 1, '2016-05-20 19:14:12', '2016-05-20 19:14:12', ' ', '', '', 'publish', 'closed', 'closed', '', '131', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 0, 'http://tedsmithdemo.com/?p=131', 22, 'nav_menu_item', '', 0),
(133, 1, '2016-05-20 19:14:12', '2016-05-20 19:14:12', ' ', '', '', 'publish', 'closed', 'closed', '', '133', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 0, 'http://tedsmithdemo.com/?p=133', 39, 'nav_menu_item', '', 0),
(137, 1, '2016-05-20 19:14:12', '2016-05-20 19:14:12', ' ', '', '', 'publish', 'closed', 'closed', '', '137', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 0, 'http://tedsmithdemo.com/?p=137', 23, 'nav_menu_item', '', 0),
(139, 1, '2016-05-20 19:14:12', '2016-05-20 19:14:12', ' ', '', '', 'publish', 'closed', 'closed', '', '139', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 0, 'http://tedsmithdemo.com/?p=139', 24, 'nav_menu_item', '', 0),
(140, 1, '2016-05-20 19:14:12', '2016-05-20 19:14:12', ' ', '', '', 'publish', 'closed', 'closed', '', '140', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 31, 'http://tedsmithdemo.com/?p=140', 25, 'nav_menu_item', '', 0),
(141, 1, '2016-05-20 19:14:12', '2016-05-20 19:14:12', ' ', '', '', 'publish', 'closed', 'closed', '', '141', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 31, 'http://tedsmithdemo.com/?p=141', 26, 'nav_menu_item', '', 0),
(142, 1, '2016-05-20 19:14:12', '2016-05-20 19:14:12', ' ', '', '', 'publish', 'closed', 'closed', '', '142', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 31, 'http://tedsmithdemo.com/?p=142', 27, 'nav_menu_item', '', 0),
(143, 1, '2016-05-20 19:14:12', '2016-05-20 19:14:12', ' ', '', '', 'publish', 'closed', 'closed', '', '143', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 31, 'http://tedsmithdemo.com/?p=143', 28, 'nav_menu_item', '', 0),
(144, 1, '2016-05-20 19:14:12', '2016-05-20 19:14:12', ' ', '', '', 'publish', 'closed', 'closed', '', '144', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 31, 'http://tedsmithdemo.com/?p=144', 29, 'nav_menu_item', '', 0),
(145, 1, '2016-05-20 19:14:12', '2016-05-20 19:14:12', ' ', '', '', 'publish', 'closed', 'closed', '', '145', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 31, 'http://tedsmithdemo.com/?p=145', 30, 'nav_menu_item', '', 0),
(146, 1, '2016-05-20 19:14:12', '2016-05-20 19:14:12', ' ', '', '', 'publish', 'closed', 'closed', '', '146', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 31, 'http://tedsmithdemo.com/?p=146', 31, 'nav_menu_item', '', 0),
(147, 1, '2016-05-20 19:14:12', '2016-05-20 19:14:12', ' ', '', '', 'publish', 'closed', 'closed', '', '147', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 31, 'http://tedsmithdemo.com/?p=147', 32, 'nav_menu_item', '', 0),
(148, 1, '2016-05-20 19:14:12', '2016-05-20 19:14:12', ' ', '', '', 'publish', 'closed', 'closed', '', '148', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 31, 'http://tedsmithdemo.com/?p=148', 33, 'nav_menu_item', '', 0),
(149, 1, '2016-05-20 19:14:12', '2016-05-20 19:14:12', ' ', '', '', 'publish', 'closed', 'closed', '', '149', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 31, 'http://tedsmithdemo.com/?p=149', 34, 'nav_menu_item', '', 0),
(150, 1, '2016-05-20 19:14:12', '2016-05-20 19:14:12', ' ', '', '', 'publish', 'closed', 'closed', '', '150', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 31, 'http://tedsmithdemo.com/?p=150', 35, 'nav_menu_item', '', 0),
(151, 1, '2016-05-20 19:14:12', '2016-05-20 19:14:12', ' ', '', '', 'publish', 'closed', 'closed', '', '151', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 0, 'http://tedsmithdemo.com/?p=151', 36, 'nav_menu_item', '', 0),
(152, 1, '2016-05-20 19:14:12', '2016-05-20 19:14:12', ' ', '', '', 'publish', 'closed', 'closed', '', '152', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 0, 'http://tedsmithdemo.com/?p=152', 41, 'nav_menu_item', '', 0),
(153, 1, '2016-05-20 19:14:12', '2016-05-20 19:14:12', ' ', '', '', 'publish', 'closed', 'closed', '', '153', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 63, 'http://tedsmithdemo.com/?p=153', 42, 'nav_menu_item', '', 0),
(154, 1, '2016-05-20 19:14:12', '2016-05-20 19:14:12', ' ', '', '', 'publish', 'closed', 'closed', '', '154', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 63, 'http://tedsmithdemo.com/?p=154', 43, 'nav_menu_item', '', 0),
(155, 1, '2016-05-20 19:14:12', '2016-05-20 19:14:12', ' ', '', '', 'publish', 'closed', 'closed', '', '155', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 63, 'http://tedsmithdemo.com/?p=155', 44, 'nav_menu_item', '', 0),
(156, 1, '2016-05-20 19:14:12', '2016-05-20 19:14:12', ' ', '', '', 'publish', 'closed', 'closed', '', '156', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 63, 'http://tedsmithdemo.com/?p=156', 45, 'nav_menu_item', '', 0),
(157, 1, '2016-05-20 19:14:12', '2016-05-20 19:14:12', ' ', '', '', 'publish', 'closed', 'closed', '', '157', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 63, 'http://tedsmithdemo.com/?p=157', 46, 'nav_menu_item', '', 0),
(158, 1, '2016-05-20 19:14:12', '2016-05-20 19:14:12', ' ', '', '', 'publish', 'closed', 'closed', '', '158', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 0, 'http://tedsmithdemo.com/?p=158', 40, 'nav_menu_item', '', 0),
(159, 1, '2016-05-20 19:14:12', '2016-05-20 19:14:12', ' ', '', '', 'publish', 'closed', 'closed', '', '159', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 31, 'http://tedsmithdemo.com/?p=159', 37, 'nav_menu_item', '', 0),
(160, 1, '2016-05-20 19:14:12', '2016-05-20 19:14:12', ' ', '', '', 'publish', 'closed', 'closed', '', '160', '', '', '2016-05-20 19:14:28', '2016-05-20 19:14:28', '', 31, 'http://tedsmithdemo.com/?p=160', 38, 'nav_menu_item', '', 0),
(161, 1, '2016-05-20 19:15:55', '2016-05-20 19:15:55', '<h2>Senior Partner</h2>\r\nLocation:\r\nHarker Heights, Texas\r\nPhone:\r\n254-690-5688\r\nFax:\r\n254-690-5685\r\n\r\nCentral Texans have been represented by Ted Smith for the past 39 years. Ted was an active duty JAG officer at Fort Hood before he opened his first private practice in Killeen in 1976. Since then he has represented thousands of Central Texans by providing solutions to their legal needs. From assisting with the purchase or sale of their family home to assisting them recover for the wrongful death of a loved one, Ted has been there offering his legal expertise at affordable rates. Ted is a fixture in the Central Texas community. He has served as city attorney for Harker Heights; been elected to the Harker Heights City Council; served as chairman of the Harker Heights Chamber of Commerce, the Metroplex Hospital Foundation, and the Killeen Food Care Center Board of Directors. He is serving or has served on the Viva Les Artes Society Board of Directors, the Youth Services Bureau, Killeen and Harker Heights Rotary clubs, and Young Life.\r\n<h2>Areas of Practice</h2>\r\nSocial Security Disability\r\nReal Estate &amp; Consumer Litigation\r\nBusiness Litigation\r\nReal Estate Transactions\r\nBusiness Formation\r\nEstate Planning &amp; Probate\r\nGeneral Business Practice\r\nCertified Legal Specialties\r\n\r\nBoard Certified in Residential and Commercial Real Estate Law, Texas Board of Legal Specialization, 1983\r\nCertified Mediator including advanced training for family matters\r\n<h2>Bar Admissions</h2>\r\nSupreme Court of Indiana, 1973\r\nSupreme Court of Texas, 1975\r\nU.S. District Court Southern District of Indiana, 1973\r\nU. S. Court of Military Appeals, 1973\r\nU.S. District Court Western District of Texas, 1984\r\n<h2>Education</h2>\r\nIndiana University School of Law, Indianapolis, Indiana\r\nJ.D. - 1973\r\nIndiana University\r\nA.B. - 1970\r\nMajor: Zoology and Radio &amp; TV\r\nU.S. Army Judge Advocate General School - 1973\r\n<h2>Honors and Awards</h2>\r\nArmy Commendation Medal\r\nDistinguished Military Attorney\r\nPresidential Citation, State Bar of Texas\r\nLiberty Bell Award\r\n<h2>Professional Associations and Memberships</h2>\r\nAmerican Bar Association, Member\r\nBell-Lampasas-Mills County Bar Association, Member\r\nFort Hood Bar Association, Member\r\nAssociation of the United States Army, Member\r\nKilleen-Heights Rotary Club, Member\r\nHarker Heights Chamber of Commerce, Member\r\nHarker Heights Chamber of Commerce Military Affairs Committee, Member\r\nHarker Heights Rotary Club, Member\r\nU.S. Army JAG Corps, Chief of Legal Assistance, III Corps and Fort Hood, 1973 - 1976\r\nUnited States Army, Judge Advocate General Officer\r\nKilleen Food Care Center, President, 1987 - 1992\r\nHarker Heights, Texas, City Attorney, 1987 - 1990\r\nHarker Heights, Texas, City Council Member, 1993 - 1997\r\nMetroplex Hospital Foundation, Treasurer\r\nState Bar Presidential Citation, Recipient, 1991 - Present\r\nMetroplex Hospital Foundation, Past Chair\r\nHarker Heights Chamber of Commerce, Past Chair\r\n<h2>Past Employment Positions</h2>\r\nU.S. Army Judge Advocate General Corps, Captain, 1973 - 1976\r\nServed as Chief, Fort Hood Legal Assistance Office\r\nFounded what is today the Carlson Law Firm, PC in October 1976 (formerly Smith &amp; Carlson, PC)\r\nCity Attorney for City of Harker Heights, 1989 - 1992\r\nFounded the Ted Smith Law Firm, PLLC in January, 2005\r\nFounded Ted Smith Law Group, PLLC in August, 2011\r\n<h2>Previous Names</h2>\r\nThe Ted Smith Law Firm, PLLC, August 1, 2011', 'Ted Smith', '', 'publish', 'closed', 'closed', '', 'ted-smith', '', '', '2016-05-20 19:15:55', '2016-05-20 19:15:55', '', 108, 'http://tedsmithdemo.com/?page_id=161', 0, 'page', '', 0),
(162, 1, '2016-05-20 19:15:55', '2016-05-20 19:15:55', '<h2>Senior Partner</h2>\r\nLocation:\r\nHarker Heights, Texas\r\nPhone:\r\n254-690-5688\r\nFax:\r\n254-690-5685\r\n\r\nCentral Texans have been represented by Ted Smith for the past 39 years. Ted was an active duty JAG officer at Fort Hood before he opened his first private practice in Killeen in 1976. Since then he has represented thousands of Central Texans by providing solutions to their legal needs. From assisting with the purchase or sale of their family home to assisting them recover for the wrongful death of a loved one, Ted has been there offering his legal expertise at affordable rates. Ted is a fixture in the Central Texas community. He has served as city attorney for Harker Heights; been elected to the Harker Heights City Council; served as chairman of the Harker Heights Chamber of Commerce, the Metroplex Hospital Foundation, and the Killeen Food Care Center Board of Directors. He is serving or has served on the Viva Les Artes Society Board of Directors, the Youth Services Bureau, Killeen and Harker Heights Rotary clubs, and Young Life.\r\n<h2>Areas of Practice</h2>\r\nSocial Security Disability\r\nReal Estate &amp; Consumer Litigation\r\nBusiness Litigation\r\nReal Estate Transactions\r\nBusiness Formation\r\nEstate Planning &amp; Probate\r\nGeneral Business Practice\r\nCertified Legal Specialties\r\n\r\nBoard Certified in Residential and Commercial Real Estate Law, Texas Board of Legal Specialization, 1983\r\nCertified Mediator including advanced training for family matters\r\n<h2>Bar Admissions</h2>\r\nSupreme Court of Indiana, 1973\r\nSupreme Court of Texas, 1975\r\nU.S. District Court Southern District of Indiana, 1973\r\nU. S. Court of Military Appeals, 1973\r\nU.S. District Court Western District of Texas, 1984\r\n<h2>Education</h2>\r\nIndiana University School of Law, Indianapolis, Indiana\r\nJ.D. - 1973\r\nIndiana University\r\nA.B. - 1970\r\nMajor: Zoology and Radio &amp; TV\r\nU.S. Army Judge Advocate General School - 1973\r\n<h2>Honors and Awards</h2>\r\nArmy Commendation Medal\r\nDistinguished Military Attorney\r\nPresidential Citation, State Bar of Texas\r\nLiberty Bell Award\r\n<h2>Professional Associations and Memberships</h2>\r\nAmerican Bar Association, Member\r\nBell-Lampasas-Mills County Bar Association, Member\r\nFort Hood Bar Association, Member\r\nAssociation of the United States Army, Member\r\nKilleen-Heights Rotary Club, Member\r\nHarker Heights Chamber of Commerce, Member\r\nHarker Heights Chamber of Commerce Military Affairs Committee, Member\r\nHarker Heights Rotary Club, Member\r\nU.S. Army JAG Corps, Chief of Legal Assistance, III Corps and Fort Hood, 1973 - 1976\r\nUnited States Army, Judge Advocate General Officer\r\nKilleen Food Care Center, President, 1987 - 1992\r\nHarker Heights, Texas, City Attorney, 1987 - 1990\r\nHarker Heights, Texas, City Council Member, 1993 - 1997\r\nMetroplex Hospital Foundation, Treasurer\r\nState Bar Presidential Citation, Recipient, 1991 - Present\r\nMetroplex Hospital Foundation, Past Chair\r\nHarker Heights Chamber of Commerce, Past Chair\r\n<h2>Past Employment Positions</h2>\r\nU.S. Army Judge Advocate General Corps, Captain, 1973 - 1976\r\nServed as Chief, Fort Hood Legal Assistance Office\r\nFounded what is today the Carlson Law Firm, PC in October 1976 (formerly Smith &amp; Carlson, PC)\r\nCity Attorney for City of Harker Heights, 1989 - 1992\r\nFounded the Ted Smith Law Firm, PLLC in January, 2005\r\nFounded Ted Smith Law Group, PLLC in August, 2011\r\n<h2>Previous Names</h2>\r\nThe Ted Smith Law Firm, PLLC, August 1, 2011', 'Ted Smith', '', 'inherit', 'closed', 'closed', '', '161-revision-v1', '', '', '2016-05-20 19:15:55', '2016-05-20 19:15:55', '', 161, 'http://tedsmithdemo.com/161-revision-v1/', 0, 'revision', '', 0),
(163, 1, '2016-05-20 19:16:51', '2016-05-20 19:16:51', 'Location:\r\nHarker Heights, Texas\r\nPhone:\r\n254-690-5688\r\nFax:\r\n254-690-5685\r\n<h2>Areas of Practice</h2>\r\nAdministrative Law\r\nFamily Law\r\nBusiness &amp; Commercial Law\r\n<h2>Bar Admissions</h2>\r\nTexas, 2013\r\n<h2>Education</h2>\r\nBaylor University School of Law, Waco, Texas\r\nJ.D. - 2013\r\nUniversity of Texas at Arlington, Arlington, Texas\r\nB.A. cum laude\r\nHonors: University Scholar, McNair Scholor\r\nMajor: Honors History\r\n<h2>Published Works</h2>\r\nVarious Water Agreements: Most Importantly Water Well Agreements , Advanced Real Estate Drafting, 2012\r\nRepresentative Clients\r\n\r\nSmall Businesses\r\nState of Texas\r\n<h2>Honors and Awards</h2>\r\nCleburne Chamber of Commerce/Hill College Citizen of the Year, 2002\r\nPast Employment Positions\r\n\r\nTexas Secretary of State, Attorney II, 2014 - 2015\r\nTexas Office of the Attorney General, Assistant of Attorney General, 2014\r\nEvans Kosut Davidson, PLLC, Attorney, 2013 - 2014\r\n<h2>Pro Bono Activities</h2>\r\nHouston Volunteer Lawyers Association, 2013 - 2014\r\nBaylor Law Veterans Clinic, 2010 - 2013', 'Grace A. Wilhem', '', 'publish', 'closed', 'closed', '', 'grace-a-wilhem', '', '', '2016-05-20 19:16:51', '2016-05-20 19:16:51', '', 108, 'http://tedsmithdemo.com/?page_id=163', 0, 'page', '', 0),
(164, 1, '2016-05-20 19:16:51', '2016-05-20 19:16:51', 'Location:\r\nHarker Heights, Texas\r\nPhone:\r\n254-690-5688\r\nFax:\r\n254-690-5685\r\n<h2>Areas of Practice</h2>\r\nAdministrative Law\r\nFamily Law\r\nBusiness &amp; Commercial Law\r\n<h2>Bar Admissions</h2>\r\nTexas, 2013\r\n<h2>Education</h2>\r\nBaylor University School of Law, Waco, Texas\r\nJ.D. - 2013\r\nUniversity of Texas at Arlington, Arlington, Texas\r\nB.A. cum laude\r\nHonors: University Scholar, McNair Scholor\r\nMajor: Honors History\r\n<h2>Published Works</h2>\r\nVarious Water Agreements: Most Importantly Water Well Agreements , Advanced Real Estate Drafting, 2012\r\nRepresentative Clients\r\n\r\nSmall Businesses\r\nState of Texas\r\n<h2>Honors and Awards</h2>\r\nCleburne Chamber of Commerce/Hill College Citizen of the Year, 2002\r\nPast Employment Positions\r\n\r\nTexas Secretary of State, Attorney II, 2014 - 2015\r\nTexas Office of the Attorney General, Assistant of Attorney General, 2014\r\nEvans Kosut Davidson, PLLC, Attorney, 2013 - 2014\r\n<h2>Pro Bono Activities</h2>\r\nHouston Volunteer Lawyers Association, 2013 - 2014\r\nBaylor Law Veterans Clinic, 2010 - 2013', 'Grace A. Wilhem', '', 'inherit', 'closed', 'closed', '', '163-revision-v1', '', '', '2016-05-20 19:16:51', '2016-05-20 19:16:51', '', 163, 'http://tedsmithdemo.com/163-revision-v1/', 0, 'revision', '', 0),
(165, 1, '2016-05-20 19:17:57', '2016-05-20 19:17:57', 'Richard Lee King\r\n<h2>Associate</h2>\r\nLocation:\r\nHarker Heights, Texas\r\nPhone:\r\n254-690-5688\r\nFax:\r\n254-690-5685\r\n<h2>Areas of Practice</h2>\r\nPersonal Injury\r\nFamily Law\r\nCriminal Defense\r\nLitigation Percentage\r\n\r\n100% of Practice Devoted to Litigation\r\n<h2>Bar Admissions</h2>\r\nTexas, 1998\r\n<h2>Education</h2>\r\nTexas Wesleyan University School of Law, Fort Worth, Texas\r\nJ.D. - 1995\r\nTexas Tech University\r\nB.A.\r\nHonors: Dean\'s List\r\nMajor: Political Science\r\nUniversity of North Texas\r\nM.P.A.\r\nMajor: Public Administration\r\n<h2>Past Employment Positions</h2>\r\nSelf-Employed, Attorney, 2004 - 2015\r\nBrown McCarroll, LLP, Attorney, 2002 - 2004', 'Richard L. King', '', 'publish', 'closed', 'closed', '', 'richard-l-king', '', '', '2016-05-20 19:17:57', '2016-05-20 19:17:57', '', 108, 'http://tedsmithdemo.com/?page_id=165', 0, 'page', '', 0),
(166, 1, '2016-05-20 19:17:57', '2016-05-20 19:17:57', 'Richard Lee King\r\n<h2>Associate</h2>\r\nLocation:\r\nHarker Heights, Texas\r\nPhone:\r\n254-690-5688\r\nFax:\r\n254-690-5685\r\n<h2>Areas of Practice</h2>\r\nPersonal Injury\r\nFamily Law\r\nCriminal Defense\r\nLitigation Percentage\r\n\r\n100% of Practice Devoted to Litigation\r\n<h2>Bar Admissions</h2>\r\nTexas, 1998\r\n<h2>Education</h2>\r\nTexas Wesleyan University School of Law, Fort Worth, Texas\r\nJ.D. - 1995\r\nTexas Tech University\r\nB.A.\r\nHonors: Dean\'s List\r\nMajor: Political Science\r\nUniversity of North Texas\r\nM.P.A.\r\nMajor: Public Administration\r\n<h2>Past Employment Positions</h2>\r\nSelf-Employed, Attorney, 2004 - 2015\r\nBrown McCarroll, LLP, Attorney, 2002 - 2004', 'Richard L. King', '', 'inherit', 'closed', 'closed', '', '165-revision-v1', '', '', '2016-05-20 19:17:57', '2016-05-20 19:17:57', '', 165, 'http://tedsmithdemo.com/165-revision-v1/', 0, 'revision', '', 0),
(167, 1, '2016-05-20 19:18:55', '2016-05-20 19:18:55', 'Location:\r\nHarker Heights, Texas\r\nPhone:\r\n254-690-5688\r\nFax:\r\n254-690-5685\r\n<h2>Areas of Practice</h2>\r\n75% Family Law\r\n25% Criminal Defense\r\nLitigation Percentage\r\n\r\n100% of Practice Devoted to Litigation\r\n<h2>Bar Admissions</h2>\r\nTexas, 2008\r\n<h2>Education</h2>\r\nUniversity of Tulsa College of Law, Tulsa, Oklahoma\r\nJ.D. - 2008\r\nWashburn University, Topeka, Kansas\r\nB.B.A. cum laude - 2004\r\nHonors: Dean\'s List Numerous Semesters\r\nMajor: Management &amp; Marketing\r\n<h2>Past Employment Positions</h2>\r\nLaw Offices of Nicholas R. Smith, Owner/Attorney, 2008 - 2015\r\nBailey &amp; Gaylen, Associate Attorney, 2013 - 2015\r\n<h2>Pro Bono Activities</h2>\r\nVolunteer Attorney at Fathers for Equal Rights, 2008 - 2015', 'Nicholas R. Smith', '', 'publish', 'closed', 'closed', '', 'nicholas-r-smith', '', '', '2016-05-20 19:18:55', '2016-05-20 19:18:55', '', 108, 'http://tedsmithdemo.com/?page_id=167', 0, 'page', '', 0),
(168, 1, '2016-05-20 19:18:55', '2016-05-20 19:18:55', 'Location:\r\nHarker Heights, Texas\r\nPhone:\r\n254-690-5688\r\nFax:\r\n254-690-5685\r\n<h2>Areas of Practice</h2>\r\n75% Family Law\r\n25% Criminal Defense\r\nLitigation Percentage\r\n\r\n100% of Practice Devoted to Litigation\r\n<h2>Bar Admissions</h2>\r\nTexas, 2008\r\n<h2>Education</h2>\r\nUniversity of Tulsa College of Law, Tulsa, Oklahoma\r\nJ.D. - 2008\r\nWashburn University, Topeka, Kansas\r\nB.B.A. cum laude - 2004\r\nHonors: Dean\'s List Numerous Semesters\r\nMajor: Management &amp; Marketing\r\n<h2>Past Employment Positions</h2>\r\nLaw Offices of Nicholas R. Smith, Owner/Attorney, 2008 - 2015\r\nBailey &amp; Gaylen, Associate Attorney, 2013 - 2015\r\n<h2>Pro Bono Activities</h2>\r\nVolunteer Attorney at Fathers for Equal Rights, 2008 - 2015', 'Nicholas R. Smith', '', 'inherit', 'closed', 'closed', '', '167-revision-v1', '', '', '2016-05-20 19:18:55', '2016-05-20 19:18:55', '', 167, 'http://tedsmithdemo.com/167-revision-v1/', 0, 'revision', '', 0),
(169, 1, '2016-05-20 19:19:46', '2016-05-20 19:19:46', ' ', '', '', 'publish', 'closed', 'closed', '', '169', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 0, 'http://tedsmithdemo.com/?p=169', 3, 'nav_menu_item', '', 0),
(174, 1, '2016-05-20 19:19:46', '2016-05-20 19:19:46', ' ', '', '', 'publish', 'closed', 'closed', '', '174', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 0, 'http://tedsmithdemo.com/?p=174', 43, 'nav_menu_item', '', 0),
(175, 1, '2016-05-20 19:19:46', '2016-05-20 19:19:46', ' ', '', '', 'publish', 'closed', 'closed', '', '175', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 0, 'http://tedsmithdemo.com/?p=175', 1, 'nav_menu_item', '', 0),
(177, 1, '2016-07-13 20:55:49', '2016-07-13 20:55:49', '', 'Practice Areas', '', 'publish', 'closed', 'closed', '', '177', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 0, 'http://tedsmithdemo.com/?p=177', 4, 'nav_menu_item', '', 0),
(178, 1, '2016-07-13 21:00:23', '2016-07-13 21:00:23', '<h2>Texans have been represented by the Ted Smith Law Group for over 43 years.</h2>\r\nSuspendisse eu lacinia enim, vel pellentesque diam. Pellentesque feu\r\ngiat a massa ac iaculis. Aliquam erat volutpat. Aliquam non quam luctus, tincidunt urna malesuada, convallis risus. Suspendisse tincidunt vehicula ultrices. Sed congue elit pretium, fringilla neque ac, imperdiet nisl. In posuere eros pellentesque porttitor varius. Aenean aliquet luctus augue id pulvinar. Cras ac pellentesque ante. Nam tempor sapien eu enim mollis, ac tincidunt nisl semper. Etiam at tortor nec sapien euismod gravida. Proin sollicitudin varius nisi a lacinia. Proin vestibulum eget augue et ultricies. Aenean cursus tristique ante ac sollicitudin.\r\n\r\nNullam dapibus augue sed lacus tempus lacinia. Proin vitae blandit tortor, eget posuere nibh. Aenean consectetur, nulla sed aliquet malesuada, nibh arcu aliquet ipsum, nec bibendum est nisl a lacus. Maecenas quis elit laoreet, convallis neque eu, ullamcorper arcu.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean ult ricies risus quis viverra scelerisque. Suspendisse eu lacinia enim, vel pelle ntesque diam. Pellentesque feugiat a massa ac iaculis. Aliquam erat volutpat. Aliquam non quam luctus, tincidunt urna malesuada, convallis risus. Suspendisse tincidunt vehicula ultrices. Sed congue elit pretium, fringilla neque ac, imperdiet nisl. In posuere eros pellentesque porttitor varius. Aenean aliquet luctus augue id pulvinar. Cras ac pellentesque.\r\n\r\n<h2>Texans have been represented by the Ted Smith Law Group for over 43 years.</h2>\r\n\r\nNam tempor sapien eu enim mollis, ac tincidunt nisl semper. Etiam at tortor nec sapien euismod gravida. Proin sollicitudin varius nisi a lacinia. Proin vestibulum eget augue et ultricies. Aenean cursus tristique ante ac sollicitudin. Nullam dapibus augue sed lacus tempus lacinia. Proin vitae blandit tortor, eget posuere nibh. Aenean consectetur, nulla sed aliquet malesuada, nibh arcu aliquet ipsum, nec bibendum est nisl a lacus.', 'About Us', '', 'publish', 'closed', 'closed', '', 'about-us', '', '', '2016-08-02 06:11:58', '2016-08-02 06:11:58', '', 0, 'http://tedsmithdemo.com/?page_id=178', 0, 'page', '', 0),
(179, 1, '2016-07-13 21:00:23', '2016-07-13 21:00:23', '', 'About Us', '', 'inherit', 'closed', 'closed', '', '178-revision-v1', '', '', '2016-07-13 21:00:23', '2016-07-13 21:00:23', '', 178, 'http://tedsmithdemo.com/178-revision-v1/', 0, 'revision', '', 0),
(180, 1, '2016-07-13 21:02:31', '2016-07-13 21:02:31', ' ', '', '', 'publish', 'closed', 'closed', '', '180', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 0, 'http://tedsmithdemo.com/?p=180', 2, 'nav_menu_item', '', 0),
(182, 1, '2016-07-13 21:05:53', '2016-07-13 21:05:53', ' ', '', '', 'publish', 'closed', 'closed', '', '182', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 31, 'http://tedsmithdemo.com/?p=182', 5, 'nav_menu_item', '', 0),
(183, 1, '2016-07-13 21:05:53', '2016-07-13 21:05:53', ' ', '', '', 'publish', 'closed', 'closed', '', '183', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 31, 'http://tedsmithdemo.com/?p=183', 6, 'nav_menu_item', '', 0),
(184, 1, '2016-07-13 21:05:53', '2016-07-13 21:05:53', ' ', '', '', 'publish', 'closed', 'closed', '', '184', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 31, 'http://tedsmithdemo.com/?p=184', 7, 'nav_menu_item', '', 0),
(185, 1, '2016-07-13 21:05:53', '2016-07-13 21:05:53', ' ', '', '', 'publish', 'closed', 'closed', '', '185', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 31, 'http://tedsmithdemo.com/?p=185', 8, 'nav_menu_item', '', 0),
(186, 1, '2016-07-13 21:05:53', '2016-07-13 21:05:53', ' ', '', '', 'publish', 'closed', 'closed', '', '186', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 31, 'http://tedsmithdemo.com/?p=186', 9, 'nav_menu_item', '', 0),
(187, 1, '2016-07-13 21:05:53', '2016-07-13 21:05:53', ' ', '', '', 'publish', 'closed', 'closed', '', '187', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 31, 'http://tedsmithdemo.com/?p=187', 10, 'nav_menu_item', '', 0),
(188, 1, '2016-07-13 21:05:53', '2016-07-13 21:05:53', ' ', '', '', 'publish', 'closed', 'closed', '', '188', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 31, 'http://tedsmithdemo.com/?p=188', 11, 'nav_menu_item', '', 0),
(189, 1, '2016-07-13 21:05:53', '2016-07-13 21:05:53', ' ', '', '', 'publish', 'closed', 'closed', '', '189', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 31, 'http://tedsmithdemo.com/?p=189', 26, 'nav_menu_item', '', 0),
(190, 1, '2016-07-13 21:05:53', '2016-07-13 21:05:53', ' ', '', '', 'publish', 'closed', 'closed', '', '190', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 31, 'http://tedsmithdemo.com/?p=190', 27, 'nav_menu_item', '', 0),
(191, 1, '2016-07-13 21:05:53', '2016-07-13 21:05:53', ' ', '', '', 'publish', 'closed', 'closed', '', '191', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 31, 'http://tedsmithdemo.com/?p=191', 28, 'nav_menu_item', '', 0),
(192, 1, '2016-07-13 21:05:53', '2016-07-13 21:05:53', ' ', '', '', 'publish', 'closed', 'closed', '', '192', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 31, 'http://tedsmithdemo.com/?p=192', 29, 'nav_menu_item', '', 0),
(194, 1, '2016-07-13 21:08:01', '2016-07-13 21:08:01', ' ', '', '', 'publish', 'closed', 'closed', '', '194', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 4, 'http://tedsmithdemo.com/?p=194', 14, 'nav_menu_item', '', 0),
(195, 1, '2016-07-13 21:08:01', '2016-07-13 21:08:01', ' ', '', '', 'publish', 'closed', 'closed', '', '195', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 4, 'http://tedsmithdemo.com/?p=195', 15, 'nav_menu_item', '', 0),
(196, 1, '2016-07-13 21:08:01', '2016-07-13 21:08:01', ' ', '', '', 'publish', 'closed', 'closed', '', '196', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 4, 'http://tedsmithdemo.com/?p=196', 16, 'nav_menu_item', '', 0),
(197, 1, '2016-07-13 21:08:01', '2016-07-13 21:08:01', ' ', '', '', 'publish', 'closed', 'closed', '', '197', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 4, 'http://tedsmithdemo.com/?p=197', 17, 'nav_menu_item', '', 0),
(198, 1, '2016-07-13 21:08:01', '2016-07-13 21:08:01', ' ', '', '', 'publish', 'closed', 'closed', '', '198', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 4, 'http://tedsmithdemo.com/?p=198', 18, 'nav_menu_item', '', 0),
(199, 1, '2016-07-13 21:08:01', '2016-07-13 21:08:01', ' ', '', '', 'publish', 'closed', 'closed', '', '199', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 4, 'http://tedsmithdemo.com/?p=199', 19, 'nav_menu_item', '', 0),
(200, 1, '2016-07-13 21:08:01', '2016-07-13 21:08:01', '', 'Fathers\' Rights', '', 'publish', 'closed', 'closed', '', 'fathers-rights-2', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 4, 'http://tedsmithdemo.com/?p=200', 20, 'nav_menu_item', '', 0),
(201, 1, '2016-07-13 21:08:01', '2016-07-13 21:08:01', ' ', '', '', 'publish', 'closed', 'closed', '', '201', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 4, 'http://tedsmithdemo.com/?p=201', 21, 'nav_menu_item', '', 0),
(202, 1, '2016-07-13 21:08:01', '2016-07-13 21:08:01', ' ', '', '', 'publish', 'closed', 'closed', '', '202', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 4, 'http://tedsmithdemo.com/?p=202', 22, 'nav_menu_item', '', 0),
(203, 1, '2016-07-13 21:08:01', '2016-07-13 21:08:01', ' ', '', '', 'publish', 'closed', 'closed', '', '203', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 4, 'http://tedsmithdemo.com/?p=203', 23, 'nav_menu_item', '', 0),
(204, 1, '2016-07-13 21:08:01', '2016-07-13 21:08:01', ' ', '', '', 'publish', 'closed', 'closed', '', '204', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 4, 'http://tedsmithdemo.com/?p=204', 24, 'nav_menu_item', '', 0),
(205, 1, '2016-07-13 21:08:01', '2016-07-13 21:08:01', ' ', '', '', 'publish', 'closed', 'closed', '', '205', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 4, 'http://tedsmithdemo.com/?p=205', 25, 'nav_menu_item', '', 0),
(206, 1, '2016-07-13 21:21:31', '0000-00-00 00:00:00', ' ', '', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-07-13 21:21:31', '0000-00-00 00:00:00', '', 0, 'http://tedsmithdemo.com/?p=206', 1, 'nav_menu_item', '', 0),
(207, 1, '2016-07-13 21:22:52', '2016-07-13 21:22:52', '', 'Family Law Overview', '', 'publish', 'closed', 'closed', '', 'family-law-overview', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 0, 'http://tedsmithdemo.com/?p=207', 13, 'nav_menu_item', '', 0),
(208, 1, '2016-07-13 21:24:03', '2016-07-13 21:24:03', '', 'Family Law', '', 'publish', 'closed', 'closed', '', 'family-law', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 0, 'http://tedsmithdemo.com/?p=208', 12, 'nav_menu_item', '', 0),
(209, 1, '2016-07-13 21:27:24', '2016-07-13 21:27:24', '', 'Social Security Disability', '', 'publish', 'closed', 'closed', '', 'social-security-disability', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 0, 'http://tedsmithdemo.com/?p=209', 30, 'nav_menu_item', '', 0),
(210, 1, '2016-07-13 21:27:24', '2016-07-13 21:27:24', '', 'Social Security Disability General Overview', '', 'publish', 'closed', 'closed', '', 'social-security-disability-general-overview', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 0, 'http://tedsmithdemo.com/?p=210', 31, 'nav_menu_item', '', 0),
(211, 1, '2016-07-13 21:27:24', '2016-07-13 21:27:24', ' ', '', '', 'publish', 'closed', 'closed', '', '211', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 63, 'http://tedsmithdemo.com/?p=211', 32, 'nav_menu_item', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(212, 1, '2016-07-13 21:27:24', '2016-07-13 21:27:24', ' ', '', '', 'publish', 'closed', 'closed', '', '212', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 63, 'http://tedsmithdemo.com/?p=212', 33, 'nav_menu_item', '', 0),
(213, 1, '2016-07-13 21:28:16', '2016-07-13 21:28:16', ' ', '', '', 'publish', 'closed', 'closed', '', '213', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 63, 'http://tedsmithdemo.com/?p=213', 36, 'nav_menu_item', '', 0),
(214, 1, '2016-07-13 21:28:16', '2016-07-13 21:28:16', ' ', '', '', 'publish', 'closed', 'closed', '', '214', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 63, 'http://tedsmithdemo.com/?p=214', 35, 'nav_menu_item', '', 0),
(215, 1, '2016-07-13 21:28:16', '2016-07-13 21:28:16', ' ', '', '', 'publish', 'closed', 'closed', '', '215', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 63, 'http://tedsmithdemo.com/?p=215', 34, 'nav_menu_item', '', 0) ;
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(222, 1, '2016-07-14 17:30:09', '2016-07-14 17:30:09', ' ', '', '', 'publish', 'closed', 'closed', '', '222', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 0, 'http://tedsmithdemo.com/?p=222', 38, 'nav_menu_item', '', 0),
(223, 1, '2016-07-14 17:30:09', '2016-07-14 17:30:09', ' ', '', '', 'publish', 'closed', 'closed', '', '223', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 0, 'http://tedsmithdemo.com/?p=223', 39, 'nav_menu_item', '', 0),
(224, 1, '2016-07-14 17:30:09', '2016-07-14 17:30:09', ' ', '', '', 'publish', 'closed', 'closed', '', '224', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 0, 'http://tedsmithdemo.com/?p=224', 40, 'nav_menu_item', '', 0),
(228, 1, '2016-07-19 22:52:00', '2016-07-19 22:52:00', '', 'Case Results', '', 'publish', 'closed', 'closed', '', 'case-results', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 0, 'http://tedsmithdemo.com/?p=228', 37, 'nav_menu_item', '', 0),
(229, 1, '2016-07-19 22:52:00', '2016-07-19 22:52:00', '', 'Testimonials', '', 'publish', 'closed', 'closed', '', 'testimonials', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 0, 'http://tedsmithdemo.com/?p=229', 41, 'nav_menu_item', '', 0),
(230, 1, '2016-07-19 22:52:48', '2016-07-19 22:52:48', '', 'Video Center', '', 'publish', 'closed', 'closed', '', 'video-center', '', '', '2016-07-19 22:52:48', '2016-07-19 22:52:48', '', 0, 'http://tedsmithdemo.com/?page_id=230', 0, 'page', '', 0),
(231, 1, '2016-07-19 22:52:48', '2016-07-19 22:52:48', '', 'Video Center', '', 'inherit', 'closed', 'closed', '', '230-revision-v1', '', '', '2016-07-19 22:52:48', '2016-07-19 22:52:48', '', 230, 'http://tedsmithdemo.com/230-revision-v1/', 0, 'revision', '', 0),
(232, 1, '2016-07-19 22:54:00', '2016-07-19 22:54:00', ' ', '', '', 'publish', 'closed', 'closed', '', '232', '', '', '2016-07-19 22:54:37', '2016-07-19 22:54:37', '', 0, 'http://tedsmithdemo.com/?p=232', 42, 'nav_menu_item', '', 0),
(233, 1, '2016-08-01 23:21:28', '0000-00-00 00:00:00', '', 'Auto Draft', '', 'auto-draft', 'open', 'open', '', '', '', '', '2016-08-01 23:21:28', '0000-00-00 00:00:00', '', 0, 'http://tedsmithdemo.com/?p=233', 0, 'post', '', 0),
(234, 1, '2016-08-02 05:31:05', '2016-08-02 05:31:05', 'The purpose of this HTML is to help determine what default settings are with CSS and to make sure that all possible HTML Elements are included in this HTML so as to not miss any possible Elements when designing a site.\r\n\r\n<hr />\r\n\r\n<h1>Heading 1</h1>\r\n<h2>Heading 2</h2>\r\n<h3>Heading 3</h3>\r\n<h4>Heading 4</h4>\r\n<h5>Heading 5</h5>\r\n<h6>Heading 6</h6>\r\n<small><a href="#wrapper">[top]</a></small>\r\n\r\n<hr />\r\n\r\n<h2 id="paragraph">Paragraph</h2>\r\nLorem ipsum dolor sit amet, <a title="test link" href="#">test link</a> adipiscing elit. Nullam dignissim convallis est. Quisque aliquam. Donec faucibus. Nunc iaculis suscipit dui. Nam sit amet sem. Aliquam libero nisi, imperdiet at, tincidunt nec, gravida vehicula, nisl. Praesent mattis, massa quis luctus fermentum, turpis mi volutpat justo, eu volutpat enim diam eget metus. Maecenas ornare tortor. Donec sed tellus eget sapien fringilla nonummy. Mauris a ante. Suspendisse quam sem, consequat at, commodo vitae, feugiat in, nunc. Morbi imperdiet augue quis tellus.\r\n\r\nLorem ipsum dolor sit amet, <em>emphasis</em> consectetuer adipiscing elit. Nullam dignissim convallis est. Quisque aliquam. Donec faucibus. Nunc iaculis suscipit dui. Nam sit amet sem. Aliquam libero nisi, imperdiet at, tincidunt nec, gravida vehicula, nisl. Praesent mattis, massa quis luctus fermentum, turpis mi volutpat justo, eu volutpat enim diam eget metus. Maecenas ornare tortor. Donec sed tellus eget sapien fringilla nonummy. Mauris a ante. Suspendisse quam sem, consequat at, commodo vitae, feugiat in, nunc. Morbi imperdiet augue quis tellus.\r\n\r\n<small><a href="#wrapper">[top]</a></small>\r\n\r\n<hr />\r\n\r\n<h2 id="list_types">List Types</h2>\r\n<h3>Definition List</h3>\r\n<dl><dt>Definition List Title</dt><dd>This is a definition list division.</dd></dl>\r\n<h3>Ordered List</h3>\r\n<ol>\r\n	<li>List Item 1</li>\r\n	<li>List Item 2</li>\r\n	<li>List Item 3</li>\r\n</ol>\r\n<h3>Unordered List</h3>\r\n<ul>\r\n	<li>List Item 1</li>\r\n	<li>List Item 2</li>\r\n	<li>List Item 3</li>\r\n</ul>\r\n<small><a href="#wrapper">[top]</a></small>\r\n\r\n<hr />\r\n\r\n<h2 id="form_elements">Forms</h2>\r\n<fieldset><legend>Legend</legend>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nullam dignissim convallis est. Quisque aliquam. Donec faucibus. Nunc iaculis suscipit dui. Nam sit amet sem. Aliquam libero nisi, imperdiet at, tincidunt nec, gravida vehicula, nisl. Praesent mattis, massa quis luctus fermentum, turpis mi volutpat justo, eu volutpat enim diam eget metus.\r\n\r\n<form>\r\n<h2>Form Element</h2>\r\nLorem ipsum dolor sit amet, consectetuer adipiscing elit. Nullam dignissim convallis est. Quisque aliquam. Donec faucibus. Nunc iaculis suscipit dui.\r\n\r\n<label for="text_field">Text Field:</label>\r\n\r\n<input id="text_field" type="text" /><label for="text_area">Text Area:</label>\r\n<textarea id="text_area"></textarea>\r\n\r\n<label for="select_element">Select Element:</label>\r\n\r\n<select name="select_element"> <optgroup label="Option Group 1"> <option value="1">Option 1</option> <option value="2">Option 2</option> <option value="3">Option 3</option></optgroup></select>&nbsp;\r\n<select name="select_element"> <optgroup label="Option Group 2"> <option value="1">Option 1</option> <option value="2">Option 2</option> <option value="3">Option 3</option></optgroup></select>&nbsp;\r\n<label for="radio_buttons">Radio Buttons:</label>\r\n\r\n<input class="radio" type="radio" name="radio_button" value="radio_1" /> Radio 1 <input class="radio" type="radio" name="radio_button" value="radio_2" /> Radio 2 <input class="radio" type="radio" name="radio_button" value="radio_3" />Radio 3<label for="checkboxes">Checkboxes:</label>\r\n\r\n<input class="checkbox" type="checkbox" name="checkboxes" value="check_1" /> Radio 1 <input class="checkbox" type="checkbox" name="checkboxes" value="check_2" /> Radio 2 <input class="checkbox" type="checkbox" name="checkboxes" value="check_3" />Radio 3<label for="password">Password:</label>\r\n\r\n<input class="password" type="password" name="password" /><label for="file">File Input:</label>\r\n\r\n<input class="file" type="file" name="file" /> <input class="button" type="reset" value="Clear" /> <input class="button" type="submit" value="Submit" /></form></fieldset>\r\n<small><a href="#wrapper">[top]</a></small>\r\n\r\n<hr />\r\n\r\n<h2 id="tables">Tables</h2>\r\n<table cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr>\r\n<th>Table Header 1</th>\r\n<th>Table Header 2</th>\r\n<th>Table Header 3</th>\r\n</tr>\r\n<tr>\r\n<td>Division 1</td>\r\n<td>Division 2</td>\r\n<td>Division 3</td>\r\n</tr>\r\n<tr class="even">\r\n<td>Division 1</td>\r\n<td>Division 2</td>\r\n<td>Division 3</td>\r\n</tr>\r\n<tr>\r\n<td>Division 1</td>\r\n<td>Division 2</td>\r\n<td>Division 3</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<small><a href="#wrapper">[top]</a></small>\r\n\r\n<hr />\r\n\r\n<h2 id="misc">Misc Stuff – abbr, acronym, pre, code, sub, sup, etc.</h2>\r\nLorem <sup>superscript</sup> dolor <sub>subscript</sub> amet, consectetuer adipiscing elit. Nullam dignissim convallis est. Quisque aliquam. <cite>cite</cite>. Nunc iaculis suscipit dui. Nam sit amet sem. Aliquam libero nisi, imperdiet at, tincidunt nec, gravida vehicula, nisl. Praesent mattis, massa quis luctus fermentum, turpis mi volutpat justo, eu volutpat enim diam eget metus. Maecenas ornare tortor. Donec sed tellus eget sapien fringilla nonummy. <acronym title="National Basketball Association">NBA</acronym> Mauris a ante. Suspendisse quam sem, consequat at, commodo vitae, feugiat in, nunc. Morbi imperdiet augue quis tellus. <abbr title="Avenue">AVE</abbr>\r\n<pre>\r\nLorem ipsum dolor sit amet,\r\n consectetuer adipiscing elit.\r\n Nullam dignissim convallis est.\r\n Quisque aliquam. Donec faucibus.\r\nNunc iaculis suscipit dui.\r\nNam sit amet sem.\r\nAliquam libero nisi, imperdiet at,\r\n tincidunt nec, gravida vehicula,\r\n nisl.\r\nPraesent mattis, massa quis\r\nluctus fermentum, turpis mi\r\nvolutpat justo, eu volutpat\r\nenim diam eget metus.\r\nMaecenas ornare tortor.\r\nDonec sed tellus eget sapien\r\n fringilla nonummy.\r\n<acronym title="National Basketball Association">NBA</acronym>\r\nMauris a ante. Suspendisse\r\n quam sem, consequat at,\r\ncommodo vitae, feugiat in,\r\nnunc. Morbi imperdiet augue\r\n quis tellus.\r\n<abbr title="Avenue">AVE</abbr></pre>\r\n<blockquote>“This stylesheet is going to help so freaking much.”\r\n-Blockquote</blockquote>\r\n<small><a href="#wrapper">[top]</a></small>\r\n<!-- End of Sample Content →\r\n', 'About Us', '', 'inherit', 'closed', 'closed', '', '178-revision-v1', '', '', '2016-08-02 05:31:05', '2016-08-02 05:31:05', '', 178, 'http://tedsmithdemo.com/178-revision-v1/', 0, 'revision', '', 0),
(235, 1, '2016-08-02 05:45:32', '2016-08-02 05:45:32', 'The purpose of this HTML is to help determine what default settings are with CSS and to make sure that all possible HTML Elements are included in this HTML so as to not miss any possible Elements when designing a site.\r\n\r\n<hr />\r\n\r\n<h1>Heading 1</h1>\r\n<h2>Heading 2</h2>\r\n<h3>Heading 3</h3>\r\n<h4>Heading 4</h4>\r\n<h5>Heading 5</h5>\r\n<h6>Heading 6</h6>\r\n<small><a href="#wrapper">[top]</a></small>\r\n\r\n<hr />\r\n\r\n<h2 id="paragraph">Paragraph</h2>\r\nLorem ipsum dolor sit amet, <a title="test link" href="#">test link</a> adipiscing elit. Nullam dignissim convallis est. Quisque aliquam. Donec faucibus. Nunc iaculis suscipit dui. Nam sit amet sem. Aliquam libero nisi, imperdiet at, tincidunt nec, gravida vehicula, nisl. Praesent mattis, massa quis luctus fermentum, turpis mi volutpat justo, eu volutpat enim diam eget metus. Maecenas ornare tortor. Donec sed tellus eget sapien fringilla nonummy. Mauris a ante. Suspendisse quam sem, consequat at, commodo vitae, feugiat in, nunc. Morbi imperdiet augue quis tellus.\r\n\r\nLorem ipsum dolor sit amet, <em>emphasis</em> consectetuer adipiscing elit. Nullam dignissim convallis est. Quisque aliquam. Donec faucibus. Nunc iaculis suscipit dui. Nam sit amet sem. Aliquam libero nisi, imperdiet at, tincidunt nec, gravida vehicula, nisl. Praesent mattis, massa quis luctus fermentum, turpis mi volutpat justo, eu volutpat enim diam eget metus. Maecenas ornare tortor. Donec sed tellus eget sapien fringilla nonummy. Mauris a ante. Suspendisse quam sem, consequat at, commodo vitae, feugiat in, nunc. Morbi imperdiet augue quis tellus.\r\n\r\n<small><a href="#wrapper">[top]</a></small>\r\n\r\n<hr />\r\n\r\n<h2 id="list_types">List Types</h2>\r\n<h3>Definition List</h3>\r\n<dl><dt>Definition List Title</dt><dd>This is a definition list division.</dd></dl>\r\n<h3>Ordered List</h3>\r\n<ol>\r\n	<li>List Item 1</li>\r\n	<li>List Item 2</li>\r\n	<li>List Item 3</li>\r\n</ol>\r\n<h3>Unordered List</h3>\r\n<ul>\r\n	<li>List Item 1</li>\r\n	<li>List Item 2</li>\r\n	<li>List Item 3</li>\r\n</ul>\r\n<small><a href="#wrapper">[top]</a></small>\r\n\r\n<hr />\r\n\r\n<h2 id="form_elements">Forms</h2>\r\n<fieldset><legend>Legend</legend>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nullam dignissim convallis est. Quisque aliquam. Donec faucibus. Nunc iaculis suscipit dui. Nam sit amet sem. Aliquam libero nisi, imperdiet at, tincidunt nec, gravida vehicula, nisl. Praesent mattis, massa quis luctus fermentum, turpis mi volutpat justo, eu volutpat enim diam eget metus.\r\n\r\n<form>\r\n<h2>Form Element</h2>\r\nLorem ipsum dolor sit amet, consectetuer adipiscing elit. Nullam dignissim convallis est. Quisque aliquam. Donec faucibus. Nunc iaculis suscipit dui.\r\n\r\n<label for="text_field">Text Field:</label>\r\n\r\n<input id="text_field" type="text" /><label for="text_area">Text Area:</label>\r\n<textarea id="text_area"></textarea>\r\n\r\n<label for="select_element">Select Element:</label>\r\n\r\n<select name="select_element"> <optgroup label="Option Group 1"> <option value="1">Option 1</option> <option value="2">Option 2</option> <option value="3">Option 3</option></optgroup></select>&nbsp;\r\n<select name="select_element"> <optgroup label="Option Group 2"> <option value="1">Option 1</option> <option value="2">Option 2</option> <option value="3">Option 3</option></optgroup></select>&nbsp;\r\n<label for="radio_buttons">Radio Buttons:</label>\r\n\r\n<input class="radio" type="radio" name="radio_button" value="radio_1" /> Radio 1 <input class="radio" type="radio" name="radio_button" value="radio_2" /> Radio 2 <input class="radio" type="radio" name="radio_button" value="radio_3" />Radio 3<label for="checkboxes">Checkboxes:</label>\r\n\r\n<input class="checkbox" type="checkbox" name="checkboxes" value="check_1" /> Radio 1 <input class="checkbox" type="checkbox" name="checkboxes" value="check_2" /> Radio 2 <input class="checkbox" type="checkbox" name="checkboxes" value="check_3" />Radio 3<label for="password">Password:</label>\r\n\r\n<input class="password" type="password" name="password" /><label for="file">File Input:</label>\r\n\r\n<input class="file" type="file" name="file" /> <input class="button" type="reset" value="Clear" /> <input class="button" type="submit" value="Submit" /></form></fieldset>\r\n<small><a href="#wrapper">[top]</a></small>\r\n\r\n<hr />\r\n\r\n<h2 id="tables">Tables</h2>\r\n<table cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr>\r\n<th>Table Header 1</th>\r\n<th>Table Header 2</th>\r\n<th>Table Header 3</th>\r\n</tr>\r\n<tr>\r\n<td>Division 1</td>\r\n<td>Division 2</td>\r\n<td>Division 3</td>\r\n</tr>\r\n<tr class="even">\r\n<td>Division 1</td>\r\n<td>Division 2</td>\r\n<td>Division 3</td>\r\n</tr>\r\n<tr>\r\n<td>Division 1</td>\r\n<td>Division 2</td>\r\n<td>Division 3</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<small><a href="#wrapper">[top]</a></small>\r\n\r\n', 'About Us', '', 'inherit', 'closed', 'closed', '', '178-revision-v1', '', '', '2016-08-02 05:45:32', '2016-08-02 05:45:32', '', 178, 'http://tedsmithdemo.com/178-revision-v1/', 0, 'revision', '', 0),
(236, 1, '2016-08-02 06:11:36', '2016-08-02 06:11:36', '<h2>Texans have been represented by the Ted Smith Law Group for over 43 years.</h2>\nSuspendisse eu lacinia enim, vel pellentesque diam. Pellentesque feu\ngiat a massa ac iaculis. Aliquam erat volutpat. Aliquam non quam luctus, tincidunt urna malesuada, convallis risus. Suspendisse tincidunt vehicula ultrices. Sed congue elit pretium, fringilla neque ac, imperdiet nisl. In posuere eros pellentesque porttitor varius. Aenean aliquet luctus augue id pulvinar. Cras ac pellentesque ante. Nam tempor sapien eu enim mollis, ac tincidunt nisl semper. Etiam at tortor nec sapien euismod gravida. Proin sollicitudin varius nisi a lacinia. Proin vestibulum eget augue et ultricies. Aenean cursus tristique ante ac sollicitudin.\n\nNullam dapibus augue sed lacus tempus lacinia. Proin vitae blandit tortor, eget posuere nibh. Aenean consectetur, nulla sed aliquet malesuada, nibh arcu aliquet ipsum, nec bibendum est nisl a lacus. Maecenas quis elit laoreet, convallis neque eu, ullamcorper arcu.\n\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean ult ricies risus quis viverra scelerisque. Suspendisse eu lacinia enim, vel pelle ntesque diam. Pellentesque feugiat a massa ac iaculis. Aliquam erat volutpat. Aliquam non quam luctus, tincidunt urna malesuada, convallis risus. Suspendisse tincidunt vehicula ultrices. Sed congue elit pretium, fringilla neque ac, imperdiet nisl. In posuere eros pellentesque porttitor varius. Aenean aliquet luctus augue id pulvinar. Cras ac pellentesque.\n<h2></h2>\n<h2>Texans have been represented by the Ted Smith Law Group for over 43 years.\n\nNam tempor sapien eu enim mollis, ac tincidunt nisl semper. Etiam at tortor nec sapien euismod gravida. Proin sollicitudin varius nisi a lacinia. Proin vestibulum eget augue et ultricies. Aenean cursus tristique ante ac sollicitudin. Nullam dapibus augue sed lacus tempus lacinia. Proin vitae blandit tortor, eget posuere nibh. Aenean consectetur, nulla sed aliquet malesuada, nibh arcu aliquet ipsum, nec bibendum est nisl a lacus.</h2>', 'About Us', '', 'inherit', 'closed', 'closed', '', '178-autosave-v1', '', '', '2016-08-02 06:11:36', '2016-08-02 06:11:36', '', 178, 'http://tedsmithdemo.com/178-autosave-v1/', 0, 'revision', '', 0),
(237, 1, '2016-08-02 06:11:58', '2016-08-02 06:11:58', '<h2>Texans have been represented by the Ted Smith Law Group for over 43 years.</h2>\r\nSuspendisse eu lacinia enim, vel pellentesque diam. Pellentesque feu\r\ngiat a massa ac iaculis. Aliquam erat volutpat. Aliquam non quam luctus, tincidunt urna malesuada, convallis risus. Suspendisse tincidunt vehicula ultrices. Sed congue elit pretium, fringilla neque ac, imperdiet nisl. In posuere eros pellentesque porttitor varius. Aenean aliquet luctus augue id pulvinar. Cras ac pellentesque ante. Nam tempor sapien eu enim mollis, ac tincidunt nisl semper. Etiam at tortor nec sapien euismod gravida. Proin sollicitudin varius nisi a lacinia. Proin vestibulum eget augue et ultricies. Aenean cursus tristique ante ac sollicitudin.\r\n\r\nNullam dapibus augue sed lacus tempus lacinia. Proin vitae blandit tortor, eget posuere nibh. Aenean consectetur, nulla sed aliquet malesuada, nibh arcu aliquet ipsum, nec bibendum est nisl a lacus. Maecenas quis elit laoreet, convallis neque eu, ullamcorper arcu.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean ult ricies risus quis viverra scelerisque. Suspendisse eu lacinia enim, vel pelle ntesque diam. Pellentesque feugiat a massa ac iaculis. Aliquam erat volutpat. Aliquam non quam luctus, tincidunt urna malesuada, convallis risus. Suspendisse tincidunt vehicula ultrices. Sed congue elit pretium, fringilla neque ac, imperdiet nisl. In posuere eros pellentesque porttitor varius. Aenean aliquet luctus augue id pulvinar. Cras ac pellentesque.\r\n\r\n<h2>Texans have been represented by the Ted Smith Law Group for over 43 years.</h2>\r\n\r\nNam tempor sapien eu enim mollis, ac tincidunt nisl semper. Etiam at tortor nec sapien euismod gravida. Proin sollicitudin varius nisi a lacinia. Proin vestibulum eget augue et ultricies. Aenean cursus tristique ante ac sollicitudin. Nullam dapibus augue sed lacus tempus lacinia. Proin vitae blandit tortor, eget posuere nibh. Aenean consectetur, nulla sed aliquet malesuada, nibh arcu aliquet ipsum, nec bibendum est nisl a lacus.', 'About Us', '', 'inherit', 'closed', 'closed', '', '178-revision-v1', '', '', '2016-08-02 06:11:58', '2016-08-02 06:11:58', '', 178, 'http://tedsmithdemo.com/178-revision-v1/', 0, 'revision', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_form`
#

DROP TABLE IF EXISTS `wp_rg_form`;


#
# Table structure of table `wp_rg_form`
#

CREATE TABLE `wp_rg_form` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `date_created` datetime NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `is_trash` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_rg_form`
#
INSERT INTO `wp_rg_form` ( `id`, `title`, `date_created`, `is_active`, `is_trash`) VALUES
(1, 'Ted Smith Free Consultation', '2016-07-12 18:05:29', 1, 0) ;

#
# End of data contents of table `wp_rg_form`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_form_meta`
#

DROP TABLE IF EXISTS `wp_rg_form_meta`;


#
# Table structure of table `wp_rg_form_meta`
#

CREATE TABLE `wp_rg_form_meta` (
  `form_id` mediumint(8) unsigned NOT NULL,
  `display_meta` longtext COLLATE utf8_unicode_ci,
  `entries_grid_meta` longtext COLLATE utf8_unicode_ci,
  `confirmations` longtext COLLATE utf8_unicode_ci,
  `notifications` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_rg_form_meta`
#
INSERT INTO `wp_rg_form_meta` ( `form_id`, `display_meta`, `entries_grid_meta`, `confirmations`, `notifications`) VALUES
(1, '{"title":"Ted Smith Free Consultation","description":"<span class=\\"description\\">Fill out the form to schedule a free consultation. We will contact you within 24 hours about your&nbsp;case.<\\/span>\\r\\n<span class=\\"sub_description\\">*All fields required<\\/span>","labelPlacement":"top_label","descriptionPlacement":"below","button":{"type":"text","text":"Submit","imageUrl":""},"fields":[{"type":"text","id":1,"label":"First Name","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"First Name *","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"inputMask":false,"inputMaskValue":"","allowsPrepopulate":false,"formId":1,"pageNumber":1,"description":"","inputType":"","cssClass":"","inputName":"","adminOnly":false,"noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","displayOnly":""},{"type":"text","id":2,"label":"Last Name*","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Last Name*","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"inputMask":false,"inputMaskValue":"","allowsPrepopulate":false,"formId":1,"pageNumber":1,"description":"","inputType":"","cssClass":"","inputName":"","adminOnly":false,"noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","displayOnly":"","useRichTextEditor":false},{"type":"phone","id":3,"label":"Phone","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"phoneFormat":"standard","labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Number*","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"inputMask":false,"inputMaskValue":"","allowsPrepopulate":false,"formId":1,"pageNumber":1,"description":"","inputType":"","cssClass":"","inputName":"","adminOnly":false,"noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","displayOnly":"","form_id":""},{"type":"email","id":4,"label":"Email","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Email*","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"inputMask":false,"inputMaskValue":"","allowsPrepopulate":false,"emailConfirmEnabled":false,"formId":1,"pageNumber":1,"description":"","inputType":"","cssClass":"","inputName":"","adminOnly":false,"noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","displayOnly":""},{"type":"textarea","id":5,"label":"Describe Your Case","adminLabel":"","isRequired":true,"size":"medium","errorMessage":"","inputs":null,"labelPlacement":"","descriptionPlacement":"","subLabelPlacement":"","placeholder":"Describe Your Case*","multipleFiles":false,"maxFiles":"","calculationFormula":"","calculationRounding":"","enableCalculation":"","disableQuantity":false,"displayAllCategories":false,"inputMask":false,"inputMaskValue":"","allowsPrepopulate":false,"formId":1,"pageNumber":1,"description":"","inputType":"","cssClass":"","inputName":"","adminOnly":false,"noDuplicates":false,"defaultValue":"","choices":"","conditionalLogic":"","displayOnly":""}],"version":"2.0.2","id":1,"useCurrentUserAsAuthor":true,"postContentTemplateEnabled":false,"postTitleTemplateEnabled":false,"postTitleTemplate":"","postContentTemplate":"","lastPageButton":null,"pagination":null,"firstPageCssClass":null,"subLabelPlacement":"below","cssClass":"","enableHoneypot":false,"enableAnimation":false,"save":{"enabled":false,"button":{"type":"link","text":"Save and Continue Later"}},"limitEntries":false,"limitEntriesCount":"","limitEntriesPeriod":"","limitEntriesMessage":"","scheduleForm":false,"scheduleStart":"","scheduleStartHour":"","scheduleStartMinute":"","scheduleStartAmpm":"","scheduleEnd":"","scheduleEndHour":"","scheduleEndMinute":"","scheduleEndAmpm":"","schedulePendingMessage":"","scheduleMessage":"","requireLogin":false,"requireLoginMessage":"","notifications":{"5785316946bc1":{"id":"5785316946bc1","to":"{admin_email}","name":"Admin Notification","event":"form_submission","toType":"email","subject":"New submission from {form_title}","message":"{all_fields}"}},"confirmations":{"578531694c5ed":{"id":"578531694c5ed","name":"Default Confirmation","isDefault":true,"type":"message","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":"","queryString":""}}}', NULL, '{"578531694c5ed":{"id":"578531694c5ed","name":"Default Confirmation","isDefault":true,"type":"message","message":"Thanks for contacting us! We will get in touch with you shortly.","url":"","pageId":"","queryString":""}}', '{"5785316946bc1":{"id":"5785316946bc1","to":"{admin_email}","name":"Admin Notification","event":"form_submission","toType":"email","subject":"New submission from {form_title}","message":"{all_fields}"}}') ;

#
# End of data contents of table `wp_rg_form_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_form_view`
#

DROP TABLE IF EXISTS `wp_rg_form_view`;


#
# Table structure of table `wp_rg_form_view`
#

CREATE TABLE `wp_rg_form_view` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` char(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `count` mediumint(8) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `date_created` (`date_created`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_rg_form_view`
#
INSERT INTO `wp_rg_form_view` ( `id`, `form_id`, `date_created`, `ip`, `count`) VALUES
(1, 1, '2016-07-12 18:10:07', '::1', 149),
(2, 1, '2016-07-13 18:10:11', '::1', 186),
(3, 1, '2016-07-14 20:12:40', '::1', 106),
(4, 1, '2016-07-15 20:14:42', '::1', 227),
(5, 1, '2016-07-18 15:33:33', '::1', 277),
(6, 1, '2016-07-19 15:39:11', '::1', 101),
(7, 1, '2016-07-20 15:41:06', '::1', 25),
(8, 1, '2016-07-22 15:52:40', '::1', 16),
(9, 1, '2016-07-25 16:35:55', '::1', 31),
(10, 1, '2016-07-28 17:23:00', '::1', 79),
(11, 1, '2016-07-29 17:30:02', '::1', 5),
(12, 1, '2016-08-01 15:31:19', '::1', 267) ;

#
# End of data contents of table `wp_rg_form_view`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_incomplete_submissions`
#

DROP TABLE IF EXISTS `wp_rg_incomplete_submissions`;


#
# Table structure of table `wp_rg_incomplete_submissions`
#

CREATE TABLE `wp_rg_incomplete_submissions` (
  `uuid` char(32) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `form_id` mediumint(8) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `ip` varchar(39) COLLATE utf8_unicode_ci NOT NULL,
  `source_url` longtext COLLATE utf8_unicode_ci NOT NULL,
  `submission` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `form_id` (`form_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_rg_incomplete_submissions`
#

#
# End of data contents of table `wp_rg_incomplete_submissions`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead`
#

DROP TABLE IF EXISTS `wp_rg_lead`;


#
# Table structure of table `wp_rg_lead`
#

CREATE TABLE `wp_rg_lead` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL,
  `post_id` bigint(20) unsigned DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `is_starred` tinyint(1) NOT NULL DEFAULT '0',
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `ip` varchar(39) COLLATE utf8_unicode_ci NOT NULL,
  `source_url` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_agent` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `currency` varchar(5) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payment_status` varchar(15) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `payment_amount` decimal(19,2) DEFAULT NULL,
  `payment_method` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `transaction_id` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `is_fulfilled` tinyint(1) DEFAULT NULL,
  `created_by` bigint(20) unsigned DEFAULT NULL,
  `transaction_type` tinyint(1) DEFAULT NULL,
  `status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_rg_lead`
#
INSERT INTO `wp_rg_lead` ( `id`, `form_id`, `post_id`, `date_created`, `is_starred`, `is_read`, `ip`, `source_url`, `user_agent`, `currency`, `payment_status`, `payment_date`, `payment_amount`, `payment_method`, `transaction_id`, `is_fulfilled`, `created_by`, `transaction_type`, `status`) VALUES
(1, 1, NULL, '2016-07-12 21:02:10', 0, 0, '::1', 'http://tedsmithdemo.com/?ckcachecontrol=1468357126', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', 'USD', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active'),
(2, 1, NULL, '2016-07-12 21:10:49', 0, 0, '::1', 'http://tedsmithdemo.com/?ckcachecontrol=1468357126', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', 'USD', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active'),
(3, 1, NULL, '2016-07-12 21:14:15', 0, 0, '::1', 'http://tedsmithdemo.com/?ckcachecontrol=1468357126', 'Mozilla/5.0 (iPhone; CPU iPhone OS 9_3_2 like Mac OS X) AppleWebKit/601.1.46 (KHTML, like Gecko) Version/9.0 Mobile/13F69 Safari/601.1', 'USD', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active'),
(4, 1, NULL, '2016-07-13 16:42:42', 0, 0, '::1', 'http://tedsmithdemo.com/?ckcachecontrol=1468427912', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', 'USD', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active'),
(5, 1, NULL, '2016-07-19 21:02:19', 0, 0, '::1', 'http://tedsmithdemo.com/?ckcachecontrol=1468962111', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', 'USD', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active'),
(6, 1, NULL, '2016-07-19 21:09:45', 0, 0, '::1', 'http://tedsmithdemo.com/?ckcachecontrol=1468962111', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0', 'USD', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'active') ;

#
# End of data contents of table `wp_rg_lead`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_detail`
#

DROP TABLE IF EXISTS `wp_rg_lead_detail`;


#
# Table structure of table `wp_rg_lead_detail`
#

CREATE TABLE `wp_rg_lead_detail` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `form_id` mediumint(8) unsigned NOT NULL,
  `field_number` float NOT NULL,
  `value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `form_id` (`form_id`),
  KEY `lead_id` (`lead_id`),
  KEY `lead_field_number` (`lead_id`,`field_number`),
  KEY `lead_field_value` (`value`(191))
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_rg_lead_detail`
#
INSERT INTO `wp_rg_lead_detail` ( `id`, `lead_id`, `form_id`, `field_number`, `value`) VALUES
(1, 1, 1, '1', 'Garrett'),
(2, 1, 1, '2', 'Cullen'),
(3, 1, 1, '3', '(111) 111-1111'),
(4, 1, 1, '4', 'garrett@hr.com'),
(5, 1, 1, '5', 'dsihafois'),
(6, 2, 1, '1', 'test'),
(7, 2, 1, '2', 'test'),
(8, 2, 1, '3', '(111) 111-1111'),
(9, 2, 1, '4', 'test@test.com'),
(10, 2, 1, '5', 'test'),
(11, 3, 1, '1', 'TeSt'),
(12, 3, 1, '2', 'Test'),
(13, 3, 1, '3', '(111) 111-1111'),
(14, 3, 1, '4', 'TeSt@test.com'),
(15, 3, 1, '5', 'Test'),
(16, 4, 1, '1', 'test'),
(17, 4, 1, '2', 'test'),
(18, 4, 1, '3', '(111) 111-1111'),
(19, 4, 1, '4', 'test@test.com'),
(20, 4, 1, '5', 'test'),
(21, 5, 1, '1', 'test'),
(22, 5, 1, '2', 'test'),
(23, 5, 1, '3', '(111) 111-1111'),
(24, 5, 1, '4', 'test@test.com'),
(25, 5, 1, '5', 'test'),
(26, 6, 1, '1', 'test'),
(27, 6, 1, '2', 'test'),
(28, 6, 1, '3', '(111) 111-1111'),
(29, 6, 1, '4', 'test@test.com'),
(30, 6, 1, '5', 'eFAWEF') ;

#
# End of data contents of table `wp_rg_lead_detail`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_detail_long`
#

DROP TABLE IF EXISTS `wp_rg_lead_detail_long`;


#
# Table structure of table `wp_rg_lead_detail_long`
#

CREATE TABLE `wp_rg_lead_detail_long` (
  `lead_detail_id` bigint(20) unsigned NOT NULL,
  `value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`lead_detail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_rg_lead_detail_long`
#

#
# End of data contents of table `wp_rg_lead_detail_long`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_meta`
#

DROP TABLE IF EXISTS `wp_rg_lead_meta`;


#
# Table structure of table `wp_rg_lead_meta`
#

CREATE TABLE `wp_rg_lead_meta` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `form_id` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `lead_id` bigint(20) unsigned NOT NULL,
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`id`),
  KEY `meta_key` (`meta_key`(191)),
  KEY `lead_id` (`lead_id`),
  KEY `form_id_meta_key` (`form_id`,`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_rg_lead_meta`
#

#
# End of data contents of table `wp_rg_lead_meta`
# --------------------------------------------------------



#
# Delete any existing table `wp_rg_lead_notes`
#

DROP TABLE IF EXISTS `wp_rg_lead_notes`;


#
# Table structure of table `wp_rg_lead_notes`
#

CREATE TABLE `wp_rg_lead_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `lead_id` int(10) unsigned NOT NULL,
  `user_name` varchar(250) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `date_created` datetime NOT NULL,
  `value` longtext COLLATE utf8_unicode_ci,
  `note_type` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `lead_id` (`lead_id`),
  KEY `lead_user_key` (`lead_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_rg_lead_notes`
#

#
# End of data contents of table `wp_rg_lead_notes`
# --------------------------------------------------------



#
# Delete any existing table `wp_simple_history`
#

DROP TABLE IF EXISTS `wp_simple_history`;


#
# Table structure of table `wp_simple_history`
#

CREATE TABLE `wp_simple_history` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `date` datetime NOT NULL,
  `logger` varchar(30) DEFAULT NULL,
  `level` varchar(20) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `occasionsID` varchar(32) DEFAULT NULL,
  `initiator` varchar(16) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `loggerdate` (`logger`,`date`)
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_simple_history`
#
INSERT INTO `wp_simple_history` ( `id`, `date`, `logger`, `level`, `message`, `occasionsID`, `initiator`) VALUES
(1, '2016-07-12 18:02:48', 'SimplePluginLogger', 'info', 'Installed plugin "{plugin_name}"', '5739ab176bc6a05f4d30b22f832e66de', 'wp_user'),
(2, '2016-07-12 18:02:48', 'SimplePluginLogger', 'info', 'Activated plugin "{plugin_name}"', '8ebd11a5eab71eec12d13fa32a821363', 'wp_user'),
(3, '2016-07-12 18:02:48', 'SimpleLogger', 'info', 'Because Simple History was just recently installed, this feed does not contain much events yet. But keep the plugin activated and soon you will see detailed information about page edits, plugin updates, user logins, and much more.', '1c6ed1ff4a97400596b011813faa932f', 'wp'),
(4, '2016-07-12 18:02:48', 'SimpleLogger', 'info', 'Welcome to Simple History!\n\nThis is the main history feed. It will contain events that this plugin has logged.', '0c4babaacbe315745cbb536eaa41278c', 'wp'),
(5, '2016-07-12 18:02:49', 'SimplePluginLogger', 'info', 'Installed plugin "{plugin_name}"', '5739ab176bc6a05f4d30b22f832e66de', 'wp'),
(6, '2016-07-12 18:02:49', 'SimplePluginLogger', 'info', 'Activated plugin "{plugin_name}"', '8ebd11a5eab71eec12d13fa32a821363', 'wp'),
(7, '2016-07-12 18:03:24', 'SimplePluginLogger', 'info', 'Activated plugin "{plugin_name}"', '4df412e1063c16afe86de0469d16dd19', 'wp_user'),
(8, '2016-07-13 20:50:18', 'SimpleMenuLogger', 'info', 'Updated menu locations', '57c57aa849b0a7202374c7be8f7d4ac2', 'wp_user'),
(9, '2016-07-13 20:50:24', 'SimpleMenuLogger', 'info', 'Updated menu locations', '57c57aa849b0a7202374c7be8f7d4ac2', 'wp_user'),
(10, '2016-07-13 20:54:23', 'SimpleMenuLogger', 'info', 'Edited menu "{menu_name}"', 'ecaf570a2ce7222a11428ae2800ee3b9', 'wp_user'),
(11, '2016-07-13 20:54:23', 'SimpleCategoriesLogger', 'info', 'Edited term "{to_term_name}" in taxonomy "{to_term_taxonomy}"', 'a05e99f45bdc1614c610eb2d97c506c8', 'wp_user'),
(12, '2016-07-13 20:54:35', 'SimpleMenuLogger', 'info', 'Edited menu "{menu_name}"', 'ecaf570a2ce7222a11428ae2800ee3b9', 'wp_user'),
(13, '2016-07-13 20:54:35', 'SimpleCategoriesLogger', 'info', 'Edited term "{to_term_name}" in taxonomy "{to_term_taxonomy}"', 'a05e99f45bdc1614c610eb2d97c506c8', 'wp_user'),
(14, '2016-07-13 20:55:48', 'SimpleMenuLogger', 'info', 'Edited menu "{menu_name}"', '6c5ebf8e3d83a02db0ae01cef34b4d1c', 'wp_user'),
(15, '2016-07-13 20:55:48', 'SimpleCategoriesLogger', 'info', 'Edited term "{to_term_name}" in taxonomy "{to_term_taxonomy}"', 'a05e99f45bdc1614c610eb2d97c506c8', 'wp_user'),
(16, '2016-07-13 20:57:10', 'SimpleMenuLogger', 'info', 'Edited menu "{menu_name}"', 'ecaf570a2ce7222a11428ae2800ee3b9', 'wp_user'),
(17, '2016-07-13 20:57:10', 'SimpleCategoriesLogger', 'info', 'Edited term "{to_term_name}" in taxonomy "{to_term_taxonomy}"', 'a05e99f45bdc1614c610eb2d97c506c8', 'wp_user'),
(18, '2016-07-13 20:57:31', 'SimpleMenuLogger', 'info', 'Edited menu "{menu_name}"', 'ecaf570a2ce7222a11428ae2800ee3b9', 'wp_user'),
(19, '2016-07-13 20:57:31', 'SimpleCategoriesLogger', 'info', 'Edited term "{to_term_name}" in taxonomy "{to_term_taxonomy}"', 'a05e99f45bdc1614c610eb2d97c506c8', 'wp_user'),
(20, '2016-07-13 21:00:24', 'SimplePostLogger', 'info', 'Created {post_type} "{post_title}"', '6c7c998c5eb607be65f597e58dd8abe8', 'wp_user'),
(21, '2016-07-13 21:02:31', 'SimpleMenuLogger', 'info', 'Edited menu "{menu_name}"', 'a9afcb2fc6a4927d42c5dbbf7dce7932', 'wp_user'),
(22, '2016-07-13 21:02:31', 'SimpleCategoriesLogger', 'info', 'Edited term "{to_term_name}" in taxonomy "{to_term_taxonomy}"', 'a05e99f45bdc1614c610eb2d97c506c8', 'wp_user'),
(23, '2016-07-13 21:05:53', 'SimpleMenuLogger', 'info', 'Edited menu "{menu_name}"', 'de36e5095a40d43c6ee6e739215c48c2', 'wp_user'),
(24, '2016-07-13 21:05:53', 'SimpleCategoriesLogger', 'info', 'Edited term "{to_term_name}" in taxonomy "{to_term_taxonomy}"', 'a05e99f45bdc1614c610eb2d97c506c8', 'wp_user'),
(25, '2016-07-13 21:08:00', 'SimpleMenuLogger', 'info', 'Edited menu "{menu_name}"', '714ca9e0ca4ed33121bd0aa4289d331e', 'wp_user'),
(26, '2016-07-13 21:08:00', 'SimpleCategoriesLogger', 'info', 'Edited term "{to_term_name}" in taxonomy "{to_term_taxonomy}"', 'a05e99f45bdc1614c610eb2d97c506c8', 'wp_user'),
(27, '2016-07-13 21:14:05', 'SimpleMenuLogger', 'info', 'Edited menu "{menu_name}"', 'ecaf570a2ce7222a11428ae2800ee3b9', 'wp_user'),
(28, '2016-07-13 21:14:06', 'SimpleCategoriesLogger', 'info', 'Edited term "{to_term_name}" in taxonomy "{to_term_taxonomy}"', 'a05e99f45bdc1614c610eb2d97c506c8', 'wp_user'),
(29, '2016-07-13 21:19:52', 'SimpleMenuLogger', 'info', 'Edited menu "{menu_name}"', 'fc0afe9da6b1ee6d5c9f3a71e90f6430', 'wp_user'),
(30, '2016-07-13 21:19:52', 'SimpleCategoriesLogger', 'info', 'Edited term "{to_term_name}" in taxonomy "{to_term_taxonomy}"', 'a05e99f45bdc1614c610eb2d97c506c8', 'wp_user'),
(31, '2016-07-13 21:22:52', 'SimpleMenuLogger', 'info', 'Edited menu "{menu_name}"', 'f040ef15ca4fb9cc3de4cd96b685937c', 'wp_user'),
(32, '2016-07-13 21:22:52', 'SimpleCategoriesLogger', 'info', 'Edited term "{to_term_name}" in taxonomy "{to_term_taxonomy}"', 'a05e99f45bdc1614c610eb2d97c506c8', 'wp_user'),
(33, '2016-07-13 21:24:03', 'SimpleMenuLogger', 'info', 'Edited menu "{menu_name}"', '6c5ebf8e3d83a02db0ae01cef34b4d1c', 'wp_user'),
(34, '2016-07-13 21:24:03', 'SimpleCategoriesLogger', 'info', 'Edited term "{to_term_name}" in taxonomy "{to_term_taxonomy}"', 'a05e99f45bdc1614c610eb2d97c506c8', 'wp_user'),
(35, '2016-07-13 21:24:29', 'SimpleMenuLogger', 'info', 'Edited menu "{menu_name}"', 'ecaf570a2ce7222a11428ae2800ee3b9', 'wp_user'),
(36, '2016-07-13 21:24:29', 'SimpleCategoriesLogger', 'info', 'Edited term "{to_term_name}" in taxonomy "{to_term_taxonomy}"', 'a05e99f45bdc1614c610eb2d97c506c8', 'wp_user'),
(37, '2016-07-13 21:27:24', 'SimpleMenuLogger', 'info', 'Edited menu "{menu_name}"', '3d21a5a4ddfa8119198cfe544c33f372', 'wp_user'),
(38, '2016-07-13 21:27:24', 'SimpleCategoriesLogger', 'info', 'Edited term "{to_term_name}" in taxonomy "{to_term_taxonomy}"', 'a05e99f45bdc1614c610eb2d97c506c8', 'wp_user'),
(39, '2016-07-13 21:28:16', 'SimpleMenuLogger', 'info', 'Edited menu "{menu_name}"', '16d5fea3a2f5cfd10fe8fd36545a9269', 'wp_user'),
(40, '2016-07-13 21:28:16', 'SimpleCategoriesLogger', 'info', 'Edited term "{to_term_name}" in taxonomy "{to_term_taxonomy}"', 'a05e99f45bdc1614c610eb2d97c506c8', 'wp_user'),
(41, '2016-07-13 21:35:01', 'SimpleMenuLogger', 'info', 'Edited menu "{menu_name}"', '6c5ebf8e3d83a02db0ae01cef34b4d1c', 'wp_user'),
(42, '2016-07-13 21:35:01', 'SimpleCategoriesLogger', 'info', 'Edited term "{to_term_name}" in taxonomy "{to_term_taxonomy}"', 'a05e99f45bdc1614c610eb2d97c506c8', 'wp_user'),
(43, '2016-07-13 22:56:03', 'SimplePluginLogger', 'info', 'Updated plugin "{plugin_name}" to {plugin_version} from {plugin_prev_version}', '0d6b772baf7a66e93c9537069c90a0e8', 'wp_user'),
(44, '2016-07-13 22:56:09', 'SimplePluginLogger', 'info', 'Updated plugin "{plugin_name}" to {plugin_version} from {plugin_prev_version}', '9950330341b48983f9a742bdd9d96d93', 'wp_user'),
(45, '2016-07-14 17:28:39', 'SimpleMenuLogger', 'info', 'Edited menu "{menu_name}"', 'cbc91bda35043506e8a7ce4bebbf7bb0', 'wp_user'),
(46, '2016-07-14 17:28:39', 'SimpleCategoriesLogger', 'info', 'Edited term "{to_term_name}" in taxonomy "{to_term_taxonomy}"', 'a05e99f45bdc1614c610eb2d97c506c8', 'wp_user'),
(47, '2016-07-14 17:30:09', 'SimpleMenuLogger', 'info', 'Edited menu "{menu_name}"', '16d5fea3a2f5cfd10fe8fd36545a9269', 'wp_user'),
(48, '2016-07-14 17:30:09', 'SimpleCategoriesLogger', 'info', 'Edited term "{to_term_name}" in taxonomy "{to_term_taxonomy}"', 'a05e99f45bdc1614c610eb2d97c506c8', 'wp_user'),
(49, '2016-07-14 17:52:46', 'SimpleMenuLogger', 'info', 'Edited menu "{menu_name}"', 'f040ef15ca4fb9cc3de4cd96b685937c', 'wp_user'),
(50, '2016-07-14 17:52:46', 'SimpleCategoriesLogger', 'info', 'Edited term "{to_term_name}" in taxonomy "{to_term_taxonomy}"', 'a05e99f45bdc1614c610eb2d97c506c8', 'wp_user'),
(51, '2016-07-18 21:19:35', 'SimpleUserLogger', 'info', 'Logged in', '37b253cb382de6301687b4b63548604b', 'wp_user'),
(52, '2016-07-19 22:51:59', 'SimpleMenuLogger', 'info', 'Edited menu "{menu_name}"', '16eb4272fa78c7cb22f5cef1673091fb', 'wp_user'),
(53, '2016-07-19 22:51:59', 'SimpleCategoriesLogger', 'info', 'Edited term "{to_term_name}" in taxonomy "{to_term_taxonomy}"', 'a05e99f45bdc1614c610eb2d97c506c8', 'wp_user'),
(54, '2016-07-19 22:52:48', 'SimplePostLogger', 'info', 'Created {post_type} "{post_title}"', '3db8b3bcd76cd257133d72d7ca574ca4', 'wp_user'),
(55, '2016-07-19 22:54:00', 'SimpleMenuLogger', 'info', 'Edited menu "{menu_name}"', '977ed747d803b0590e565c04ecc39909', 'wp_user'),
(56, '2016-07-19 22:54:00', 'SimpleCategoriesLogger', 'info', 'Edited term "{to_term_name}" in taxonomy "{to_term_taxonomy}"', 'a05e99f45bdc1614c610eb2d97c506c8', 'wp_user'),
(57, '2016-07-19 22:54:37', 'SimpleMenuLogger', 'info', 'Edited menu "{menu_name}"', 'ecaf570a2ce7222a11428ae2800ee3b9', 'wp_user'),
(58, '2016-07-19 22:54:37', 'SimpleCategoriesLogger', 'info', 'Edited term "{to_term_name}" in taxonomy "{to_term_taxonomy}"', 'a05e99f45bdc1614c610eb2d97c506c8', 'wp_user'),
(59, '2016-08-01 23:21:22', 'SimpleUserLogger', 'info', 'Logged in', '37b253cb382de6301687b4b63548604b', 'wp_user'),
(60, '2016-08-02 03:02:50', 'SimpleUserLogger', 'warning', 'Failed to login with username "{login}" (incorrect password entered)', 'fc19fe068b4a1e111ed26b846cc30560', 'web_user'),
(61, '2016-08-02 03:03:21', 'SimpleUserLogger', 'warning', 'Failed to login with username "{login}" (incorrect password entered)', 'fc19fe068b4a1e111ed26b846cc30560', 'web_user'),
(62, '2016-08-02 03:03:34', 'SimpleUserLogger', 'warning', 'Failed to login with username "{login}" (incorrect password entered)', 'fc19fe068b4a1e111ed26b846cc30560', 'web_user'),
(63, '2016-08-02 03:03:44', 'SimpleUserLogger', 'warning', 'Failed to login with username "{login}" (incorrect password entered)', 'fc19fe068b4a1e111ed26b846cc30560', 'web_user'),
(64, '2016-08-02 03:04:02', 'SimpleUserLogger', 'warning', 'Failed to login with username "{login}" (incorrect password entered)', 'fc19fe068b4a1e111ed26b846cc30560', 'web_user'),
(65, '2016-08-02 03:04:46', 'SimpleUserLogger', 'warning', 'Failed to login with username "{login}" (incorrect password entered)', 'fc19fe068b4a1e111ed26b846cc30560', 'web_user'),
(66, '2016-08-02 03:05:20', 'SimpleUserLogger', 'warning', 'Failed to login with username "{login}" (incorrect password entered)', 'fc19fe068b4a1e111ed26b846cc30560', 'web_user'),
(67, '2016-08-02 03:06:33', 'SimpleUserLogger', 'warning', 'Failed to login with username "{login}" (incorrect password entered)', 'fc19fe068b4a1e111ed26b846cc30560', 'web_user'),
(68, '2016-08-02 03:10:26', 'SimpleUserLogger', 'info', 'Logged in', '37b253cb382de6301687b4b63548604b', 'wp_user'),
(69, '2016-08-02 03:10:59', 'SimpleUserLogger', 'info', 'Logged out', 'abfee0819f198c2782490c4ccb735367', 'wp_user'),
(70, '2016-08-02 05:26:11', 'SimpleUserLogger', 'info', 'Logged in', '37b253cb382de6301687b4b63548604b', 'wp_user'),
(71, '2016-08-02 05:26:28', 'SimplePluginLogger', 'info', 'Updated plugin "{plugin_name}" to {plugin_version} from {plugin_prev_version}', '1e144413708d6c740484bbfb91b27a64', 'wp_user'),
(72, '2016-08-02 05:26:37', 'SimplePluginLogger', 'info', 'Updated plugin "{plugin_name}" to {plugin_version} from {plugin_prev_version}', 'e1c914cffdf3400b4a458300722ed803', 'wp_user'),
(73, '2016-08-02 05:26:45', 'SimplePluginLogger', 'info', 'Updated plugin "{plugin_name}" to {plugin_version} from {plugin_prev_version}', '433cefe803b8f721fcf42d652635c3d1', 'wp_user'),
(74, '2016-08-02 05:26:56', 'SimplePluginLogger', 'info', 'Updated plugin "{plugin_name}" to {plugin_version} from {plugin_prev_version}', '27a2749abb15890133caca55d3ac93c4', 'wp_user'),
(75, '2016-08-02 05:30:34', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '7701ae95045d7b123470c851ba9e1ef8', 'wp_user'),
(76, '2016-08-02 05:31:05', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '7701ae95045d7b123470c851ba9e1ef8', 'wp_user'),
(77, '2016-08-02 05:32:37', 'SimpleUserLogger', 'info', 'Logged out', 'abfee0819f198c2782490c4ccb735367', 'wp_user'),
(78, '2016-08-02 05:43:34', 'SimpleUserLogger', 'warning', 'Failed to login with username "{failed_username}" (username does not exist)', 'fc19fe068b4a1e111ed26b846cc30560', 'web_user'),
(79, '2016-08-02 05:43:45', 'SimpleUserLogger', 'info', 'Logged in', '37b253cb382de6301687b4b63548604b', 'wp_user'),
(80, '2016-08-02 05:45:32', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '7701ae95045d7b123470c851ba9e1ef8', 'wp_user'),
(81, '2016-08-02 05:45:50', 'SimpleUserLogger', 'info', 'Logged out', 'abfee0819f198c2782490c4ccb735367', 'wp_user'),
(82, '2016-08-02 06:09:39', 'SimpleUserLogger', 'info', 'Logged in', '37b253cb382de6301687b4b63548604b', 'wp_user'),
(83, '2016-08-02 06:11:58', 'SimplePostLogger', 'info', 'Updated {post_type} "{post_title}"', '7701ae95045d7b123470c851ba9e1ef8', 'wp_user'),
(84, '2016-08-02 06:13:30', 'SimpleUserLogger', 'info', 'Logged out', 'abfee0819f198c2782490c4ccb735367', 'wp_user'),
(85, '2016-08-02 06:14:44', 'SimpleUserLogger', 'info', 'Logged in', '37b253cb382de6301687b4b63548604b', 'wp_user') ;

#
# End of data contents of table `wp_simple_history`
# --------------------------------------------------------



#
# Delete any existing table `wp_simple_history_contexts`
#

DROP TABLE IF EXISTS `wp_simple_history_contexts`;


#
# Table structure of table `wp_simple_history_contexts`
#

CREATE TABLE `wp_simple_history_contexts` (
  `context_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `history_id` bigint(20) unsigned NOT NULL,
  `key` varchar(255) DEFAULT NULL,
  `value` longtext,
  PRIMARY KEY (`context_id`),
  KEY `history_id` (`history_id`),
  KEY `key` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=922 DEFAULT CHARSET=utf8;


#
# Data contents of table `wp_simple_history_contexts`
#
INSERT INTO `wp_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(1, 1, 'plugin_name', 'Simple History'),
(2, 1, 'plugin_description', 'Plugin that logs various things that occur in WordPress and then presents those events in a very nice GUI.'),
(3, 1, 'plugin_url', 'http://simple-history.com'),
(4, 1, 'plugin_version', '2.7.3'),
(5, 1, 'plugin_author', 'Pär Thernström'),
(6, 1, '_message_key', 'plugin_installed'),
(7, 1, '_user_id', '1'),
(8, 1, '_user_login', 'highrank'),
(9, 1, '_user_email', 'ilawyerwp@gmail.com'),
(10, 1, '_server_remote_addr', '::1'),
(11, 1, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/update.php?action=install-plugin&plugin=simple-history&_wpnonce=f03792ae56'),
(12, 2, 'plugin_name', 'Simple History'),
(13, 2, 'plugin_description', 'Plugin that logs various things that occur in WordPress and then presents those events in a very nice GUI.'),
(14, 2, 'plugin_url', 'http://simple-history.com'),
(15, 2, 'plugin_version', '2.7.3'),
(16, 2, 'plugin_author', 'Pär Thernström'),
(17, 2, 'plugin_slug', 'simple-history'),
(18, 2, 'plugin_title', '<a href="http://simple-history.com/">Simple History</a>'),
(19, 2, '_message_key', 'plugin_activated'),
(20, 2, '_user_id', '1'),
(21, 2, '_user_login', 'highrank'),
(22, 2, '_user_email', 'ilawyerwp@gmail.com'),
(23, 2, '_server_remote_addr', '::1'),
(24, 2, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/update.php?action=install-plugin&plugin=simple-history&_wpnonce=f03792ae56'),
(25, 3, '_user_id', '1'),
(26, 3, '_user_login', 'highrank'),
(27, 3, '_user_email', 'ilawyerwp@gmail.com'),
(28, 3, '_server_remote_addr', '::1'),
(29, 3, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/update.php?action=install-plugin&plugin=simple-history&_wpnonce=f03792ae56'),
(30, 4, '_user_id', '1'),
(31, 4, '_user_login', 'highrank'),
(32, 4, '_user_email', 'ilawyerwp@gmail.com'),
(33, 4, '_server_remote_addr', '::1'),
(34, 4, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/update.php?action=install-plugin&plugin=simple-history&_wpnonce=f03792ae56'),
(35, 5, 'plugin_name', 'Simple History'),
(36, 5, 'plugin_description', 'Plugin that logs various things that occur in WordPress and then presents those events in a very nice GUI.'),
(37, 5, 'plugin_url', 'http://simple-history.com'),
(38, 5, 'plugin_version', '2.7.3'),
(39, 5, 'plugin_author', 'Pär Thernström'),
(40, 5, '_message_key', 'plugin_installed'),
(41, 5, '_wp_cron_running', 'true'),
(42, 5, '_server_remote_addr', '::1'),
(43, 6, 'plugin_name', 'Simple History'),
(44, 6, 'plugin_description', 'Plugin that logs various things that occur in WordPress and then presents those events in a very nice GUI.'),
(45, 6, 'plugin_url', 'http://simple-history.com'),
(46, 6, 'plugin_version', '2.7.3'),
(47, 6, 'plugin_author', 'Pär Thernström'),
(48, 6, 'plugin_slug', 'simple-history'),
(49, 6, 'plugin_title', '<a href="http://simple-history.com/">Simple History</a>'),
(50, 6, '_message_key', 'plugin_activated'),
(51, 6, '_wp_cron_running', 'true'),
(52, 6, '_server_remote_addr', '::1'),
(53, 7, 'plugin_name', 'Gravity Forms'),
(54, 7, 'plugin_slug', 'gravityforms'),
(55, 7, 'plugin_title', '<a href="http://www.gravityforms.com">Gravity Forms</a>'),
(56, 7, 'plugin_description', 'Easily create web forms and manage form entries within the WordPress admin. <cite>By <a href="http://www.rocketgenius.com">rocketgenius</a>.</cite>'),
(57, 7, 'plugin_author', '<a href="http://www.rocketgenius.com">rocketgenius</a>'),
(58, 7, 'plugin_version', '1.9.19'),
(59, 7, 'plugin_url', 'http://www.gravityforms.com'),
(60, 7, '_message_key', 'plugin_activated'),
(61, 7, '_user_id', '1'),
(62, 7, '_user_login', 'highrank'),
(63, 7, '_user_email', 'ilawyerwp@gmail.com'),
(64, 7, '_server_remote_addr', '::1'),
(65, 7, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/plugins.php?plugin_status=all&paged=1&s'),
(66, 8, 'menu_locations', '{"primary":"3"}'),
(67, 8, '_message_key', 'edited_menu_locations'),
(68, 8, '_user_id', '1'),
(69, 8, '_user_login', 'highrank'),
(70, 8, '_user_email', 'ilawyerwp@gmail.com'),
(71, 8, '_server_remote_addr', '::1'),
(72, 8, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php?action=locations'),
(73, 9, 'menu_locations', '{"primary":"3"}'),
(74, 9, '_message_key', 'edited_menu_locations'),
(75, 9, '_user_id', '1'),
(76, 9, '_user_login', 'highrank'),
(77, 9, '_user_email', 'ilawyerwp@gmail.com'),
(78, 9, '_server_remote_addr', '::1'),
(79, 9, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php?action=locations'),
(80, 10, 'menu_id', '3'),
(81, 10, 'menu_name', 'MainNav'),
(82, 10, 'menu_items_added', '0'),
(83, 10, 'menu_items_removed', '0'),
(84, 10, '_message_key', 'edited_menu'),
(85, 10, '_user_id', '1'),
(86, 10, '_user_login', 'highrank'),
(87, 10, '_user_email', 'ilawyerwp@gmail.com'),
(88, 10, '_server_remote_addr', '::1'),
(89, 10, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(90, 11, 'term_id', '3'),
(91, 11, 'from_term_name', 'MainNav'),
(92, 11, 'from_term_taxonomy', 'nav_menu'),
(93, 11, 'from_term_slug', ''),
(94, 11, 'to_term_name', 'MainNav'),
(95, 11, 'to_term_taxonomy', 'nav_menu'),
(96, 11, 'to_term_slug', 'null'),
(97, 11, 'to_term_description', ''),
(98, 11, '_message_key', 'edited_term'),
(99, 11, '_user_id', '1'),
(100, 11, '_user_login', 'highrank') ;
INSERT INTO `wp_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(101, 11, '_user_email', 'ilawyerwp@gmail.com'),
(102, 11, '_server_remote_addr', '::1'),
(103, 11, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(104, 12, 'menu_id', '3'),
(105, 12, 'menu_name', 'MainNav'),
(106, 12, 'menu_items_added', '0'),
(107, 12, 'menu_items_removed', '0'),
(108, 12, '_message_key', 'edited_menu'),
(109, 12, '_user_id', '1'),
(110, 12, '_user_login', 'highrank'),
(111, 12, '_user_email', 'ilawyerwp@gmail.com'),
(112, 12, '_server_remote_addr', '::1'),
(113, 12, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(114, 13, 'term_id', '3'),
(115, 13, 'from_term_name', 'MainNav'),
(116, 13, 'from_term_taxonomy', 'nav_menu'),
(117, 13, 'from_term_slug', ''),
(118, 13, 'to_term_name', 'MainNav'),
(119, 13, 'to_term_taxonomy', 'nav_menu'),
(120, 13, 'to_term_slug', 'null'),
(121, 13, 'to_term_description', ''),
(122, 13, '_message_key', 'edited_term'),
(123, 13, '_user_id', '1'),
(124, 13, '_user_login', 'highrank'),
(125, 13, '_user_email', 'ilawyerwp@gmail.com'),
(126, 13, '_server_remote_addr', '::1'),
(127, 13, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(128, 14, 'menu_id', '3'),
(129, 14, 'menu_name', 'MainNav'),
(130, 14, 'menu_items_added', '1'),
(131, 14, 'menu_items_removed', '0'),
(132, 14, '_message_key', 'edited_menu'),
(133, 14, '_user_id', '1'),
(134, 14, '_user_login', 'highrank'),
(135, 14, '_user_email', 'ilawyerwp@gmail.com'),
(136, 14, '_server_remote_addr', '::1'),
(137, 14, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(138, 15, 'term_id', '3'),
(139, 15, 'from_term_name', 'MainNav'),
(140, 15, 'from_term_taxonomy', 'nav_menu'),
(141, 15, 'from_term_slug', ''),
(142, 15, 'to_term_name', 'MainNav'),
(143, 15, 'to_term_taxonomy', 'nav_menu'),
(144, 15, 'to_term_slug', 'null'),
(145, 15, 'to_term_description', ''),
(146, 15, '_message_key', 'edited_term'),
(147, 15, '_user_id', '1'),
(148, 15, '_user_login', 'highrank'),
(149, 15, '_user_email', 'ilawyerwp@gmail.com'),
(150, 15, '_server_remote_addr', '::1'),
(151, 15, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(152, 16, 'menu_id', '3'),
(153, 16, 'menu_name', 'MainNav'),
(154, 16, 'menu_items_added', '0'),
(155, 16, 'menu_items_removed', '0'),
(156, 16, '_message_key', 'edited_menu'),
(157, 16, '_user_id', '1'),
(158, 16, '_user_login', 'highrank'),
(159, 16, '_user_email', 'ilawyerwp@gmail.com'),
(160, 16, '_server_remote_addr', '::1'),
(161, 16, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(162, 17, 'term_id', '3'),
(163, 17, 'from_term_name', 'MainNav'),
(164, 17, 'from_term_taxonomy', 'nav_menu'),
(165, 17, 'from_term_slug', ''),
(166, 17, 'to_term_name', 'MainNav'),
(167, 17, 'to_term_taxonomy', 'nav_menu'),
(168, 17, 'to_term_slug', 'null'),
(169, 17, 'to_term_description', ''),
(170, 17, '_message_key', 'edited_term'),
(171, 17, '_user_id', '1'),
(172, 17, '_user_login', 'highrank'),
(173, 17, '_user_email', 'ilawyerwp@gmail.com'),
(174, 17, '_server_remote_addr', '::1'),
(175, 17, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(176, 18, 'menu_id', '3'),
(177, 18, 'menu_name', 'MainNav'),
(178, 18, 'menu_items_added', '0'),
(179, 18, 'menu_items_removed', '0'),
(180, 18, '_message_key', 'edited_menu'),
(181, 18, '_user_id', '1'),
(182, 18, '_user_login', 'highrank'),
(183, 18, '_user_email', 'ilawyerwp@gmail.com'),
(184, 18, '_server_remote_addr', '::1'),
(185, 18, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(186, 19, 'term_id', '3'),
(187, 19, 'from_term_name', 'MainNav'),
(188, 19, 'from_term_taxonomy', 'nav_menu'),
(189, 19, 'from_term_slug', ''),
(190, 19, 'to_term_name', 'MainNav'),
(191, 19, 'to_term_taxonomy', 'nav_menu'),
(192, 19, 'to_term_slug', 'null'),
(193, 19, 'to_term_description', ''),
(194, 19, '_message_key', 'edited_term'),
(195, 19, '_user_id', '1'),
(196, 19, '_user_login', 'highrank'),
(197, 19, '_user_email', 'ilawyerwp@gmail.com'),
(198, 19, '_server_remote_addr', '::1'),
(199, 19, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(200, 20, 'post_id', '178') ;
INSERT INTO `wp_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(201, 20, 'post_type', 'page'),
(202, 20, 'post_title', 'About Us'),
(203, 20, '_message_key', 'post_created'),
(204, 20, '_user_id', '1'),
(205, 20, '_user_login', 'highrank'),
(206, 20, '_user_email', 'ilawyerwp@gmail.com'),
(207, 20, '_server_remote_addr', '::1'),
(208, 20, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/post-new.php?post_type=page&wp-post-new-reload=true&wp-post-new-reload=true'),
(209, 21, 'menu_id', '3'),
(210, 21, 'menu_name', 'MainNav'),
(211, 21, 'menu_items_added', '1'),
(212, 21, 'menu_items_removed', '4'),
(213, 21, '_message_key', 'edited_menu'),
(214, 21, '_user_id', '1'),
(215, 21, '_user_login', 'highrank'),
(216, 21, '_user_email', 'ilawyerwp@gmail.com'),
(217, 21, '_server_remote_addr', '::1'),
(218, 21, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(219, 22, 'term_id', '3'),
(220, 22, 'from_term_name', 'MainNav'),
(221, 22, 'from_term_taxonomy', 'nav_menu'),
(222, 22, 'from_term_slug', ''),
(223, 22, 'to_term_name', 'MainNav'),
(224, 22, 'to_term_taxonomy', 'nav_menu'),
(225, 22, 'to_term_slug', 'null'),
(226, 22, 'to_term_description', ''),
(227, 22, '_message_key', 'edited_term'),
(228, 22, '_user_id', '1'),
(229, 22, '_user_login', 'highrank'),
(230, 22, '_user_email', 'ilawyerwp@gmail.com'),
(231, 22, '_server_remote_addr', '::1'),
(232, 22, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(233, 23, 'menu_id', '3'),
(234, 23, 'menu_name', 'MainNav'),
(235, 23, 'menu_items_added', '12'),
(236, 23, 'menu_items_removed', '0'),
(237, 23, '_message_key', 'edited_menu'),
(238, 23, '_user_id', '1'),
(239, 23, '_user_login', 'highrank'),
(240, 23, '_user_email', 'ilawyerwp@gmail.com'),
(241, 23, '_server_remote_addr', '::1'),
(242, 23, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(243, 24, 'term_id', '3'),
(244, 24, 'from_term_name', 'MainNav'),
(245, 24, 'from_term_taxonomy', 'nav_menu'),
(246, 24, 'from_term_slug', ''),
(247, 24, 'to_term_name', 'MainNav'),
(248, 24, 'to_term_taxonomy', 'nav_menu'),
(249, 24, 'to_term_slug', 'null'),
(250, 24, 'to_term_description', ''),
(251, 24, '_message_key', 'edited_term'),
(252, 24, '_user_id', '1'),
(253, 24, '_user_login', 'highrank'),
(254, 24, '_user_email', 'ilawyerwp@gmail.com'),
(255, 24, '_server_remote_addr', '::1'),
(256, 24, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(257, 25, 'menu_id', '3'),
(258, 25, 'menu_name', 'MainNav'),
(259, 25, 'menu_items_added', '13'),
(260, 25, 'menu_items_removed', '0'),
(261, 25, '_message_key', 'edited_menu'),
(262, 25, '_user_id', '1'),
(263, 25, '_user_login', 'highrank'),
(264, 25, '_user_email', 'ilawyerwp@gmail.com'),
(265, 25, '_server_remote_addr', '::1'),
(266, 25, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(267, 26, 'term_id', '3'),
(268, 26, 'from_term_name', 'MainNav'),
(269, 26, 'from_term_taxonomy', 'nav_menu'),
(270, 26, 'from_term_slug', ''),
(271, 26, 'to_term_name', 'MainNav'),
(272, 26, 'to_term_taxonomy', 'nav_menu'),
(273, 26, 'to_term_slug', 'null'),
(274, 26, 'to_term_description', ''),
(275, 26, '_message_key', 'edited_term'),
(276, 26, '_user_id', '1'),
(277, 26, '_user_login', 'highrank'),
(278, 26, '_user_email', 'ilawyerwp@gmail.com'),
(279, 26, '_server_remote_addr', '::1'),
(280, 26, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(281, 27, 'menu_id', '3'),
(282, 27, 'menu_name', 'MainNav'),
(283, 27, 'menu_items_added', '0'),
(284, 27, 'menu_items_removed', '0'),
(285, 27, '_message_key', 'edited_menu'),
(286, 27, '_user_id', '1'),
(287, 27, '_user_login', 'highrank'),
(288, 27, '_user_email', 'ilawyerwp@gmail.com'),
(289, 27, '_server_remote_addr', '::1'),
(290, 27, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(291, 28, 'term_id', '3'),
(292, 28, 'from_term_name', 'MainNav'),
(293, 28, 'from_term_taxonomy', 'nav_menu'),
(294, 28, 'from_term_slug', ''),
(295, 28, 'to_term_name', 'MainNav'),
(296, 28, 'to_term_taxonomy', 'nav_menu'),
(297, 28, 'to_term_slug', 'null'),
(298, 28, 'to_term_description', ''),
(299, 28, '_message_key', 'edited_term'),
(300, 28, '_user_id', '1') ;
INSERT INTO `wp_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(301, 28, '_user_login', 'highrank'),
(302, 28, '_user_email', 'ilawyerwp@gmail.com'),
(303, 28, '_server_remote_addr', '::1'),
(304, 28, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(305, 29, 'menu_id', '3'),
(306, 29, 'menu_name', 'MainNav'),
(307, 29, 'menu_items_added', '0'),
(308, 29, 'menu_items_removed', '1'),
(309, 29, '_message_key', 'edited_menu'),
(310, 29, '_user_id', '1'),
(311, 29, '_user_login', 'highrank'),
(312, 29, '_user_email', 'ilawyerwp@gmail.com'),
(313, 29, '_server_remote_addr', '::1'),
(314, 29, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(315, 30, 'term_id', '3'),
(316, 30, 'from_term_name', 'MainNav'),
(317, 30, 'from_term_taxonomy', 'nav_menu'),
(318, 30, 'from_term_slug', ''),
(319, 30, 'to_term_name', 'MainNav'),
(320, 30, 'to_term_taxonomy', 'nav_menu'),
(321, 30, 'to_term_slug', 'null'),
(322, 30, 'to_term_description', ''),
(323, 30, '_message_key', 'edited_term'),
(324, 30, '_user_id', '1'),
(325, 30, '_user_login', 'highrank'),
(326, 30, '_user_email', 'ilawyerwp@gmail.com'),
(327, 30, '_server_remote_addr', '::1'),
(328, 30, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(329, 31, 'menu_id', '3'),
(330, 31, 'menu_name', 'MainNav'),
(331, 31, 'menu_items_added', '1'),
(332, 31, 'menu_items_removed', '1'),
(333, 31, '_message_key', 'edited_menu'),
(334, 31, '_user_id', '1'),
(335, 31, '_user_login', 'highrank'),
(336, 31, '_user_email', 'ilawyerwp@gmail.com'),
(337, 31, '_server_remote_addr', '::1'),
(338, 31, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(339, 32, 'term_id', '3'),
(340, 32, 'from_term_name', 'MainNav'),
(341, 32, 'from_term_taxonomy', 'nav_menu'),
(342, 32, 'from_term_slug', ''),
(343, 32, 'to_term_name', 'MainNav'),
(344, 32, 'to_term_taxonomy', 'nav_menu'),
(345, 32, 'to_term_slug', 'null'),
(346, 32, 'to_term_description', ''),
(347, 32, '_message_key', 'edited_term'),
(348, 32, '_user_id', '1'),
(349, 32, '_user_login', 'highrank'),
(350, 32, '_user_email', 'ilawyerwp@gmail.com'),
(351, 32, '_server_remote_addr', '::1'),
(352, 32, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(353, 33, 'menu_id', '3'),
(354, 33, 'menu_name', 'MainNav'),
(355, 33, 'menu_items_added', '1'),
(356, 33, 'menu_items_removed', '0'),
(357, 33, '_message_key', 'edited_menu'),
(358, 33, '_user_id', '1'),
(359, 33, '_user_login', 'highrank'),
(360, 33, '_user_email', 'ilawyerwp@gmail.com'),
(361, 33, '_server_remote_addr', '::1'),
(362, 33, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(363, 34, 'term_id', '3'),
(364, 34, 'from_term_name', 'MainNav'),
(365, 34, 'from_term_taxonomy', 'nav_menu'),
(366, 34, 'from_term_slug', ''),
(367, 34, 'to_term_name', 'MainNav'),
(368, 34, 'to_term_taxonomy', 'nav_menu'),
(369, 34, 'to_term_slug', 'null'),
(370, 34, 'to_term_description', ''),
(371, 34, '_message_key', 'edited_term'),
(372, 34, '_user_id', '1'),
(373, 34, '_user_login', 'highrank'),
(374, 34, '_user_email', 'ilawyerwp@gmail.com'),
(375, 34, '_server_remote_addr', '::1'),
(376, 34, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(377, 35, 'menu_id', '3'),
(378, 35, 'menu_name', 'MainNav'),
(379, 35, 'menu_items_added', '0'),
(380, 35, 'menu_items_removed', '0'),
(381, 35, '_message_key', 'edited_menu'),
(382, 35, '_user_id', '1'),
(383, 35, '_user_login', 'highrank'),
(384, 35, '_user_email', 'ilawyerwp@gmail.com'),
(385, 35, '_server_remote_addr', '::1'),
(386, 35, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(387, 36, 'term_id', '3'),
(388, 36, 'from_term_name', 'MainNav'),
(389, 36, 'from_term_taxonomy', 'nav_menu'),
(390, 36, 'from_term_slug', ''),
(391, 36, 'to_term_name', 'MainNav'),
(392, 36, 'to_term_taxonomy', 'nav_menu'),
(393, 36, 'to_term_slug', 'null'),
(394, 36, 'to_term_description', ''),
(395, 36, '_message_key', 'edited_term'),
(396, 36, '_user_id', '1'),
(397, 36, '_user_login', 'highrank'),
(398, 36, '_user_email', 'ilawyerwp@gmail.com'),
(399, 36, '_server_remote_addr', '::1'),
(400, 36, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php') ;
INSERT INTO `wp_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(401, 37, 'menu_id', '3'),
(402, 37, 'menu_name', 'MainNav'),
(403, 37, 'menu_items_added', '4'),
(404, 37, 'menu_items_removed', '0'),
(405, 37, '_message_key', 'edited_menu'),
(406, 37, '_user_id', '1'),
(407, 37, '_user_login', 'highrank'),
(408, 37, '_user_email', 'ilawyerwp@gmail.com'),
(409, 37, '_server_remote_addr', '::1'),
(410, 37, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(411, 38, 'term_id', '3'),
(412, 38, 'from_term_name', 'MainNav'),
(413, 38, 'from_term_taxonomy', 'nav_menu'),
(414, 38, 'from_term_slug', ''),
(415, 38, 'to_term_name', 'MainNav'),
(416, 38, 'to_term_taxonomy', 'nav_menu'),
(417, 38, 'to_term_slug', 'null'),
(418, 38, 'to_term_description', ''),
(419, 38, '_message_key', 'edited_term'),
(420, 38, '_user_id', '1'),
(421, 38, '_user_login', 'highrank'),
(422, 38, '_user_email', 'ilawyerwp@gmail.com'),
(423, 38, '_server_remote_addr', '::1'),
(424, 38, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(425, 39, 'menu_id', '3'),
(426, 39, 'menu_name', 'MainNav'),
(427, 39, 'menu_items_added', '3'),
(428, 39, 'menu_items_removed', '0'),
(429, 39, '_message_key', 'edited_menu'),
(430, 39, '_user_id', '1'),
(431, 39, '_user_login', 'highrank'),
(432, 39, '_user_email', 'ilawyerwp@gmail.com'),
(433, 39, '_server_remote_addr', '::1'),
(434, 39, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(435, 40, 'term_id', '3'),
(436, 40, 'from_term_name', 'MainNav'),
(437, 40, 'from_term_taxonomy', 'nav_menu'),
(438, 40, 'from_term_slug', ''),
(439, 40, 'to_term_name', 'MainNav'),
(440, 40, 'to_term_taxonomy', 'nav_menu'),
(441, 40, 'to_term_slug', 'null'),
(442, 40, 'to_term_description', ''),
(443, 40, '_message_key', 'edited_term'),
(444, 40, '_user_id', '1'),
(445, 40, '_user_login', 'highrank'),
(446, 40, '_user_email', 'ilawyerwp@gmail.com'),
(447, 40, '_server_remote_addr', '::1'),
(448, 40, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(449, 41, 'menu_id', '3'),
(450, 41, 'menu_name', 'MainNav'),
(451, 41, 'menu_items_added', '1'),
(452, 41, 'menu_items_removed', '0'),
(453, 41, '_message_key', 'edited_menu'),
(454, 41, '_user_id', '1'),
(455, 41, '_user_login', 'highrank'),
(456, 41, '_user_email', 'ilawyerwp@gmail.com'),
(457, 41, '_server_remote_addr', '::1'),
(458, 41, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(459, 42, 'term_id', '3'),
(460, 42, 'from_term_name', 'MainNav'),
(461, 42, 'from_term_taxonomy', 'nav_menu'),
(462, 42, 'from_term_slug', ''),
(463, 42, 'to_term_name', 'MainNav'),
(464, 42, 'to_term_taxonomy', 'nav_menu'),
(465, 42, 'to_term_slug', 'null'),
(466, 42, 'to_term_description', ''),
(467, 42, '_message_key', 'edited_term'),
(468, 42, '_user_id', '1'),
(469, 42, '_user_login', 'highrank'),
(470, 42, '_user_email', 'ilawyerwp@gmail.com'),
(471, 42, '_server_remote_addr', '::1'),
(472, 42, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(473, 43, 'plugin_slug', 'gravityforms'),
(474, 43, 'plugin_name', 'Gravity Forms'),
(475, 43, 'plugin_title', '<a href="http://www.gravityforms.com">Gravity Forms</a>'),
(476, 43, 'plugin_description', 'Easily create web forms and manage form entries within the WordPress admin. <cite>By <a href="http://www.rocketgenius.com">rocketgenius</a>.</cite>'),
(477, 43, 'plugin_author', '<a href="http://www.rocketgenius.com">rocketgenius</a>'),
(478, 43, 'plugin_version', '2.0.2'),
(479, 43, 'plugin_url', 'http://www.gravityforms.com'),
(480, 43, 'plugin_update_info_plugin', 'gravityforms/gravityforms.php'),
(481, 43, 'plugin_update_info_package', 'http://s3.amazonaws.com/gravityforms/releases/gravityforms_2.0.2.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1468606291&Signature=0MaM5uddTNHqGnsdoE7rdY%2B10X8%3D'),
(482, 43, 'plugin_prev_version', '1.9.19'),
(483, 43, '_message_key', 'plugin_bulk_updated'),
(484, 43, '_user_id', '1'),
(485, 43, '_user_login', 'highrank'),
(486, 43, '_user_email', 'ilawyerwp@gmail.com'),
(487, 43, '_server_remote_addr', '::1'),
(488, 43, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/plugins.php'),
(489, 44, 'plugin_slug', 'wp-migrate-db-pro'),
(490, 44, 'plugin_name', 'WP Migrate DB Pro'),
(491, 44, 'plugin_title', '<a href="http://deliciousbrains.com/wp-migrate-db-pro/">WP Migrate DB Pro</a>'),
(492, 44, 'plugin_description', 'Export, push, and pull to migrate your WordPress databases. <cite>By <a href="http://deliciousbrains.com">Delicious Brains</a>.</cite>'),
(493, 44, 'plugin_author', '<a href="http://deliciousbrains.com">Delicious Brains</a>'),
(494, 44, 'plugin_version', '1.6.1'),
(495, 44, 'plugin_url', 'http://deliciousbrains.com/wp-migrate-db-pro/'),
(496, 44, 'plugin_update_info_plugin', 'wp-migrate-db-pro/wp-migrate-db-pro.php'),
(497, 44, 'plugin_update_info_package', 'https://api.deliciousbrains.com/?wc-api=delicious-brains&request=download&licence_key=59dc13dd-1ccf-46fe-b573-fe88cf5e873a&slug=wp-migrate-db-pro&site_url=http://tedsmithdemo.com'),
(498, 44, 'plugin_prev_version', '1.6'),
(499, 44, '_message_key', 'plugin_bulk_updated'),
(500, 44, '_user_id', '1') ;
INSERT INTO `wp_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(501, 44, '_user_login', 'highrank'),
(502, 44, '_user_email', 'ilawyerwp@gmail.com'),
(503, 44, '_server_remote_addr', '::1'),
(504, 44, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/plugins.php'),
(505, 45, 'menu_id', '3'),
(506, 45, 'menu_name', 'MainNav'),
(507, 45, 'menu_items_added', '5'),
(508, 45, 'menu_items_removed', '0'),
(509, 45, '_message_key', 'edited_menu'),
(510, 45, '_user_id', '1'),
(511, 45, '_user_login', 'highrank'),
(512, 45, '_user_email', 'ilawyerwp@gmail.com'),
(513, 45, '_server_remote_addr', '::1'),
(514, 45, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(515, 46, 'term_id', '3'),
(516, 46, 'from_term_name', 'MainNav'),
(517, 46, 'from_term_taxonomy', 'nav_menu'),
(518, 46, 'from_term_slug', ''),
(519, 46, 'to_term_name', 'MainNav'),
(520, 46, 'to_term_taxonomy', 'nav_menu'),
(521, 46, 'to_term_slug', 'null'),
(522, 46, 'to_term_description', ''),
(523, 46, '_message_key', 'edited_term'),
(524, 46, '_user_id', '1'),
(525, 46, '_user_login', 'highrank'),
(526, 46, '_user_email', 'ilawyerwp@gmail.com'),
(527, 46, '_server_remote_addr', '::1'),
(528, 46, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(529, 47, 'menu_id', '3'),
(530, 47, 'menu_name', 'MainNav'),
(531, 47, 'menu_items_added', '3'),
(532, 47, 'menu_items_removed', '0'),
(533, 47, '_message_key', 'edited_menu'),
(534, 47, '_user_id', '1'),
(535, 47, '_user_login', 'highrank'),
(536, 47, '_user_email', 'ilawyerwp@gmail.com'),
(537, 47, '_server_remote_addr', '::1'),
(538, 47, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(539, 48, 'term_id', '3'),
(540, 48, 'from_term_name', 'MainNav'),
(541, 48, 'from_term_taxonomy', 'nav_menu'),
(542, 48, 'from_term_slug', ''),
(543, 48, 'to_term_name', 'MainNav'),
(544, 48, 'to_term_taxonomy', 'nav_menu'),
(545, 48, 'to_term_slug', 'null'),
(546, 48, 'to_term_description', ''),
(547, 48, '_message_key', 'edited_term'),
(548, 48, '_user_id', '1'),
(549, 48, '_user_login', 'highrank'),
(550, 48, '_user_email', 'ilawyerwp@gmail.com'),
(551, 48, '_server_remote_addr', '::1'),
(552, 48, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(553, 49, 'menu_id', '3'),
(554, 49, 'menu_name', 'MainNav'),
(555, 49, 'menu_items_added', '1'),
(556, 49, 'menu_items_removed', '1'),
(557, 49, '_message_key', 'edited_menu'),
(558, 49, '_user_id', '1'),
(559, 49, '_user_login', 'highrank'),
(560, 49, '_user_email', 'ilawyerwp@gmail.com'),
(561, 49, '_server_remote_addr', '::1'),
(562, 49, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(563, 50, 'term_id', '3'),
(564, 50, 'from_term_name', 'MainNav'),
(565, 50, 'from_term_taxonomy', 'nav_menu'),
(566, 50, 'from_term_slug', ''),
(567, 50, 'to_term_name', 'MainNav'),
(568, 50, 'to_term_taxonomy', 'nav_menu'),
(569, 50, 'to_term_slug', 'null'),
(570, 50, 'to_term_description', ''),
(571, 50, '_message_key', 'edited_term'),
(572, 50, '_user_id', '1'),
(573, 50, '_user_login', 'highrank'),
(574, 50, '_user_email', 'ilawyerwp@gmail.com'),
(575, 50, '_server_remote_addr', '::1'),
(576, 50, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(577, 51, 'user_id', '1'),
(578, 51, 'user_email', 'ilawyerwp@gmail.com'),
(579, 51, 'user_login', 'highrank'),
(580, 51, '_user_id', '1'),
(581, 51, '_user_login', 'highrank'),
(582, 51, '_user_email', 'ilawyerwp@gmail.com'),
(583, 51, 'server_http_user_agent', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0'),
(584, 51, '_message_key', 'user_logged_in'),
(585, 51, '_server_remote_addr', '::1'),
(586, 51, '_server_http_referer', 'http://tedsmithdemo.com/wp-login.php?redirect_to=http%3A%2F%2Ftedsmithdemo.com%2Fwp-admin%2F&reauth=1'),
(587, 52, 'menu_id', '3'),
(588, 52, 'menu_name', 'MainNav'),
(589, 52, 'menu_items_added', '3'),
(590, 52, 'menu_items_removed', '5'),
(591, 52, '_message_key', 'edited_menu'),
(592, 52, '_user_id', '1'),
(593, 52, '_user_login', 'highrank'),
(594, 52, '_user_email', 'ilawyerwp@gmail.com'),
(595, 52, '_server_remote_addr', '::1'),
(596, 52, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(597, 53, 'term_id', '3'),
(598, 53, 'from_term_name', 'MainNav'),
(599, 53, 'from_term_taxonomy', 'nav_menu'),
(600, 53, 'from_term_slug', '') ;
INSERT INTO `wp_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(601, 53, 'to_term_name', 'MainNav'),
(602, 53, 'to_term_taxonomy', 'nav_menu'),
(603, 53, 'to_term_slug', 'null'),
(604, 53, 'to_term_description', ''),
(605, 53, '_message_key', 'edited_term'),
(606, 53, '_user_id', '1'),
(607, 53, '_user_login', 'highrank'),
(608, 53, '_user_email', 'ilawyerwp@gmail.com'),
(609, 53, '_server_remote_addr', '::1'),
(610, 53, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(611, 54, 'post_id', '230'),
(612, 54, 'post_type', 'page'),
(613, 54, 'post_title', 'Video Center'),
(614, 54, '_message_key', 'post_created'),
(615, 54, '_user_id', '1'),
(616, 54, '_user_login', 'highrank'),
(617, 54, '_user_email', 'ilawyerwp@gmail.com'),
(618, 54, '_server_remote_addr', '::1'),
(619, 54, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/post-new.php?post_type=page&wp-post-new-reload=true&wp-post-new-reload=true'),
(620, 55, 'menu_id', '3'),
(621, 55, 'menu_name', 'MainNav'),
(622, 55, 'menu_items_added', '1'),
(623, 55, 'menu_items_removed', '2'),
(624, 55, '_message_key', 'edited_menu'),
(625, 55, '_user_id', '1'),
(626, 55, '_user_login', 'highrank'),
(627, 55, '_user_email', 'ilawyerwp@gmail.com'),
(628, 55, '_server_remote_addr', '::1'),
(629, 55, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(630, 56, 'term_id', '3'),
(631, 56, 'from_term_name', 'MainNav'),
(632, 56, 'from_term_taxonomy', 'nav_menu'),
(633, 56, 'from_term_slug', ''),
(634, 56, 'to_term_name', 'MainNav'),
(635, 56, 'to_term_taxonomy', 'nav_menu'),
(636, 56, 'to_term_slug', 'null'),
(637, 56, 'to_term_description', ''),
(638, 56, '_message_key', 'edited_term'),
(639, 56, '_user_id', '1'),
(640, 56, '_user_login', 'highrank'),
(641, 56, '_user_email', 'ilawyerwp@gmail.com'),
(642, 56, '_server_remote_addr', '::1'),
(643, 56, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(644, 57, 'menu_id', '3'),
(645, 57, 'menu_name', 'MainNav'),
(646, 57, 'menu_items_added', '0'),
(647, 57, 'menu_items_removed', '0'),
(648, 57, '_message_key', 'edited_menu'),
(649, 57, '_user_id', '1'),
(650, 57, '_user_login', 'highrank'),
(651, 57, '_user_email', 'ilawyerwp@gmail.com'),
(652, 57, '_server_remote_addr', '::1'),
(653, 57, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(654, 58, 'term_id', '3'),
(655, 58, 'from_term_name', 'MainNav'),
(656, 58, 'from_term_taxonomy', 'nav_menu'),
(657, 58, 'from_term_slug', ''),
(658, 58, 'to_term_name', 'MainNav'),
(659, 58, 'to_term_taxonomy', 'nav_menu'),
(660, 58, 'to_term_slug', 'null'),
(661, 58, 'to_term_description', ''),
(662, 58, '_message_key', 'edited_term'),
(663, 58, '_user_id', '1'),
(664, 58, '_user_login', 'highrank'),
(665, 58, '_user_email', 'ilawyerwp@gmail.com'),
(666, 58, '_server_remote_addr', '::1'),
(667, 58, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/nav-menus.php'),
(668, 59, 'user_id', '1'),
(669, 59, 'user_email', 'ilawyerwp@gmail.com'),
(670, 59, 'user_login', 'highrank'),
(671, 59, '_user_id', '1'),
(672, 59, '_user_login', 'highrank'),
(673, 59, '_user_email', 'ilawyerwp@gmail.com'),
(674, 59, 'server_http_user_agent', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0'),
(675, 59, '_message_key', 'user_logged_in'),
(676, 59, '_server_remote_addr', '::1'),
(677, 59, '_server_http_referer', 'http://tedsmithdemo.com/wp-login.php?redirect_to=http%3A%2F%2Ftedsmithdemo.com%2Fwp-admin%2F&reauth=1'),
(678, 60, 'login_id', '1'),
(679, 60, 'login_email', 'ilawyerwp@gmail.com'),
(680, 60, 'login', 'highrank'),
(681, 60, 'server_http_user_agent', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0'),
(682, 60, '_message_key', 'user_login_failed'),
(683, 60, '_server_remote_addr', '::1'),
(684, 60, '_server_http_referer', 'http://tedsmithdemo.com/wp-login.php?redirect_to=http%3A%2F%2Ftedsmithdemo.com%2Fwp-admin%2F&reauth=1'),
(685, 61, 'login_id', '1'),
(686, 61, 'login_email', 'ilawyerwp@gmail.com'),
(687, 61, 'login', 'highrank'),
(688, 61, 'server_http_user_agent', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0'),
(689, 61, '_message_key', 'user_login_failed'),
(690, 61, '_server_remote_addr', '::1'),
(691, 61, '_server_http_referer', 'http://tedsmithdemo.com/wp-login.php'),
(692, 62, 'login_id', '1'),
(693, 62, 'login_email', 'ilawyerwp@gmail.com'),
(694, 62, 'login', 'highrank'),
(695, 62, 'server_http_user_agent', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0'),
(696, 62, '_message_key', 'user_login_failed'),
(697, 62, '_server_remote_addr', '::1'),
(698, 62, '_server_http_referer', 'http://tedsmithdemo.com/wp-login.php'),
(699, 63, 'login_id', '1'),
(700, 63, 'login_email', 'ilawyerwp@gmail.com') ;
INSERT INTO `wp_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(701, 63, 'login', 'highrank'),
(702, 63, 'server_http_user_agent', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0'),
(703, 63, '_message_key', 'user_login_failed'),
(704, 63, '_server_remote_addr', '::1'),
(705, 63, '_server_http_referer', 'http://tedsmithdemo.com/wp-login.php'),
(706, 64, 'login_id', '1'),
(707, 64, 'login_email', 'ilawyerwp@gmail.com'),
(708, 64, 'login', 'highrank'),
(709, 64, 'server_http_user_agent', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0'),
(710, 64, '_message_key', 'user_login_failed'),
(711, 64, '_server_remote_addr', '::1'),
(712, 64, '_server_http_referer', 'http://tedsmithdemo.com/wp-login.php'),
(713, 65, 'login_id', '1'),
(714, 65, 'login_email', 'ilawyerwp@gmail.com'),
(715, 65, 'login', 'highrank'),
(716, 65, 'server_http_user_agent', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0'),
(717, 65, '_message_key', 'user_login_failed'),
(718, 65, '_server_remote_addr', '::1'),
(719, 65, '_server_http_referer', 'http://tedsmithdemo.com/wp-login.php'),
(720, 66, 'login_id', '1'),
(721, 66, 'login_email', 'ilawyerwp@gmail.com'),
(722, 66, 'login', 'highrank'),
(723, 66, 'server_http_user_agent', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0'),
(724, 66, '_message_key', 'user_login_failed'),
(725, 66, '_server_remote_addr', '::1'),
(726, 66, '_server_http_referer', 'http://tedsmithdemo.com/wp-login.php'),
(727, 67, 'login_id', '1'),
(728, 67, 'login_email', 'ilawyerwp@gmail.com'),
(729, 67, 'login', 'highrank'),
(730, 67, 'server_http_user_agent', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0'),
(731, 67, '_message_key', 'user_login_failed'),
(732, 67, '_server_remote_addr', '::1'),
(733, 67, '_server_http_referer', 'http://tedsmithdemo.com/wp-login.php'),
(734, 68, 'user_id', '1'),
(735, 68, 'user_email', 'ilawyerwp@gmail.com'),
(736, 68, 'user_login', 'highrank'),
(737, 68, '_user_id', '1'),
(738, 68, '_user_login', 'highrank'),
(739, 68, '_user_email', 'ilawyerwp@gmail.com'),
(740, 68, 'server_http_user_agent', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0'),
(741, 68, '_message_key', 'user_logged_in'),
(742, 68, '_server_remote_addr', '::1'),
(743, 68, '_server_http_referer', 'http://tedsmithdemo.com/wp-login.php'),
(744, 69, '_message_key', 'user_logged_out'),
(745, 69, '_user_id', '1'),
(746, 69, '_user_login', 'highrank'),
(747, 69, '_user_email', 'ilawyerwp@gmail.com'),
(748, 69, '_server_remote_addr', '::1'),
(749, 69, '_server_http_referer', 'http://tedsmithdemo.com/'),
(750, 70, 'user_id', '1'),
(751, 70, 'user_email', 'ilawyerwp@gmail.com'),
(752, 70, 'user_login', 'highrank'),
(753, 70, '_user_id', '1'),
(754, 70, '_user_login', 'highrank'),
(755, 70, '_user_email', 'ilawyerwp@gmail.com'),
(756, 70, 'server_http_user_agent', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0'),
(757, 70, '_message_key', 'user_logged_in'),
(758, 70, '_server_remote_addr', '::1'),
(759, 70, '_server_http_referer', 'http://tedsmithdemo.com/wp-login.php?redirect_to=http%3A%2F%2Ftedsmithdemo.com%2Fwp-admin%2F&reauth=1'),
(760, 71, 'plugin_slug', 'advanced-custom-fields-pro'),
(761, 71, 'plugin_name', 'Advanced Custom Fields PRO'),
(762, 71, 'plugin_title', '<a href="https://www.advancedcustomfields.com/">Advanced Custom Fields PRO</a>'),
(763, 71, 'plugin_description', 'Customise WordPress with powerful, professional and intuitive fields <cite>By <a href="http://www.elliotcondon.com/">Elliot Condon</a>.</cite>'),
(764, 71, 'plugin_author', '<a href="http://www.elliotcondon.com/">Elliot Condon</a>'),
(765, 71, 'plugin_version', '5.3.10'),
(766, 71, 'plugin_url', 'https://www.advancedcustomfields.com/'),
(767, 71, 'plugin_update_info_plugin', 'advanced-custom-fields-pro/acf.php'),
(768, 71, 'plugin_update_info_package', 'https://connect.advancedcustomfields.com/index.php?k=b3JkZXJfaWQ9MzMyODN8dHlwZT1kZXZlbG9wZXJ8ZGF0ZT0yMDE0LTA3LTA3IDIxOjI4OjM2&wp_url=http://tedsmithdemo.com&acf_version=5.3.9.2&wp_version=4.5.3&a=download&p=pro'),
(769, 71, 'plugin_prev_version', '5.3.9.2'),
(770, 71, '_message_key', 'plugin_bulk_updated'),
(771, 71, '_user_id', '1'),
(772, 71, '_user_login', 'highrank'),
(773, 71, '_user_email', 'ilawyerwp@gmail.com'),
(774, 71, '_server_remote_addr', '::1'),
(775, 71, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/plugins.php'),
(776, 72, 'plugin_slug', 'gravityforms'),
(777, 72, 'plugin_name', 'Gravity Forms'),
(778, 72, 'plugin_title', '<a href="http://www.gravityforms.com">Gravity Forms</a>'),
(779, 72, 'plugin_description', 'Easily create web forms and manage form entries within the WordPress admin. <cite>By <a href="http://www.rocketgenius.com">rocketgenius</a>.</cite>'),
(780, 72, 'plugin_author', '<a href="http://www.rocketgenius.com">rocketgenius</a>'),
(781, 72, 'plugin_version', '2.0.4'),
(782, 72, 'plugin_url', 'http://www.gravityforms.com'),
(783, 72, 'plugin_update_info_plugin', 'gravityforms/gravityforms.php'),
(784, 72, 'plugin_update_info_package', 'http://s3.amazonaws.com/gravityforms/releases/gravityforms_2.0.4.zip?AWSAccessKeyId=1603BBK66770VCSCJSG2&Expires=1470280225&Signature=R%2Fwc%2Bm8ZIOPgWmaZUVpz3b5xHzU%3D'),
(785, 72, 'plugin_prev_version', '2.0.2'),
(786, 72, '_message_key', 'plugin_bulk_updated'),
(787, 72, '_user_id', '1'),
(788, 72, '_user_login', 'highrank'),
(789, 72, '_user_email', 'ilawyerwp@gmail.com'),
(790, 72, '_server_remote_addr', '::1'),
(791, 72, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/plugins.php'),
(792, 73, 'plugin_slug', 'simple-history'),
(793, 73, 'plugin_name', 'Simple History'),
(794, 73, 'plugin_title', '<a href="http://simple-history.com">Simple History</a>'),
(795, 73, 'plugin_description', 'Plugin that logs various things that occur in WordPress and then presents those events in a very nice GUI. <cite>By <a href="http://simple-history.com/">Pär Thernström</a>.</cite>'),
(796, 73, 'plugin_author', '<a href="http://simple-history.com/">Pär Thernström</a>'),
(797, 73, 'plugin_version', '2.7.4'),
(798, 73, 'plugin_url', 'http://simple-history.com'),
(799, 73, 'plugin_update_info_plugin', 'simple-history/index.php'),
(800, 73, 'plugin_update_info_package', 'https://downloads.wordpress.org/plugin/simple-history.2.7.4.zip') ;
INSERT INTO `wp_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(801, 73, 'plugin_prev_version', '2.7.3'),
(802, 73, '_message_key', 'plugin_bulk_updated'),
(803, 73, '_user_id', '1'),
(804, 73, '_user_login', 'highrank'),
(805, 73, '_user_email', 'ilawyerwp@gmail.com'),
(806, 73, '_server_remote_addr', '::1'),
(807, 73, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/plugins.php'),
(808, 74, 'plugin_slug', 'wordpress-seo'),
(809, 74, 'plugin_name', 'Yoast SEO'),
(810, 74, 'plugin_title', '<a href="https://yoast.com/wordpress/plugins/seo/#utm_source=wpadmin&#038;utm_medium=plugin&#038;utm_campaign=wpseoplugin">Yoast SEO</a>'),
(811, 74, 'plugin_description', 'The first true all-in-one SEO solution for WordPress, including on-page content analysis, XML sitemaps and much more. <cite>By <a href="https://yoast.com/">Team Yoast</a>.</cite>'),
(812, 74, 'plugin_author', '<a href="https://yoast.com/">Team Yoast</a>'),
(813, 74, 'plugin_version', '3.4'),
(814, 74, 'plugin_url', 'https://yoast.com/wordpress/plugins/seo/#utm_source=wpadmin&#038;utm_medium=plugin&#038;utm_campaign=wpseoplugin'),
(815, 74, 'plugin_update_info_plugin', 'wordpress-seo/wp-seo.php'),
(816, 74, 'plugin_update_info_package', 'https://downloads.wordpress.org/plugin/wordpress-seo.3.4.zip'),
(817, 74, 'plugin_prev_version', '3.3.4'),
(818, 74, '_message_key', 'plugin_bulk_updated'),
(819, 74, '_user_id', '1'),
(820, 74, '_user_login', 'highrank'),
(821, 74, '_user_email', 'ilawyerwp@gmail.com'),
(822, 74, '_server_remote_addr', '::1'),
(823, 74, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/plugins.php'),
(824, 75, 'post_id', '178'),
(825, 75, 'post_type', 'page'),
(826, 75, 'post_title', 'About Us'),
(827, 75, 'post_prev_page_template', 'default'),
(828, 75, 'post_new_page_template', 'page-about.php'),
(829, 75, 'post_new_page_template_name', 'About Us'),
(830, 75, '_message_key', 'post_updated'),
(831, 75, '_user_id', '1'),
(832, 75, '_user_login', 'highrank'),
(833, 75, '_user_email', 'ilawyerwp@gmail.com'),
(834, 75, '_server_remote_addr', '::1'),
(835, 75, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/post.php?post=178&action=edit'),
(836, 76, 'post_id', '178'),
(837, 76, 'post_type', 'page'),
(838, 76, 'post_title', 'About Us'),
(839, 76, 'post_prev_post_content', ''),
(840, 76, 'post_new_post_content', 'The purpose of this HTML is to help determine what default settings are with CSS and to make sure that all possible HTML Elements are included in this HTML so as to not miss any possible Elements when designing a site.\r\n\r\n<hr />\r\n\r\n<h1>Heading 1</h1>\r\n<h2>Heading 2</h2>\r\n<h3>Heading 3</h3>\r\n<h4>Heading 4</h4>\r\n<h5>Heading 5</h5>\r\n<h6>Heading 6</h6>\r\n<small><a href="#wrapper">[top]</a></small>\r\n\r\n<hr />\r\n\r\n<h2 id="paragraph">Paragraph</h2>\r\nLorem ipsum dolor sit amet, <a title="test link" href="#">test link</a> adipiscing elit. Nullam dignissim convallis est. Quisque aliquam. Donec faucibus. Nunc iaculis suscipit dui. Nam sit amet sem. Aliquam libero nisi, imperdiet at, tincidunt nec, gravida vehicula, nisl. Praesent mattis, massa quis luctus fermentum, turpis mi volutpat justo, eu volutpat enim diam eget metus. Maecenas ornare tortor. Donec sed tellus eget sapien fringilla nonummy. Mauris a ante. Suspendisse quam sem, consequat at, commodo vitae, feugiat in, nunc. Morbi imperdiet augue quis tellus.\r\n\r\nLorem ipsum dolor sit amet, <em>emphasis</em> consectetuer adipiscing elit. Nullam dignissim convallis est. Quisque aliquam. Donec faucibus. Nunc iaculis suscipit dui. Nam sit amet sem. Aliquam libero nisi, imperdiet at, tincidunt nec, gravida vehicula, nisl. Praesent mattis, massa quis luctus fermentum, turpis mi volutpat justo, eu volutpat enim diam eget metus. Maecenas ornare tortor. Donec sed tellus eget sapien fringilla nonummy. Mauris a ante. Suspendisse quam sem, consequat at, commodo vitae, feugiat in, nunc. Morbi imperdiet augue quis tellus.\r\n\r\n<small><a href="#wrapper">[top]</a></small>\r\n\r\n<hr />\r\n\r\n<h2 id="list_types">List Types</h2>\r\n<h3>Definition List</h3>\r\n<dl><dt>Definition List Title</dt><dd>This is a definition list division.</dd></dl>\r\n<h3>Ordered List</h3>\r\n<ol>\r\n	<li>List Item 1</li>\r\n	<li>List Item 2</li>\r\n	<li>List Item 3</li>\r\n</ol>\r\n<h3>Unordered List</h3>\r\n<ul>\r\n	<li>List Item 1</li>\r\n	<li>List Item 2</li>\r\n	<li>List Item 3</li>\r\n</ul>\r\n<small><a href="#wrapper">[top]</a></small>\r\n\r\n<hr />\r\n\r\n<h2 id="form_elements">Forms</h2>\r\n<fieldset><legend>Legend</legend>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nullam dignissim convallis est. Quisque aliquam. Donec faucibus. Nunc iaculis suscipit dui. Nam sit amet sem. Aliquam libero nisi, imperdiet at, tincidunt nec, gravida vehicula, nisl. Praesent mattis, massa quis luctus fermentum, turpis mi volutpat justo, eu volutpat enim diam eget metus.\r\n\r\n<form>\r\n<h2>Form Element</h2>\r\nLorem ipsum dolor sit amet, consectetuer adipiscing elit. Nullam dignissim convallis est. Quisque aliquam. Donec faucibus. Nunc iaculis suscipit dui.\r\n\r\n<label for="text_field">Text Field:</label>\r\n\r\n<input id="text_field" type="text" /><label for="text_area">Text Area:</label>\r\n<textarea id="text_area"></textarea>\r\n\r\n<label for="select_element">Select Element:</label>\r\n\r\n<select name="select_element"> <optgroup label="Option Group 1"> <option value="1">Option 1</option> <option value="2">Option 2</option> <option value="3">Option 3</option></optgroup></select>&nbsp;\r\n<select name="select_element"> <optgroup label="Option Group 2"> <option value="1">Option 1</option> <option value="2">Option 2</option> <option value="3">Option 3</option></optgroup></select>&nbsp;\r\n<label for="radio_buttons">Radio Buttons:</label>\r\n\r\n<input class="radio" type="radio" name="radio_button" value="radio_1" /> Radio 1 <input class="radio" type="radio" name="radio_button" value="radio_2" /> Radio 2 <input class="radio" type="radio" name="radio_button" value="radio_3" />Radio 3<label for="checkboxes">Checkboxes:</label>\r\n\r\n<input class="checkbox" type="checkbox" name="checkboxes" value="check_1" /> Radio 1 <input class="checkbox" type="checkbox" name="checkboxes" value="check_2" /> Radio 2 <input class="checkbox" type="checkbox" name="checkboxes" value="check_3" />Radio 3<label for="password">Password:</label>\r\n\r\n<input class="password" type="password" name="password" /><label for="file">File Input:</label>\r\n\r\n<input class="file" type="file" name="file" /> <input class="button" type="reset" value="Clear" /> <input class="button" type="submit" value="Submit" /></form></fieldset>\r\n<small><a href="#wrapper">[top]</a></small>\r\n\r\n<hr />\r\n\r\n<h2 id="tables">Tables</h2>\r\n<table cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr>\r\n<th>Table Header 1</th>\r\n<th>Table Header 2</th>\r\n<th>Table Header 3</th>\r\n</tr>\r\n<tr>\r\n<td>Division 1</td>\r\n<td>Division 2</td>\r\n<td>Division 3</td>\r\n</tr>\r\n<tr class="even">\r\n<td>Division 1</td>\r\n<td>Division 2</td>\r\n<td>Division 3</td>\r\n</tr>\r\n<tr>\r\n<td>Division 1</td>\r\n<td>Division 2</td>\r\n<td>Division 3</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<small><a href="#wrapper">[top]</a></small>\r\n\r\n<hr />\r\n\r\n<h2 id="misc">Misc Stuff – abbr, acronym, pre, code, sub, sup, etc.</h2>\r\nLorem <sup>superscript</sup> dolor <sub>subscript</sub> amet, consectetuer adipiscing elit. Nullam dignissim convallis est. Quisque aliquam. <cite>cite</cite>. Nunc iaculis suscipit dui. Nam sit amet sem. Aliquam libero nisi, imperdiet at, tincidunt nec, gravida vehicula, nisl. Praesent mattis, massa quis luctus fermentum, turpis mi volutpat justo, eu volutpat enim diam eget metus. Maecenas ornare tortor. Donec sed tellus eget sapien fringilla nonummy. <acronym title="National Basketball Association">NBA</acronym> Mauris a ante. Suspendisse quam sem, consequat at, commodo vitae, feugiat in, nunc. Morbi imperdiet augue quis tellus. <abbr title="Avenue">AVE</abbr>\r\n<pre>\r\nLorem ipsum dolor sit amet,\r\n consectetuer adipiscing elit.\r\n Nullam dignissim convallis est.\r\n Quisque aliquam. Donec faucibus.\r\nNunc iaculis suscipit dui.\r\nNam sit amet sem.\r\nAliquam libero nisi, imperdiet at,\r\n tincidunt nec, gravida vehicula,\r\n nisl.\r\nPraesent mattis, massa quis\r\nluctus fermentum, turpis mi\r\nvolutpat justo, eu volutpat\r\nenim diam eget metus.\r\nMaecenas ornare tortor.\r\nDonec sed tellus eget sapien\r\n fringilla nonummy.\r\n<acronym title="National Basketball Association">NBA</acronym>\r\nMauris a ante. Suspendisse\r\n quam sem, consequat at,\r\ncommodo vitae, feugiat in,\r\nnunc. Morbi imperdiet augue\r\n quis tellus.\r\n<abbr title="Avenue">AVE</abbr></pre>\r\n<blockquote>“This stylesheet is going to help so freaking much.”\r\n-Blockquote</blockquote>\r\n<small><a href="#wrapper">[top]</a></small>\r\n<!-- End of Sample Content →\r\n'),
(841, 76, '_message_key', 'post_updated'),
(842, 76, '_user_id', '1'),
(843, 76, '_user_login', 'highrank'),
(844, 76, '_user_email', 'ilawyerwp@gmail.com'),
(845, 76, '_server_remote_addr', '::1'),
(846, 76, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/post.php?post=178&action=edit'),
(847, 77, '_message_key', 'user_logged_out'),
(848, 77, '_user_id', '1'),
(849, 77, '_user_login', 'highrank'),
(850, 77, '_user_email', 'ilawyerwp@gmail.com'),
(851, 77, '_server_remote_addr', '::1'),
(852, 77, '_server_http_referer', 'http://tedsmithdemo.com/about-us/'),
(853, 78, 'failed_username', 'destroyer'),
(854, 78, 'server_http_user_agent', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0'),
(855, 78, '_message_key', 'user_unknown_login_failed'),
(856, 78, '_server_remote_addr', '::1'),
(857, 78, '_server_http_referer', 'http://tedsmithdemo.com/wp-login.php?redirect_to=http%3A%2F%2Ftedsmithdemo.com%2Fwp-admin%2F&reauth=1'),
(858, 79, 'user_id', '1'),
(859, 79, 'user_email', 'ilawyerwp@gmail.com'),
(860, 79, 'user_login', 'highrank'),
(861, 79, '_user_id', '1'),
(862, 79, '_user_login', 'highrank'),
(863, 79, '_user_email', 'ilawyerwp@gmail.com'),
(864, 79, 'server_http_user_agent', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0'),
(865, 79, '_message_key', 'user_logged_in'),
(866, 79, '_server_remote_addr', '::1'),
(867, 79, '_server_http_referer', 'http://tedsmithdemo.com/wp-login.php'),
(868, 80, 'post_id', '178'),
(869, 80, 'post_type', 'page'),
(870, 80, 'post_title', 'About Us'),
(871, 80, 'post_prev_post_content', 'The purpose of this HTML is to help determine what default settings are with CSS and to make sure that all possible HTML Elements are included in this HTML so as to not miss any possible Elements when designing a site.\r\n\r\n<hr />\r\n\r\n<h1>Heading 1</h1>\r\n<h2>Heading 2</h2>\r\n<h3>Heading 3</h3>\r\n<h4>Heading 4</h4>\r\n<h5>Heading 5</h5>\r\n<h6>Heading 6</h6>\r\n<small><a href="#wrapper">[top]</a></small>\r\n\r\n<hr />\r\n\r\n<h2 id="paragraph">Paragraph</h2>\r\nLorem ipsum dolor sit amet, <a title="test link" href="#">test link</a> adipiscing elit. Nullam dignissim convallis est. Quisque aliquam. Donec faucibus. Nunc iaculis suscipit dui. Nam sit amet sem. Aliquam libero nisi, imperdiet at, tincidunt nec, gravida vehicula, nisl. Praesent mattis, massa quis luctus fermentum, turpis mi volutpat justo, eu volutpat enim diam eget metus. Maecenas ornare tortor. Donec sed tellus eget sapien fringilla nonummy. Mauris a ante. Suspendisse quam sem, consequat at, commodo vitae, feugiat in, nunc. Morbi imperdiet augue quis tellus.\r\n\r\nLorem ipsum dolor sit amet, <em>emphasis</em> consectetuer adipiscing elit. Nullam dignissim convallis est. Quisque aliquam. Donec faucibus. Nunc iaculis suscipit dui. Nam sit amet sem. Aliquam libero nisi, imperdiet at, tincidunt nec, gravida vehicula, nisl. Praesent mattis, massa quis luctus fermentum, turpis mi volutpat justo, eu volutpat enim diam eget metus. Maecenas ornare tortor. Donec sed tellus eget sapien fringilla nonummy. Mauris a ante. Suspendisse quam sem, consequat at, commodo vitae, feugiat in, nunc. Morbi imperdiet augue quis tellus.\r\n\r\n<small><a href="#wrapper">[top]</a></small>\r\n\r\n<hr />\r\n\r\n<h2 id="list_types">List Types</h2>\r\n<h3>Definition List</h3>\r\n<dl><dt>Definition List Title</dt><dd>This is a definition list division.</dd></dl>\r\n<h3>Ordered List</h3>\r\n<ol>\r\n	<li>List Item 1</li>\r\n	<li>List Item 2</li>\r\n	<li>List Item 3</li>\r\n</ol>\r\n<h3>Unordered List</h3>\r\n<ul>\r\n	<li>List Item 1</li>\r\n	<li>List Item 2</li>\r\n	<li>List Item 3</li>\r\n</ul>\r\n<small><a href="#wrapper">[top]</a></small>\r\n\r\n<hr />\r\n\r\n<h2 id="form_elements">Forms</h2>\r\n<fieldset><legend>Legend</legend>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nullam dignissim convallis est. Quisque aliquam. Donec faucibus. Nunc iaculis suscipit dui. Nam sit amet sem. Aliquam libero nisi, imperdiet at, tincidunt nec, gravida vehicula, nisl. Praesent mattis, massa quis luctus fermentum, turpis mi volutpat justo, eu volutpat enim diam eget metus.\r\n\r\n<form>\r\n<h2>Form Element</h2>\r\nLorem ipsum dolor sit amet, consectetuer adipiscing elit. Nullam dignissim convallis est. Quisque aliquam. Donec faucibus. Nunc iaculis suscipit dui.\r\n\r\n<label for="text_field">Text Field:</label>\r\n\r\n<input id="text_field" type="text" /><label for="text_area">Text Area:</label>\r\n<textarea id="text_area"></textarea>\r\n\r\n<label for="select_element">Select Element:</label>\r\n\r\n<select name="select_element"> <optgroup label="Option Group 1"> <option value="1">Option 1</option> <option value="2">Option 2</option> <option value="3">Option 3</option></optgroup></select>&nbsp;\r\n<select name="select_element"> <optgroup label="Option Group 2"> <option value="1">Option 1</option> <option value="2">Option 2</option> <option value="3">Option 3</option></optgroup></select>&nbsp;\r\n<label for="radio_buttons">Radio Buttons:</label>\r\n\r\n<input class="radio" type="radio" name="radio_button" value="radio_1" /> Radio 1 <input class="radio" type="radio" name="radio_button" value="radio_2" /> Radio 2 <input class="radio" type="radio" name="radio_button" value="radio_3" />Radio 3<label for="checkboxes">Checkboxes:</label>\r\n\r\n<input class="checkbox" type="checkbox" name="checkboxes" value="check_1" /> Radio 1 <input class="checkbox" type="checkbox" name="checkboxes" value="check_2" /> Radio 2 <input class="checkbox" type="checkbox" name="checkboxes" value="check_3" />Radio 3<label for="password">Password:</label>\r\n\r\n<input class="password" type="password" name="password" /><label for="file">File Input:</label>\r\n\r\n<input class="file" type="file" name="file" /> <input class="button" type="reset" value="Clear" /> <input class="button" type="submit" value="Submit" /></form></fieldset>\r\n<small><a href="#wrapper">[top]</a></small>\r\n\r\n<hr />\r\n\r\n<h2 id="tables">Tables</h2>\r\n<table cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr>\r\n<th>Table Header 1</th>\r\n<th>Table Header 2</th>\r\n<th>Table Header 3</th>\r\n</tr>\r\n<tr>\r\n<td>Division 1</td>\r\n<td>Division 2</td>\r\n<td>Division 3</td>\r\n</tr>\r\n<tr class="even">\r\n<td>Division 1</td>\r\n<td>Division 2</td>\r\n<td>Division 3</td>\r\n</tr>\r\n<tr>\r\n<td>Division 1</td>\r\n<td>Division 2</td>\r\n<td>Division 3</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<small><a href="#wrapper">[top]</a></small>\r\n\r\n<hr />\r\n\r\n<h2 id="misc">Misc Stuff – abbr, acronym, pre, code, sub, sup, etc.</h2>\r\nLorem <sup>superscript</sup> dolor <sub>subscript</sub> amet, consectetuer adipiscing elit. Nullam dignissim convallis est. Quisque aliquam. <cite>cite</cite>. Nunc iaculis suscipit dui. Nam sit amet sem. Aliquam libero nisi, imperdiet at, tincidunt nec, gravida vehicula, nisl. Praesent mattis, massa quis luctus fermentum, turpis mi volutpat justo, eu volutpat enim diam eget metus. Maecenas ornare tortor. Donec sed tellus eget sapien fringilla nonummy. <acronym title="National Basketball Association">NBA</acronym> Mauris a ante. Suspendisse quam sem, consequat at, commodo vitae, feugiat in, nunc. Morbi imperdiet augue quis tellus. <abbr title="Avenue">AVE</abbr>\r\n<pre>\r\nLorem ipsum dolor sit amet,\r\n consectetuer adipiscing elit.\r\n Nullam dignissim convallis est.\r\n Quisque aliquam. Donec faucibus.\r\nNunc iaculis suscipit dui.\r\nNam sit amet sem.\r\nAliquam libero nisi, imperdiet at,\r\n tincidunt nec, gravida vehicula,\r\n nisl.\r\nPraesent mattis, massa quis\r\nluctus fermentum, turpis mi\r\nvolutpat justo, eu volutpat\r\nenim diam eget metus.\r\nMaecenas ornare tortor.\r\nDonec sed tellus eget sapien\r\n fringilla nonummy.\r\n<acronym title="National Basketball Association">NBA</acronym>\r\nMauris a ante. Suspendisse\r\n quam sem, consequat at,\r\ncommodo vitae, feugiat in,\r\nnunc. Morbi imperdiet augue\r\n quis tellus.\r\n<abbr title="Avenue">AVE</abbr></pre>\r\n<blockquote>“This stylesheet is going to help so freaking much.”\r\n-Blockquote</blockquote>\r\n<small><a href="#wrapper">[top]</a></small>\r\n<!-- End of Sample Content →\r\n'),
(872, 80, 'post_new_post_content', 'The purpose of this HTML is to help determine what default settings are with CSS and to make sure that all possible HTML Elements are included in this HTML so as to not miss any possible Elements when designing a site.\r\n\r\n<hr />\r\n\r\n<h1>Heading 1</h1>\r\n<h2>Heading 2</h2>\r\n<h3>Heading 3</h3>\r\n<h4>Heading 4</h4>\r\n<h5>Heading 5</h5>\r\n<h6>Heading 6</h6>\r\n<small><a href="#wrapper">[top]</a></small>\r\n\r\n<hr />\r\n\r\n<h2 id="paragraph">Paragraph</h2>\r\nLorem ipsum dolor sit amet, <a title="test link" href="#">test link</a> adipiscing elit. Nullam dignissim convallis est. Quisque aliquam. Donec faucibus. Nunc iaculis suscipit dui. Nam sit amet sem. Aliquam libero nisi, imperdiet at, tincidunt nec, gravida vehicula, nisl. Praesent mattis, massa quis luctus fermentum, turpis mi volutpat justo, eu volutpat enim diam eget metus. Maecenas ornare tortor. Donec sed tellus eget sapien fringilla nonummy. Mauris a ante. Suspendisse quam sem, consequat at, commodo vitae, feugiat in, nunc. Morbi imperdiet augue quis tellus.\r\n\r\nLorem ipsum dolor sit amet, <em>emphasis</em> consectetuer adipiscing elit. Nullam dignissim convallis est. Quisque aliquam. Donec faucibus. Nunc iaculis suscipit dui. Nam sit amet sem. Aliquam libero nisi, imperdiet at, tincidunt nec, gravida vehicula, nisl. Praesent mattis, massa quis luctus fermentum, turpis mi volutpat justo, eu volutpat enim diam eget metus. Maecenas ornare tortor. Donec sed tellus eget sapien fringilla nonummy. Mauris a ante. Suspendisse quam sem, consequat at, commodo vitae, feugiat in, nunc. Morbi imperdiet augue quis tellus.\r\n\r\n<small><a href="#wrapper">[top]</a></small>\r\n\r\n<hr />\r\n\r\n<h2 id="list_types">List Types</h2>\r\n<h3>Definition List</h3>\r\n<dl><dt>Definition List Title</dt><dd>This is a definition list division.</dd></dl>\r\n<h3>Ordered List</h3>\r\n<ol>\r\n	<li>List Item 1</li>\r\n	<li>List Item 2</li>\r\n	<li>List Item 3</li>\r\n</ol>\r\n<h3>Unordered List</h3>\r\n<ul>\r\n	<li>List Item 1</li>\r\n	<li>List Item 2</li>\r\n	<li>List Item 3</li>\r\n</ul>\r\n<small><a href="#wrapper">[top]</a></small>\r\n\r\n<hr />\r\n\r\n<h2 id="form_elements">Forms</h2>\r\n<fieldset><legend>Legend</legend>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nullam dignissim convallis est. Quisque aliquam. Donec faucibus. Nunc iaculis suscipit dui. Nam sit amet sem. Aliquam libero nisi, imperdiet at, tincidunt nec, gravida vehicula, nisl. Praesent mattis, massa quis luctus fermentum, turpis mi volutpat justo, eu volutpat enim diam eget metus.\r\n\r\n<form>\r\n<h2>Form Element</h2>\r\nLorem ipsum dolor sit amet, consectetuer adipiscing elit. Nullam dignissim convallis est. Quisque aliquam. Donec faucibus. Nunc iaculis suscipit dui.\r\n\r\n<label for="text_field">Text Field:</label>\r\n\r\n<input id="text_field" type="text" /><label for="text_area">Text Area:</label>\r\n<textarea id="text_area"></textarea>\r\n\r\n<label for="select_element">Select Element:</label>\r\n\r\n<select name="select_element"> <optgroup label="Option Group 1"> <option value="1">Option 1</option> <option value="2">Option 2</option> <option value="3">Option 3</option></optgroup></select>&nbsp;\r\n<select name="select_element"> <optgroup label="Option Group 2"> <option value="1">Option 1</option> <option value="2">Option 2</option> <option value="3">Option 3</option></optgroup></select>&nbsp;\r\n<label for="radio_buttons">Radio Buttons:</label>\r\n\r\n<input class="radio" type="radio" name="radio_button" value="radio_1" /> Radio 1 <input class="radio" type="radio" name="radio_button" value="radio_2" /> Radio 2 <input class="radio" type="radio" name="radio_button" value="radio_3" />Radio 3<label for="checkboxes">Checkboxes:</label>\r\n\r\n<input class="checkbox" type="checkbox" name="checkboxes" value="check_1" /> Radio 1 <input class="checkbox" type="checkbox" name="checkboxes" value="check_2" /> Radio 2 <input class="checkbox" type="checkbox" name="checkboxes" value="check_3" />Radio 3<label for="password">Password:</label>\r\n\r\n<input class="password" type="password" name="password" /><label for="file">File Input:</label>\r\n\r\n<input class="file" type="file" name="file" /> <input class="button" type="reset" value="Clear" /> <input class="button" type="submit" value="Submit" /></form></fieldset>\r\n<small><a href="#wrapper">[top]</a></small>\r\n\r\n<hr />\r\n\r\n<h2 id="tables">Tables</h2>\r\n<table cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr>\r\n<th>Table Header 1</th>\r\n<th>Table Header 2</th>\r\n<th>Table Header 3</th>\r\n</tr>\r\n<tr>\r\n<td>Division 1</td>\r\n<td>Division 2</td>\r\n<td>Division 3</td>\r\n</tr>\r\n<tr class="even">\r\n<td>Division 1</td>\r\n<td>Division 2</td>\r\n<td>Division 3</td>\r\n</tr>\r\n<tr>\r\n<td>Division 1</td>\r\n<td>Division 2</td>\r\n<td>Division 3</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<small><a href="#wrapper">[top]</a></small>\r\n\r\n'),
(873, 80, '_message_key', 'post_updated'),
(874, 80, '_user_id', '1'),
(875, 80, '_user_login', 'highrank'),
(876, 80, '_user_email', 'ilawyerwp@gmail.com'),
(877, 80, '_server_remote_addr', '::1'),
(878, 80, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/post.php?post=178&action=edit'),
(879, 81, '_message_key', 'user_logged_out'),
(880, 81, '_user_id', '1'),
(881, 81, '_user_login', 'highrank'),
(882, 81, '_user_email', 'ilawyerwp@gmail.com'),
(883, 81, '_server_remote_addr', '::1'),
(884, 81, '_server_http_referer', 'http://tedsmithdemo.com/about-us/'),
(885, 82, 'user_id', '1'),
(886, 82, 'user_email', 'ilawyerwp@gmail.com'),
(887, 82, 'user_login', 'highrank'),
(888, 82, '_user_id', '1'),
(889, 82, '_user_login', 'highrank'),
(890, 82, '_user_email', 'ilawyerwp@gmail.com'),
(891, 82, 'server_http_user_agent', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0'),
(892, 82, '_message_key', 'user_logged_in'),
(893, 82, '_server_remote_addr', '::1'),
(894, 82, '_server_http_referer', 'http://tedsmithdemo.com/wp-login.php?redirect_to=http%3A%2F%2Ftedsmithdemo.com%2Fwp-admin%2F&reauth=1'),
(895, 83, 'post_id', '178'),
(896, 83, 'post_type', 'page'),
(897, 83, 'post_title', 'About Us'),
(898, 83, 'post_prev_post_content', 'The purpose of this HTML is to help determine what default settings are with CSS and to make sure that all possible HTML Elements are included in this HTML so as to not miss any possible Elements when designing a site.\r\n\r\n<hr />\r\n\r\n<h1>Heading 1</h1>\r\n<h2>Heading 2</h2>\r\n<h3>Heading 3</h3>\r\n<h4>Heading 4</h4>\r\n<h5>Heading 5</h5>\r\n<h6>Heading 6</h6>\r\n<small><a href="#wrapper">[top]</a></small>\r\n\r\n<hr />\r\n\r\n<h2 id="paragraph">Paragraph</h2>\r\nLorem ipsum dolor sit amet, <a title="test link" href="#">test link</a> adipiscing elit. Nullam dignissim convallis est. Quisque aliquam. Donec faucibus. Nunc iaculis suscipit dui. Nam sit amet sem. Aliquam libero nisi, imperdiet at, tincidunt nec, gravida vehicula, nisl. Praesent mattis, massa quis luctus fermentum, turpis mi volutpat justo, eu volutpat enim diam eget metus. Maecenas ornare tortor. Donec sed tellus eget sapien fringilla nonummy. Mauris a ante. Suspendisse quam sem, consequat at, commodo vitae, feugiat in, nunc. Morbi imperdiet augue quis tellus.\r\n\r\nLorem ipsum dolor sit amet, <em>emphasis</em> consectetuer adipiscing elit. Nullam dignissim convallis est. Quisque aliquam. Donec faucibus. Nunc iaculis suscipit dui. Nam sit amet sem. Aliquam libero nisi, imperdiet at, tincidunt nec, gravida vehicula, nisl. Praesent mattis, massa quis luctus fermentum, turpis mi volutpat justo, eu volutpat enim diam eget metus. Maecenas ornare tortor. Donec sed tellus eget sapien fringilla nonummy. Mauris a ante. Suspendisse quam sem, consequat at, commodo vitae, feugiat in, nunc. Morbi imperdiet augue quis tellus.\r\n\r\n<small><a href="#wrapper">[top]</a></small>\r\n\r\n<hr />\r\n\r\n<h2 id="list_types">List Types</h2>\r\n<h3>Definition List</h3>\r\n<dl><dt>Definition List Title</dt><dd>This is a definition list division.</dd></dl>\r\n<h3>Ordered List</h3>\r\n<ol>\r\n	<li>List Item 1</li>\r\n	<li>List Item 2</li>\r\n	<li>List Item 3</li>\r\n</ol>\r\n<h3>Unordered List</h3>\r\n<ul>\r\n	<li>List Item 1</li>\r\n	<li>List Item 2</li>\r\n	<li>List Item 3</li>\r\n</ul>\r\n<small><a href="#wrapper">[top]</a></small>\r\n\r\n<hr />\r\n\r\n<h2 id="form_elements">Forms</h2>\r\n<fieldset><legend>Legend</legend>Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nullam dignissim convallis est. Quisque aliquam. Donec faucibus. Nunc iaculis suscipit dui. Nam sit amet sem. Aliquam libero nisi, imperdiet at, tincidunt nec, gravida vehicula, nisl. Praesent mattis, massa quis luctus fermentum, turpis mi volutpat justo, eu volutpat enim diam eget metus.\r\n\r\n<form>\r\n<h2>Form Element</h2>\r\nLorem ipsum dolor sit amet, consectetuer adipiscing elit. Nullam dignissim convallis est. Quisque aliquam. Donec faucibus. Nunc iaculis suscipit dui.\r\n\r\n<label for="text_field">Text Field:</label>\r\n\r\n<input id="text_field" type="text" /><label for="text_area">Text Area:</label>\r\n<textarea id="text_area"></textarea>\r\n\r\n<label for="select_element">Select Element:</label>\r\n\r\n<select name="select_element"> <optgroup label="Option Group 1"> <option value="1">Option 1</option> <option value="2">Option 2</option> <option value="3">Option 3</option></optgroup></select>&nbsp;\r\n<select name="select_element"> <optgroup label="Option Group 2"> <option value="1">Option 1</option> <option value="2">Option 2</option> <option value="3">Option 3</option></optgroup></select>&nbsp;\r\n<label for="radio_buttons">Radio Buttons:</label>\r\n\r\n<input class="radio" type="radio" name="radio_button" value="radio_1" /> Radio 1 <input class="radio" type="radio" name="radio_button" value="radio_2" /> Radio 2 <input class="radio" type="radio" name="radio_button" value="radio_3" />Radio 3<label for="checkboxes">Checkboxes:</label>\r\n\r\n<input class="checkbox" type="checkbox" name="checkboxes" value="check_1" /> Radio 1 <input class="checkbox" type="checkbox" name="checkboxes" value="check_2" /> Radio 2 <input class="checkbox" type="checkbox" name="checkboxes" value="check_3" />Radio 3<label for="password">Password:</label>\r\n\r\n<input class="password" type="password" name="password" /><label for="file">File Input:</label>\r\n\r\n<input class="file" type="file" name="file" /> <input class="button" type="reset" value="Clear" /> <input class="button" type="submit" value="Submit" /></form></fieldset>\r\n<small><a href="#wrapper">[top]</a></small>\r\n\r\n<hr />\r\n\r\n<h2 id="tables">Tables</h2>\r\n<table cellspacing="0" cellpadding="0">\r\n<tbody>\r\n<tr>\r\n<th>Table Header 1</th>\r\n<th>Table Header 2</th>\r\n<th>Table Header 3</th>\r\n</tr>\r\n<tr>\r\n<td>Division 1</td>\r\n<td>Division 2</td>\r\n<td>Division 3</td>\r\n</tr>\r\n<tr class="even">\r\n<td>Division 1</td>\r\n<td>Division 2</td>\r\n<td>Division 3</td>\r\n</tr>\r\n<tr>\r\n<td>Division 1</td>\r\n<td>Division 2</td>\r\n<td>Division 3</td>\r\n</tr>\r\n</tbody>\r\n</table>\r\n<small><a href="#wrapper">[top]</a></small>\r\n\r\n'),
(899, 83, 'post_new_post_content', '<h2>Texans have been represented by the Ted Smith Law Group for over 43 years.</h2>\r\nSuspendisse eu lacinia enim, vel pellentesque diam. Pellentesque feu\r\ngiat a massa ac iaculis. Aliquam erat volutpat. Aliquam non quam luctus, tincidunt urna malesuada, convallis risus. Suspendisse tincidunt vehicula ultrices. Sed congue elit pretium, fringilla neque ac, imperdiet nisl. In posuere eros pellentesque porttitor varius. Aenean aliquet luctus augue id pulvinar. Cras ac pellentesque ante. Nam tempor sapien eu enim mollis, ac tincidunt nisl semper. Etiam at tortor nec sapien euismod gravida. Proin sollicitudin varius nisi a lacinia. Proin vestibulum eget augue et ultricies. Aenean cursus tristique ante ac sollicitudin.\r\n\r\nNullam dapibus augue sed lacus tempus lacinia. Proin vitae blandit tortor, eget posuere nibh. Aenean consectetur, nulla sed aliquet malesuada, nibh arcu aliquet ipsum, nec bibendum est nisl a lacus. Maecenas quis elit laoreet, convallis neque eu, ullamcorper arcu.\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean ult ricies risus quis viverra scelerisque. Suspendisse eu lacinia enim, vel pelle ntesque diam. Pellentesque feugiat a massa ac iaculis. Aliquam erat volutpat. Aliquam non quam luctus, tincidunt urna malesuada, convallis risus. Suspendisse tincidunt vehicula ultrices. Sed congue elit pretium, fringilla neque ac, imperdiet nisl. In posuere eros pellentesque porttitor varius. Aenean aliquet luctus augue id pulvinar. Cras ac pellentesque.\r\n\r\n<h2>Texans have been represented by the Ted Smith Law Group for over 43 years.</h2>\r\n\r\nNam tempor sapien eu enim mollis, ac tincidunt nisl semper. Etiam at tortor nec sapien euismod gravida. Proin sollicitudin varius nisi a lacinia. Proin vestibulum eget augue et ultricies. Aenean cursus tristique ante ac sollicitudin. Nullam dapibus augue sed lacus tempus lacinia. Proin vitae blandit tortor, eget posuere nibh. Aenean consectetur, nulla sed aliquet malesuada, nibh arcu aliquet ipsum, nec bibendum est nisl a lacus.'),
(900, 83, '_message_key', 'post_updated') ;
INSERT INTO `wp_simple_history_contexts` ( `context_id`, `history_id`, `key`, `value`) VALUES
(901, 83, '_user_id', '1'),
(902, 83, '_user_login', 'highrank'),
(903, 83, '_user_email', 'ilawyerwp@gmail.com'),
(904, 83, '_server_remote_addr', '::1'),
(905, 83, '_server_http_referer', 'http://tedsmithdemo.com/wp-admin/post.php?post=178&action=edit'),
(906, 84, '_message_key', 'user_logged_out'),
(907, 84, '_user_id', '1'),
(908, 84, '_user_login', 'highrank'),
(909, 84, '_user_email', 'ilawyerwp@gmail.com'),
(910, 84, '_server_remote_addr', '::1'),
(911, 84, '_server_http_referer', 'http://tedsmithdemo.com/about-us/'),
(912, 85, 'user_id', '1'),
(913, 85, 'user_email', 'ilawyerwp@gmail.com'),
(914, 85, 'user_login', 'highrank'),
(915, 85, '_user_id', '1'),
(916, 85, '_user_login', 'highrank'),
(917, 85, '_user_email', 'ilawyerwp@gmail.com'),
(918, 85, 'server_http_user_agent', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0'),
(919, 85, '_message_key', 'user_logged_in'),
(920, 85, '_server_remote_addr', '::1'),
(921, 85, '_server_http_referer', 'http://tedsmithdemo.com/wp-login.php?redirect_to=http%3A%2F%2Ftedsmithdemo.com%2Fwp-admin%2F&reauth=1') ;

#
# End of data contents of table `wp_simple_history_contexts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(110, 2, 0),
(111, 2, 0),
(112, 2, 0),
(113, 2, 0),
(114, 2, 0),
(115, 2, 0),
(116, 2, 0),
(117, 2, 0),
(118, 2, 0),
(119, 2, 0),
(120, 2, 0),
(121, 2, 0),
(122, 2, 0),
(123, 2, 0),
(124, 2, 0),
(125, 2, 0),
(126, 2, 0),
(127, 2, 0),
(128, 2, 0),
(129, 2, 0),
(130, 2, 0),
(131, 2, 0),
(133, 2, 0),
(137, 2, 0),
(139, 2, 0),
(140, 2, 0),
(141, 2, 0),
(142, 2, 0),
(143, 2, 0),
(144, 2, 0),
(145, 2, 0),
(146, 2, 0),
(147, 2, 0),
(148, 2, 0),
(149, 2, 0),
(150, 2, 0),
(151, 2, 0),
(152, 2, 0),
(153, 2, 0),
(154, 2, 0),
(155, 2, 0),
(156, 2, 0),
(157, 2, 0),
(158, 2, 0),
(159, 2, 0),
(160, 2, 0),
(169, 3, 0),
(174, 3, 0),
(175, 3, 0),
(177, 3, 0),
(180, 3, 0),
(182, 3, 0),
(183, 3, 0),
(184, 3, 0),
(185, 3, 0),
(186, 3, 0),
(187, 3, 0),
(188, 3, 0),
(189, 3, 0),
(190, 3, 0),
(191, 3, 0),
(192, 3, 0),
(194, 3, 0),
(195, 3, 0),
(196, 3, 0),
(197, 3, 0),
(198, 3, 0),
(199, 3, 0),
(200, 3, 0),
(201, 3, 0),
(202, 3, 0),
(203, 3, 0),
(204, 3, 0),
(205, 3, 0),
(207, 3, 0),
(208, 3, 0),
(209, 3, 0),
(210, 3, 0),
(211, 3, 0),
(212, 3, 0),
(213, 3, 0),
(214, 3, 0),
(215, 3, 0),
(222, 3, 0),
(223, 3, 0),
(224, 3, 0),
(228, 3, 0),
(229, 3, 0),
(232, 3, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'nav_menu', '', 0, 46),
(3, 3, 'nav_menu', '', 0, 43) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Practice Areas', 'practice-areas', 0),
(3, 'MainNav', 'mainnav', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'highrank'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(11, 1, 'wp_user_level', '10'),
(12, 1, 'dismissed_wp_pointers', ''),
(13, 1, 'show_welcome_panel', '1'),
(14, 1, 'session_tokens', 'a:2:{s:64:"89f363a6c4fc2f8f81db0478b7d43eee974a8acc814cd581f57c194224182099";a:4:{s:10:"expiration";i:1470266482;s:2:"ip";s:3:"::1";s:2:"ua";s:82:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0";s:5:"login";i:1470093682;}s:64:"e3c31fdd3a1a14e58700c91c558206bd0dd411cccd337f806731091798251b82";a:4:{s:10:"expiration";i:1470291284;s:2:"ip";s:3:"::1";s:2:"ua";s:82:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10.11; rv:47.0) Gecko/20100101 Firefox/47.0";s:5:"login";i:1470118484;}}'),
(15, 1, 'wp_dashboard_quick_press_last_post_id', '233'),
(16, 1, 'wp_user-settings', 'hidetb=1&editor=html'),
(17, 1, 'wp_user-settings-time', '1470115862'),
(18, 1, 'edit_page_per_page', '400'),
(19, 1, 'wpseo_ignore_tour', '1'),
(20, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(21, 1, 'metaboxhidden_nav-menus', 'a:2:{i:0;s:12:"add-post_tag";i:1;s:15:"add-post_format";}'),
(22, 1, 'nav_menu_recently_edited', '3'),
(23, 1, '_yoast_wpseo_profile_updated', '1467999653'),
(24, 1, 'wp_yoast_notifications', 'a:3:{i:0;a:2:{s:7:"message";s:166:"Don\'t miss your crawl errors: <a href="http://tedsmithdemo.com/wp-admin/admin.php?page=wpseo_search_console&tab=settings">connect with Google Search Console here</a>.";s:7:"options";a:8:{s:4:"type";s:7:"warning";s:2:"id";s:17:"wpseo-dismiss-gsc";s:5:"nonce";N;s:8:"priority";d:0.5;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:14:"manage_options";s:16:"capability_check";s:3:"all";}}i:1;a:2:{s:7:"message";s:149:"Yoast SEO has been updated to version 3.4. <a href="http://tedsmithdemo.com/wp-admin/admin.php?page=wpseo_dashboard&intro=1">Find out what\'s new!</a>";s:7:"options";a:8:{s:4:"type";s:7:"updated";s:2:"id";s:19:"wpseo-dismiss-about";s:5:"nonce";N;s:8:"priority";d:0.5;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:14:"manage_options";s:16:"capability_check";s:3:"all";}}i:2;a:2:{s:7:"message";s:220:"<strong>Huge SEO Issue: You\'re blocking access to robots.</strong> You must <a href="http://tedsmithdemo.com/wp-admin/options-reading.php">go to your Reading Settings</a> and uncheck the box for Search Engine Visibility.";s:7:"options";a:8:{s:4:"type";s:5:"error";s:2:"id";s:32:"wpseo-dismiss-blog-public-notice";s:5:"nonce";N;s:8:"priority";i:1;s:9:"data_json";a:0:{}s:13:"dismissal_key";N;s:12:"capabilities";s:14:"manage_options";s:16:"capability_check";s:3:"all";}}}') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'highrank', '$P$BMWw8grTyg6UPnT7Jc1mglVUzKz4t/.', 'highrank', 'ilawyerwp@gmail.com', '', '2016-05-20 17:38:50', '', 0, 'highrank') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

